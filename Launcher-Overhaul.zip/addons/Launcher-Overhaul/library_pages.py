"""Saved and recent servers, shared server rows, and the add-on manager."""

import tkinter as tk

from client.core import addon_loader
from client.core import server_list_panel as stock_servers
from tavern_shared import addon_manager_window

from .launch_history import DEFAULT_PORT, saved_target
from .widgets import BG, BORDER, FOCUS, SECONDARY, SURF, SURF2, UI, button, frame, label, styles, text_field


def split_address(address):
    """Extract the host and port from a community address or a manual entry."""
    address = address.strip()
    if address.startswith("["):
        host, close, suffix = address[1:].partition("]")
        if close:
            return host, suffix.removeprefix(":") or DEFAULT_PORT
    if address.count(":") == 1:
        host, port = address.rsplit(":", 1)
        return host, port or DEFAULT_PORT
    return address, DEFAULT_PORT


def server_address(host, port=DEFAULT_PORT):
    if str(port) == DEFAULT_PORT:
        return host
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    return f"{host}:{port}"


def favorite_key(record):
    """Identify a favorite by address and connection type."""
    target = saved_target(record)
    if target is not None:
        return target.key
    if isinstance(record, dict):
        return record.get("ip"), str(record.get("port") or DEFAULT_PORT), record.get("kind") or "official"
    return None


def _remove_window_header(page):
    header = page.pack_slaves()[:2]
    # Keep unfamiliar layouts intact if the stock launcher changes its chrome.
    if len(header) == 2 and all(isinstance(widget, tk.Frame) for widget in header):
        if tuple(int(widget.cget("height")) for widget in header) == (44, 1):
            for widget in header:
                widget.destroy()


class _ServerRow(tk.Frame):
    def __init__(self, parent, server, name, address, metadata, players, ping):
        super().__init__(parent, takefocus=False, cursor="hand2", highlightthickness=1)
        self.server = server
        self.identity = frame(self, SURF)
        self.identity.grid(row=0, column=0, sticky="nsew", padx=12, pady=8)
        self.columnconfigure(0, weight=1)
        self.name = label(self.identity, name, size=10, weight="bold", width=1,
                          wraplength=185, justify="left")
        self.address = label(self.identity, address, size=9, color=SECONDARY, width=1,
                             wraplength=185, justify="left")
        self.names = [self.name, self.address]
        self.meta = None
        if metadata:
            self.meta = label(self.identity, metadata, size=9, color=SECONDARY, width=1,
                              wraplength=185, justify="left")
            self.names.append(self.meta)
        for widget in self.names:
            widget.pack(fill="x")
        self.identity.bind("<Configure>", self._wrap, add="+")
        self.ping = None
        self.metrics = None
        self.players = None
        self.compact = None
        if players:
            self.metrics = frame(self, SURF)
            self.players = label(self.metrics, players, size=9, weight="bold")
            self.ping = label(self.metrics, size=9)
            self._layout_metrics(True)
            self.bind("<Configure>", lambda event: self._layout_metrics(event.width < 420), add="+")
        self.ping_role = SECONDARY
        self.set_ping(*ping)
        self.paint(False)

    def _wrap(self, event):
        width = max(35, event.width)
        for widget in self.names:
            if int(widget.cget("wraplength")) != width:
                widget.configure(wraplength=width)

    def _layout_metrics(self, compact):
        if compact == self.compact:
            return
        self.compact = compact
        self.players.pack_forget()
        self.ping.pack_forget()
        if compact:
            self.identity.grid_configure(pady=(8, 3))
            self.metrics.grid(row=1, column=0, sticky="w", padx=12, pady=(0, 8))
            self.players.pack(side="left", padx=(0, 10))
            self.ping.pack(side="left")
        else:
            self.identity.grid_configure(pady=8)
            self.metrics.grid(row=0, column=1, sticky="e", padx=(0, 12), pady=8)
            self.players.pack(anchor="e")
            self.ping.pack(anchor="e")

    def set_ping(self, text, role):
        self.ping_role = role
        if self.ping is not None:
            self.ping.configure(text=text)
            styles(self.ping).bind(self.ping, fg=role)

    def paint(self, selected):
        surface = SURF2 if selected else SURF
        ink = "SURF2_TEXT" if selected else "PARCH"
        styles(self).bind(self, bg=surface, highlightbackground="FOCUS" if selected else surface,
                          highlightcolor=FOCUS)
        styles(self.identity).bind(self.identity, bg=surface)
        for widget in self.names:
            styles(widget).bind(widget, bg=surface, fg=ink if selected or widget is self.name else SECONDARY)
        if self.metrics is not None:
            styles(self.metrics).bind(self.metrics, bg=surface)
            styles(self.players).bind(self.players, bg=surface, fg=ink)
            styles(self.ping).bind(self.ping, bg=surface, fg=self.ping_role)


class ServerList(tk.Frame):
    """A keyboard-selectable list that shares the dashboard's scrollbar."""

    def __init__(self, parent, describe, on_selection, on_connect):
        super().__init__(parent, highlightthickness=1)
        styles(self).bind(self, bg=BORDER, highlightbackground=BORDER)
        self._describe = describe
        self._on_selection = on_selection
        self._on_connect = on_connect
        self.rows = []
        self._rows = {}
        self._selected = None
        self._focus_row = None
        empty_surface = self._empty_surface = frame(self, SURF)
        self._empty = label(empty_surface, color=SECONDARY, width=1, wraplength=220, justify="left")
        self._empty.pack(fill="x", padx=14, pady=14)
        empty_surface.bind("<Configure>", self._wrap_empty, add="+")

    @property
    def selected(self):
        return self._selected.server if self._selected is not None else None

    def _wrap_empty(self, event):
        self._empty.configure(wraplength=max(35, event.width - 28))

    def set_servers(self, servers, empty):
        selection = self.selected
        old_rows = self._rows
        self._rows = {}
        self.rows = []
        self._selected = None
        self._empty_surface.pack_forget()
        for row in old_rows.values():
            row.pack_forget()
        for server in servers:
            row = old_rows.pop(id(server), None)
            if row is None:
                row = _ServerRow(self, server, *self._describe(server))
                self._bind_row(row)
            self.rows.append(row)
            self._rows[id(server)] = row
            row.pack(fill="x", pady=(0, 1))
        for row in old_rows.values():
            if row is self._focus_row:
                self._focus_row = None
            row.destroy()
        if self.rows:
            self.rows[-1].pack_configure(pady=0)
        else:
            self._empty.configure(text=empty)
            self._empty_surface.pack(fill="x")
        self.select(selection)

    def select(self, server):
        row = self._rows.get(id(server))
        if self._selected is not None and row is not self._selected:
            self._selected.paint(False)
        self._selected = row
        focus_row = row or (self.rows[0] if self.rows else None)
        if focus_row is not self._focus_row:
            if self._focus_row is not None:
                self._focus_row.configure(takefocus=False)
            if focus_row is not None:
                focus_row.configure(takefocus=True)
            self._focus_row = focus_row
        if row is not None:
            row.paint(True)
        self._on_selection()

    def set_ping(self, server, text, role):
        row = self._rows.get(id(server))
        if row is not None:
            row.set_ping(text, role)

    def _bind_row(self, row):
        controls = [row]
        for widget in controls:
            controls.extend(widget.winfo_children())
            widget.bind("<Button-1>", lambda _event: self._activate(row))
            widget.bind("<Double-Button-1>", lambda _event: self._open(row))
        row.bind("<FocusIn>", lambda _event: self.select(row.server))
        row.bind("<Return>", lambda _event: self._open(row))
        row.bind("<space>", lambda _event: self._activate(row))
        row.bind("<Up>", lambda _event: self._move(row, -1))
        row.bind("<Down>", lambda _event: self._move(row, 1))

    def _activate(self, row):
        row.focus_set()
        self.select(row.server)
        return "break"

    def _open(self, row):
        self.select(row.server)
        self._on_connect()
        return "break"

    def _move(self, row, step):
        index = min(len(self.rows) - 1, max(0, self.rows.index(row) + step))
        return self._activate(self.rows[index])


class ServerActions(tk.Frame):
    """Keep the pin and connect controls together when the toolbar wraps."""

    def __init__(self, parent, is_pinned, on_pin, *, action_parent=None):
        self._docked = action_parent is not None
        super().__init__(action_parent if self._docked else parent, padx=12 if self._docked else 0,
                         pady=6 if self._docked else 0, highlightthickness=int(self._docked))
        styles(self).bind(self, bg=SURF, highlightbackground=BORDER)
        self.pack(fill="x", pady=0 if self._docked else (0, 8))
        self._is_pinned = is_pinned
        self._on_pin = on_pin
        self._target = None
        self._secondary = self._connect = None
        self.pin_button = None
        self._stacked = None
        self.columnconfigure(1, weight=1)
        root = self.winfo_toplevel()
        dashboard = getattr(root, "_launcher_overhaul", None)
        if self._docked:
            self._viewport = action_parent
        else:
            self._viewport = dashboard.pane.canvas if dashboard is not None else root
        self._resize_id = self._viewport.bind("<Configure>", self._reflow, add="+")

    def add_pin_button(self):
        if self._is_pinned is not None and self._on_pin is not None:
            self.pin_button = button(self, "Pin", self._toggle_pin, compact=True)
            self.pin_button.configure(font=(UI, 9, "bold"), width=5, padx=7, state="disabled")
            self.pin_button.bind("<Return>", self._keyboard_pin)
        return self.pin_button

    def show_controls(self, secondary, connect):
        if self._secondary is not None:
            self._secondary.grid_remove()
        self._secondary, self._connect = secondary, connect
        self._stacked = None
        self._reflow()

    def _reflow(self, event=None):
        if self._secondary is None or (event is not None and event.widget is not self._viewport):
            return
        width = self._viewport.winfo_width()
        needed = self._secondary.winfo_reqwidth() + self._connect.winfo_reqwidth() + 6
        if self.pin_button is not None:
            needed += self.pin_button.winfo_reqwidth() + 6
        # The footer's parent is already inside the dashboard's page gutter.
        padding = 26 if self._docked else 62
        stacked = self.pin_button is not None and needed > width - padding
        if stacked == self._stacked:
            return
        self._stacked = stacked
        self._secondary.grid(row=0, column=0, columnspan=4 if stacked else 1,
                             sticky="w", pady=(0, 6) if stacked else 0)
        if self.pin_button is not None:
            self.pin_button.grid(row=int(stacked), column=2, sticky="e")
        self._connect.grid(row=int(stacked), column=3, sticky="e", padx=(6, 0))

    def update_pin(self, target):
        self._target = target
        if self.pin_button is not None:
            pinned = target is not None and self._is_pinned(target)
            self.pin_button.configure(text="Unpin" if pinned else "Pin", state="normal" if target else "disabled")
            styles(self.pin_button).bind(self.pin_button, bg="ACTIVE_TAB" if pinned else SURF2,
                                         fg="ACTIVE_TEXT" if pinned else "SURF2_TEXT")
        self._reflow()

    def _toggle_pin(self):
        if self._target is not None:
            self._on_pin(self._target)
            if self.winfo_exists():
                self.update_pin(self._target)

    def _keyboard_pin(self, _event):
        self.pin_button.invoke()
        return "break"

    def close_dock(self):
        if self._docked and self.winfo_exists():
            self.destroy()

    def destroy(self):
        self._viewport.unbind("<Configure>", self._resize_id)
        super().destroy()


class SavedServersPage(tk.Frame):

    def __init__(self, parent, on_select=None, *, on_target=None, is_pinned=None, on_pin=None, action_parent=None):
        super().__init__(parent)
        styles(self).bind(self, bg=BG)
        self._on_select = on_select
        self._on_target = on_target
        self._source = "saved_servers"
        self._form = None
        self._form_source = None
        self._favorites = []
        self._recent = []

        tabs = frame(self)
        tabs.pack(fill="x", pady=(0, 10))
        self.favorite_tab = button(tabs, "Favorites", lambda: self._show("saved_servers"), compact=True)
        self.favorite_tab.pack(side="left")
        self.recent_tab = button(tabs, "Recent", lambda: self._show("recent_servers"), compact=True)
        self.recent_tab.pack(side="left", padx=(6, 0))

        panel = frame(self, SURF, border=True)
        panel.pack(fill="x")
        self._panel = frame(panel)
        self._panel.pack(fill="x", padx=12, pady=12)
        self._heading = frame(self._panel)
        self._heading.pack(fill="x", pady=(0, 8))
        self._count = label(self._heading, color=SECONDARY, size=9)
        self._count.pack(side="left")
        self.add_button = button(self._heading, "Add server", self._add_manual, compact=True)

        actions = self._actions = self.action_bar = ServerActions(self._panel, is_pinned, on_pin,
                                                                   action_parent=action_parent)
        self.remove_button = button(actions, "Remove", self._remove, compact=True)
        self.save_button = button(actions, "Save favorite", self._save_recent, compact=True)
        self.pin_button = actions.add_pin_button()
        self.connect_button = button(actions, "Connect", self._connect, primary=True, compact=True)
        for control in (self.remove_button, self.save_button, self.connect_button):
            control.configure(font=(UI, 9, "bold"), padx=7)
        self.server_list = ServerList(self._panel, self._describe, self._update_actions, self._connect)
        self.server_list.pack(fill="x")
        self._show("saved_servers")

    def destroy(self):
        self.action_bar.close_dock()
        super().destroy()

    @staticmethod
    def _entries(config, key):
        rows = config.get(key, [])
        return [row for row in rows if isinstance(row, dict) and isinstance(row.get("ip"), str) and
                row["ip"].strip()] if isinstance(rows, list) else []

    @staticmethod
    def _describe(server):
        host = server["ip"]
        metadata = "Headless" if server.get("kind") == "headless" else ""
        return (server.get("name") or host, server_address(host, server.get("port") or DEFAULT_PORT),
                metadata, "", ("", SECONDARY))

    def _show(self, source):
        self._source = source
        config = stock_servers.load_cfg()
        self._favorites = self._entries(config, "saved_servers")
        self._recent = self._entries(config, "recent_servers")
        favorites = source == "saved_servers"
        for tab, active in ((self.favorite_tab, favorites), (self.recent_tab, not favorites)):
            styles(tab).bind(tab, bg="ACTIVE_TAB" if active else SURF2,
                             fg="ACTIVE_TEXT" if active else "SURF2_TEXT",
                             highlightbackground=FOCUS if active else BG)
        self.add_button.pack_forget()
        if favorites:
            self.add_button.pack(side="right")
        self._actions.show_controls(self.remove_button if favorites else self.save_button, self.connect_button)
        if self._form is not None:
            if self._form_source == source:
                self._form.pack(fill="x", before=self.server_list, pady=(0, 8))
            else:
                self._form.pack_forget()
        servers = self._favorites if favorites else self._recent
        noun = "favorite" if favorites else "server"
        self._count.configure(text=f"{len(servers)} {noun if len(servers) == 1 else noun + 's'}")
        empty = ("Add a server by address or save one from the community list." if favorites
                 else "Servers you join will appear here.")
        self.server_list.set_servers(servers, empty)

    def _connect(self):
        server = self.server_list.selected
        if server is not None:
            target = saved_target(server)
            if self._on_target is not None and target is not None:
                self._on_target(target)
            elif self._on_select is not None:
                host = server["ip"]
                self._on_select(host, server.get("name") or host, server.get("port") or DEFAULT_PORT)
            else:
                return
            if self.winfo_exists():
                self.destroy()

    def _is_saved(self, record):
        key = favorite_key(record)
        return any(favorite_key(server) == key for server in self._favorites)

    def _update_actions(self):
        server = self.server_list.selected
        target = saved_target(server)
        state = "normal" if server is not None else "disabled"
        can_connect = self._on_select is not None or (self._on_target is not None and target is not None)
        self.connect_button.configure(state=state if can_connect else "disabled")
        self.remove_button.configure(state=state)
        saved = server is not None and self._is_saved(server)
        self.save_button.configure(text="Saved" if saved else "Save favorite", state="disabled" if saved else state)
        self._actions.update_pin(target)

    def _remove(self):
        server = self.server_list.selected
        if server is None:
            return
        config = stock_servers.load_cfg()
        entries = self._entries(config, "saved_servers")
        if server in entries:
            entries.remove(server)
            config["saved_servers"] = entries
            stock_servers.save_cfg(config)
        self._show(self._source)

    def _save_favorite(self, record):
        config = stock_servers.load_cfg()
        self._favorites = favorites = self._entries(config, "saved_servers")
        if not self._is_saved(record):
            favorites.append(record)
            config["saved_servers"] = favorites
            stock_servers.save_cfg(config)
        self._show(self._source)
        source = self._favorites if self._source == "saved_servers" else self._recent
        key = favorite_key(record)
        match = next((server for server in source if favorite_key(server) == key), None)
        self.server_list.select(match)

    def _add_manual(self):
        self._open_form()

    def _save_recent(self):
        server = self.server_list.selected
        if server is None:
            return
        host = server["ip"]
        if server.get("name") and server["name"] != host:
            self._save_favorite({**server, "port": server.get("port") or DEFAULT_PORT})
        else:
            self._open_form(server)

    def _close_form(self):
        if self._form is not None:
            self._form.destroy()
            self._form = None
            self._form_source = None

    def _open_form(self, server=None):
        self._close_form()
        self._form_source = self._source
        self._form = frame(self._panel, SURF2, border=True)
        self._form.pack(fill="x", before=self.server_list, pady=(0, 8))
        body = frame(self._form)
        body.pack(fill="x", padx=12, pady=12)
        server = server or {}
        address = tk.StringVar(body, server.get("ip", ""))
        port = tk.StringVar(body, server.get("port") or "")
        name = tk.StringVar(body, server.get("name") or "")
        error = tk.StringVar(body)
        fields = frame(body)
        fields.pack(fill="x")
        fields.columnconfigure(0, weight=1)
        host_field, host_entry = text_field(fields, "Server address", address, size=7)
        port_field, port_entry = text_field(fields, "Port", port, size=4)
        name_field, name_entry = text_field(fields, "Display name", name, size=7)
        host_field.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        port_field.grid(row=0, column=1, sticky="ew")
        name_field.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        validation = label(body, textvariable=error, color="STATUS_ERROR", size=9, width=1, justify="left")
        validation.pack(fill="x")
        validation.bind("<Configure>", lambda event: validation.configure(wraplength=event.width), add="+")

        def save(_event=None):
            host, parsed_port = split_address(address.get())
            resolved_port = port.get().strip() or parsed_port
            if not host or any(char.isspace() for char in host):
                error.set("Enter a server address.")
                host_entry.focus_set()
                return "break"
            if not resolved_port.isascii() or not resolved_port.isdecimal() or len(resolved_port) > 5 or not 0 < int(resolved_port) <= 65535:
                error.set("Enter a port from 1 to 65535.")
                port_entry.focus_set()
                return "break"
            self._close_form()
            self._save_favorite({**server, "ip": host, "port": str(int(resolved_port)), "name": name.get().strip() or host})
            return "break"

        actions = frame(body)
        actions.pack(fill="x", pady=(4, 0))
        cancel = button(actions, "Cancel", self._close_form, compact=True)
        submit = button(actions, "Save server", save, primary=True, compact=True)
        for control, side in ((cancel, "left"), (submit, "right")):
            control.configure(font=(UI, 9, "bold"), padx=7)
            control.pack(side=side)
        for entry in (host_entry, port_entry, name_entry):
            entry.bind("<Return>", save)
        (name_entry if server else host_entry).focus_set()


class _PageList:
    """Let the dashboard scroll the list instead of adding a nested viewport."""

    def __init__(self, parent, bg):
        self.shell = self.body = tk.Frame(parent, bg=bg)


class AddonsPage(tk.Frame):
    _build = addon_manager_window.AddonManagerWindow._build
    _on_save = addon_manager_window.AddonManagerWindow._on_save
    _add_result = getattr(addon_manager_window.AddonManagerWindow, "_add_result", None)

    def __init__(self, parent, launcher):
        super().__init__(parent, bg=parent.cget("bg"))
        self._addon_loader = addon_loader
        self._app_label = "Client"
        self._get_game_dir = launcher._current_game_dir
        self._vars = {}
        self._resize_id = None
        stock_list = getattr(addon_manager_window, "ScrollArea", None)
        try:
            if stock_list is not None:
                # Newer builds make their own ScrollArea and bind its callbacks
                # on the containing window. The dashboard supplies both here.
                addon_manager_window.ScrollArea = _PageList
            self._build()
        finally:
            if stock_list is not None:
                addon_manager_window.ScrollArea = stock_list
        _remove_window_header(self)

        self._labels = []
        pending = list(self.winfo_children())
        while pending:
            widget = pending.pop()
            pending.extend(widget.winfo_children())
            if isinstance(widget, tk.Label):
                self._labels.append((widget, int(widget.cget("wraplength"))))

        dashboard = getattr(launcher, "_launcher_overhaul", None)
        self._viewport = dashboard.pane.canvas if dashboard is not None else parent
        self._resize_id = self._viewport.bind("<Configure>", self._wrap_labels, add="+")
        self._wrap_labels()

    def _wrap_labels(self, event=None):
        if self._viewport.winfo_width() <= 1:
            return
        # Allow for the dashboard's gutter, stock list padding and checkbox.
        width = max(180, self._viewport.winfo_width() - 96)
        for label, stock_wrap in self._labels:
            wrap = min(stock_wrap, width) if stock_wrap else width
            if int(label.cget("wraplength")) != wrap:
                label.configure(wraplength=wrap)

    def destroy(self):
        if self._resize_id is not None:
            try:
                self._viewport.unbind("<Configure>", self._resize_id)
            except tk.TclError:
                pass
        super().destroy()
