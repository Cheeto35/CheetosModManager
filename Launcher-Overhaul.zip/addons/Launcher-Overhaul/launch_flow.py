"""Surface launcher activity without replacing the game's join or authentication flow."""

import os
import queue
import threading
from dataclasses import dataclass

from client.core import launcher_window as stock


@dataclass(frozen=True)
class LaunchStatus:
    title: str
    detail: str = ""
    tone: str = "SECONDARY"
    remedy: str = ""
    error: str = ""


class LaunchFlow:
    def __init__(self, root, changed, target, launched):
        self.root = root
        self.changed = changed
        self.target = target
        self.launched = launched
        self.mode = None
        self.status = None
        self.busy = False
        self.depth = 0
        self.destination = None
        self.archive_callbacks = None

    def _set(self, title, detail="", tone="SECONDARY", remedy="", error=""):
        self.status = LaunchStatus(title, detail, tone, remedy, error)
        self.changed()

    def _begin(self, mode):
        if self.busy:
            return False
        self.mode = mode
        self.destination = self.target() if mode == "join" else None
        self.busy = True
        return True

    def _validation(self):
        exe = self.root.v_exe.get().strip()
        if not os.path.isfile(exe):
            self.fail("Choose the game executable in Setup & Tools.", "setup", "Game setup needed")
            return False
        if self.mode == "patch":
            return True
        name = self.root.v_username.get().strip()
        if not name:
            self.fail("Enter the name you use in game.", "player", "Player name needed")
            return False
        if len(name) > stock.USERNAME_MAX_LEN:
            self.fail(f"Use at most {stock.USERNAME_MAX_LEN} characters.", "player", "Player name is too long")
            return False
        if not stock._is_valid_username(name):
            self.fail("Use letters, numbers, spaces, hyphens, or underscores.", "player", "Check the player name")
            return False
        return True

    def stage(self, title, detail=""):
        if self.busy:
            self._set(title, detail, "PANEL_ACCENT")
            self.root.update_idletasks()

    def fail(self, error, remedy="retry", title="Couldn’t start the game"):
        self.busy = False
        # Keep long exceptions copyable without expanding the fixed action area.
        first_line = next((line.strip() for line in error.splitlines() if line.strip()), title)
        self._set(title, first_line[:190] + ("…" if len(first_line) > 190 else ""),
                  "STATUS_ERROR", remedy, error)

    def request_join(self, call):
        if not self._begin("join") or not self._validation():
            return
        self.stage("Preparing to join", "Archiving the previous game log.")
        try:
            return call()
        except Exception as exc:
            self.fail(str(exc))
            raise

    def archive(self, on_done):
        if self.archive_callbacks is not None:
            self.archive_callbacks.append(on_done)
            return
        self.archive_callbacks = [on_done]
        results = queue.SimpleQueue()

        def worker():
            try:
                self.root._tailer.stop_and_wait(timeout=2)
                result = stock.archive_log_now(stock.GAME_LOG_PATH)
            except Exception as exc:
                result = False, str(exc) or "The game log could not be archived.", False
            results.put(result)

        def receive():
            try:
                result = results.get_nowait()
            except queue.Empty:
                self.root.after(50, receive)
                return
            callbacks, self.archive_callbacks = self.archive_callbacks, None
            try:
                self.root._start_log_tailer()
            finally:
                for callback in callbacks:
                    self.root.after(0, callback, *result)

        threading.Thread(target=worker, daemon=True).start()
        self.root.after(50, receive)

    def launch(self, mode, call):
        if self.busy:
            if self.mode != mode:
                return
        elif not self._begin(mode) or not self._validation():
            return
        if mode == "join":
            self.destination = self.target()
        self.depth += 1
        self.stage("Preparing the game")
        try:
            return call()
        except Exception as exc:
            self.fail(str(exc))
            raise
        finally:
            self.depth -= 1
            if not self.depth and self.busy:
                self.busy = False
                self._set("Launch stopped", "The game did not start.", "STATUS_WARNING", "retry")

    def observe(self, message, tag):
        if not isinstance(message, str) or not self.busy or self.mode not in ("join", "menu") or not self.depth:
            return
        success_prefix = "Game running (PID " if self.mode == "join" else "Menu running (PID "
        if tag == "ok" and message.startswith(success_prefix):
            self.busy = False
            warning = ""
            if self.mode == "join" and (target := self.target()) is not None:
                self.destination = target
                try:
                    self.launched(target)
                except (OSError, ValueError):
                    warning = "The game started. The Continue Playing shortcut could not be saved."
            self._set("Game started", warning, "STATUS_OK")
        elif message.startswith(("Launch failed: ", "Menu launch failed: ", "Rejected: ")):
            error = message.partition(": ")[2]
            if error.startswith("Launch cancelled"):
                self.busy = False
                self._set("Launch cancelled", error, "STATUS_WARNING", "retry")
            else:
                self.fail(error)
        elif message.startswith("Launch stopped: "):
            self.busy = False
            self._set("Launch stopped", message.partition(": ")[2], "STATUS_WARNING", "retry")
        elif message.startswith("Authenticating "):
            self.stage("Connecting to the server", "Waiting for the server to verify your player name.")
        elif message.startswith("No official auth service"):
            self.stage("Checking server type", "Looking up the selected server in Community Servers.")
        elif message.startswith("Welcomed as "):
            self.stage("Server accepted", "Preparing the game's launch files.")
        elif message.startswith("Launching"):
            self.stage("Starting the game")

    def patch(self):
        if not self._begin("patch") or not self._validation():
            return
        exe = self.root.v_exe.get().strip()
        results = queue.SimpleQueue()
        self.stage("Applying game patch", "Checking for the latest patch and updating the game files.")

        def worker():
            try:
                results.put((stock.apply_patch(exe), ""))
            except Exception as exc:
                results.put((None, str(exc) or "The game patch could not be applied."))

        def receive():
            try:
                result, error = results.get_nowait()
            except queue.Empty:
                self.root.after(50, receive)
                return
            if error:
                self.fail(error, title="Patch failed")
                return
            details = {"downloaded": "The latest patch was applied.",
                       "bundled": "The bundled patch was applied.",
                       "current": "Your game files are already up to date."}
            self.busy = False
            self._set("Game patch ready", details.get(result, "The game files were patched."), "STATUS_OK")
            if self.root.v_exe.get().strip() == exe:
                self.root._refresh_patch_alert(exe)

        threading.Thread(target=worker, daemon=True).start()
        self.root.after(50, receive)
