"""Recent and pinned destinations on the Play page."""

import tkinter as tk

from .library_pages import server_address
from .widgets import BORDER, DISPLAY, SECONDARY, SURF, SURF2, UI, button, frame, label, styles


def _fit_two_lines(widget, text, width, *, preserve_end=False):
    font = widget.cget("font")
    limit = width * 2

    def fits(value):
        return int(widget.tk.call("font", "measure", font, value)) <= limit

    if fits(text):
        return text

    def shortened(count):
        tail = count // 3 if preserve_end else 0
        return text[:count - tail] + "…" + text[len(text) - tail:]

    low, high = 0, len(text) - 1
    while low < high:
        middle = (low + high + 1) // 2
        if fits(shortened(middle)):
            low = middle
        else:
            high = middle - 1
    return shortened(low)


class _ActionRow:
    def __init__(self, parent, caption, command, *, heading=False, unpin=None):
        self.frame = frame(parent)
        self.frame.columnconfigure(0, weight=1)
        self._text = frame(self.frame)
        self._text.grid(row=0, column=0, sticky="ew")
        self.title = label(self._text, size=14 if heading else 11, family=DISPLAY if heading else UI,
                           weight="bold", width=1, wraplength=180, justify="left")
        self.title.pack(fill="x")
        self.detail = label(self._text, color=SECONDARY, size=9, width=1, wraplength=180, justify="left")
        self._actions = frame(self.frame)
        self._actions.grid(row=0, column=1, padx=(12, 0), sticky="e")
        self._actions.columnconfigure(0, weight=1)
        self.action = button(self._actions, caption, command, compact=True)
        self.action.grid(row=0, column=0, sticky="ew")
        self.unpin_button = None
        if unpin is not None:
            self.unpin_button = button(self._actions, "Unpin", unpin, compact=True)
            styles(self.unpin_button).bind(self.unpin_button, bg=SURF, fg=SECONDARY,
                                           activebackground=SURF2, activeforeground="SURF2_TEXT")
            self.unpin_button.configure(font=(UI, 9))
            self.unpin_button.grid(row=0, column=1, padx=(5, 0))
        for control in self.controls():
            for key in ("<Return>", "<KP_Enter>"):
                control.bind(key, self._invoke)
        self._stacked = None
        self._wrap_width = 180
        self._title = ""
        self._detail = ""
        self.frame.bind("<Configure>", self._layout)
        self._text.bind("<Configure>", self._wrap)

    def controls(self):
        return (self.action, self.unpin_button) if self.unpin_button is not None else (self.action,)

    @staticmethod
    def _invoke(event):
        event.widget.invoke()
        return "break"

    def set_text(self, title, detail):
        self._title, self._detail = title, detail
        self._show_text()
        if detail:
            self.detail.pack(fill="x", pady=(2, 0))
        else:
            self.detail.pack_forget()

    def _layout(self, event):
        stacked = event.width < self._actions.winfo_reqwidth() + 120
        if stacked == self._stacked:
            return
        self._stacked = stacked
        self._actions.grid(row=int(stacked), column=int(not stacked), sticky="ew" if stacked else "e",
                           padx=0 if stacked else (12, 0), pady=(7, 0) if stacked else 0)

    def _wrap(self, event):
        width = max(1, event.width - 4)
        if width != self._wrap_width:
            self._wrap_width = width
            self._show_text()

    def _show_text(self):
        width = self._wrap_width
        self.title.configure(wraplength=width, text=_fit_two_lines(self.title, self._title, width))
        self.detail.configure(wraplength=width,
                              text=_fit_two_lines(self.detail, self._detail, width, preserve_end=True))


class LaunchCenter(tk.Frame):
    def __init__(self, parent, on_continue, on_pinned, on_open_saved, *, on_unpin=None):
        super().__init__(parent, highlightthickness=1)
        styles(self).bind(self, bg=SURF, highlightbackground=BORDER)
        self.on_continue = on_continue
        self.on_pinned = on_pinned
        self.on_unpin = on_unpin
        self._last = None
        self._pins = None
        self._pin_rows = []
        self._body = frame(self)
        self._body.pack(fill="x", padx=16, pady=11)

        self._continue = frame(self._body)
        label(self._continue, "Continue playing", size=14, family=DISPLAY, weight="bold",
              wraplength=225, justify="left").pack(fill="x")
        self._empty_continue = label(self._continue, "Join a server to see it here.", color=SECONDARY,
                                     size=9, wraplength=190, justify="left")
        self._last_row = _ActionRow(self._continue, "Join", self._join_last)
        self.join_button = self._last_row.action
        self._divider = frame(self._body, BORDER, height=1)
        self._shortcuts = _ActionRow(self._body, "Saved & recent", on_open_saved, heading=True)
        self._shortcuts.frame.pack(fill="x")
        self.saved_button = self._shortcuts.action
        self._list = frame(self._body)
        self.render(None, ())

    def render(self, last, pins, busy=False):
        """Show the last launched target and the current pins."""
        pins = tuple(pins)
        if last != self._last or pins != self._pins:
            has_targets = last is not None or bool(pins)
            self._body.pack_configure(pady=11 if has_targets else 8)
            self._render_last(last, has_targets)
            self._render_pins(pins, has_targets)
            self._last, self._pins = last, pins

        state = "disabled" if busy else "normal"
        self.join_button.configure(state=state)
        for row in self._pin_rows:
            for control in row.controls():
                control.configure(state=state)

    def _render_last(self, last, has_targets):
        if not has_targets:
            self._continue.pack_forget()
            self._divider.pack_forget()
            return
        self._continue.pack(fill="x", before=self._shortcuts.frame)
        self._divider.pack(fill="x", before=self._shortcuts.frame, pady=(10, 9))
        if last is None:
            self._last_row.frame.pack_forget()
            self._empty_continue.pack(fill="x", pady=(4, 0))
        else:
            self._empty_continue.pack_forget()
            self._last_row.set_text(*self._describe(last, platform=last.platform))
            self._last_row.frame.pack(fill="x", pady=(4, 0))

    def _render_pins(self, pins, has_targets):
        if has_targets:
            self._shortcuts.set_text("Pinned servers", "" if pins else "Pin a server to join it from Play.")
        else:
            self._shortcuts.set_text("Continue playing", "Your last server appears here after you join.")
        if pins == self._pins:
            return
        focused = self._focused_pin_control()
        for row in self._pin_rows:
            row.frame.destroy()
        self._pin_rows.clear()
        for record in pins:
            unpin = (lambda record=record: self.on_unpin(record)) if self.on_unpin is not None else None
            row = _ActionRow(self._list, "Join", lambda record=record: self.on_pinned(record), unpin=unpin)
            row.set_text(*self._describe(record))
            row.frame.pack(fill="x", pady=(6, 0))
            self._pin_rows.append(row)
        if pins:
            self._list.pack(fill="x")
        else:
            self._list.pack_forget()
        if focused is not None:
            index, control = focused
            next_control = (self._pin_rows[min(index, len(self._pin_rows) - 1)].controls()[control]
                            if self._pin_rows else self.saved_button)
            next_control.focus_set()

    def _focused_pin_control(self):
        try:
            focused = self.focus_get()
        except KeyError:
            return None
        for index, row in enumerate(self._pin_rows):
            if focused in row.controls():
                return index, row.controls().index(focused)

    @staticmethod
    def _describe(record, platform=None):
        address = server_address(record.host, record.port)
        title = record.label or address
        detail = "  ·  ".join(value for value in (platform, address if title != address else "") if value)
        return title, detail

    def _join_last(self):
        if self._last is not None:
            self.on_continue(self._last)
