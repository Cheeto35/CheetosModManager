"""Embed the launcher's server tools and keep their console work on the right thread."""

import queue
import threading
import tkinter as tk

from client.core.tavernkeeper.registry import registry
from client.core.tavernkeeper.window import TavernKeeperWindow
from tavern_shared.reorder_dialog import ReorderDialog
from tavern_shared.theme import BG
from tavern_shared.ws_console_client import WsConsoleClient

from .widgets import SECONDARY, SURF, button, card, frame, label, scrollbar, text_field


class TavernKeeperPage(tk.Frame):
    def __init__(self, parent, launcher, open_detail, back):
        super().__init__(parent, bg=BG)
        self._launcher = launcher
        self._open_detail = open_detail
        self._back = back
        self._ws_client = None
        self._connected = False
        self._stop = threading.Event()
        self._prefab_list = None
        self._save_items = []
        self._callbacks = queue.SimpleQueue()
        self._jobs = set()
        self._build_connect_form()
        self.after(40, self._service_callbacks)

    def _build_connect_form(self):
        self.v_host = tk.StringVar(self, value=self._launcher.v_ip.get().strip())
        self.v_token = tk.StringVar(self)
        self._connect_status = tk.StringVar(self)
        panel, inner = card(self, "Server connection")
        panel.pack(fill="x")
        label(inner, "Use the server address and a console token from the server owner.",
              size=9, color=SECONDARY, wraplength=240, justify="left").pack(fill="x", pady=(6, 9))
        host_field, host = text_field(inner, "Server address", self.v_host)
        host_field.pack(fill="x", pady=(0, 7))
        token_field, token = text_field(inner, "Console token", self.v_token)
        token.configure(show="●")
        token_field.pack(fill="x")
        label(inner, textvariable=self._connect_status, size=9, color="STATUS_ERROR",
              wraplength=240, justify="left").pack(fill="x", pady=(5, 0))
        self._connect_btn = button(inner, "Connect", self._attempt_connect, primary=True)
        self._connect_btn.pack(fill="x", pady=(7, 0))
        host.bind("<Return>", lambda event: token.focus_set())
        token.bind("<Return>", lambda event: self._attempt_connect())

    def __getattr__(self, name):
        # The stock tool's callbacks operate on widgets and state owned by this page.
        members = vars(TavernKeeperWindow)
        if name.startswith("_") and not name.startswith("__") and name in members:
            member = members[name]
            return member.__get__(self, type(self)) if hasattr(member, "__get__") else member
        raise AttributeError(name)

    def geometry(self, _size):
        """The dashboard owns window geometry."""

    def minsize(self, _width, _height):
        """The dashboard's viewport scrolls when the window is small."""

    def after(self, delay, callback=None, *args):
        if callback is None:
            return super().after(delay)

        def run():
            self._jobs.discard(job)
            callback(*args)

        job = super().after(delay, run)
        self._jobs.add(job)
        return job

    def after_cancel(self, job):
        self._jobs.discard(job)
        super().after_cancel(job)

    def _post(self, callback):
        self._callbacks.put(callback)

    def _service_callbacks(self):
        try:
            for _ in range(50):
                if self._stop.is_set():
                    return
                try:
                    callback = self._callbacks.get_nowait()
                except queue.Empty:
                    return
                callback()
        finally:
            if not self._stop.is_set():
                self.after(40, self._service_callbacks)

    def _attempt_connect(self):
        host = self.v_host.get().strip() or "127.0.0.1"
        token = self.v_token.get().strip()
        if not token:
            self._connect_status.set("Enter the console token.")
            return
        if str(self._connect_btn.cget("state")) == "disabled":
            return
        self._connect_btn.configure(state="disabled", text="Connecting…")
        self._connect_status.set("")
        client = self._ws_client = WsConsoleClient()

        def deliver(callback, *args):
            def current():
                if self._ws_client is client:
                    callback(*args)
            self._post(current)

        def connected():
            self._connected = client._connected
            if self._connected:
                self._connect_succeeded()
            else:
                self._connect_failed("The console disconnected. Try connecting again.")

        def worker():
            ok, message = client.connect(
                host, token, on_line=lambda text: deliver(self._on_line, text),
                on_disc=lambda reason: deliver(self._on_disconnected, reason))
            if self._stop.is_set():
                client.disconnect()
            elif ok:
                deliver(connected)
            else:
                deliver(self._connect_failed, message)

        threading.Thread(target=worker, daemon=True).start()

    def _on_line(self, text):
        if hasattr(self, "out"):
            TavernKeeperWindow._on_line(self, text)

    def _send_and_capture(self, command, on_result, quiet=0.4, max_wait=20.0):
        if not self._connected:
            self.after(0, on_result, None, None)
            return
        self._append_log(f"> {command}\n", "cyan")
        client = self._ws_client

        def worker():
            result, data, _ = client.send_capture(command, timeout=max_wait)
            self._post(lambda: on_result(result, data))

        threading.Thread(target=worker, daemon=True).start()

    def _open_reorder_tabs(self):
        self._open_detail("Reorder TavernKeeper tabs", lambda parent: _ReorderPage(
            parent, registry(), self._rebuild_tabs, self._back), self.focus_get())

    def _show_prefab_picker(self, target_var):
        def build(parent):
            panel, inner = card(parent, "Find a prefab")
            search = tk.StringVar(panel)
            search_row = frame(inner, SURF)
            search_row.pack(fill="x", pady=(8, 5))
            field, _ = text_field(search_row, "Search", search)
            field.pack(side="left", fill="x", expand=True)

            def refresh_cache():
                self._back()
                self._fetch_prefab_list(target_var)

            button(search_row, "Refresh", refresh_cache, compact=True).pack(side="right", padx=(8, 0))
            count = label(inner)
            count.pack(fill="x", pady=(4, 8))
            results = frame(inner, SURF)
            results.pack(fill="both", expand=True)
            listing = tk.Listbox(results, width=12, height=15, exportselection=False, activestyle="none")
            bar = scrollbar(results, listing.yview)
            listing.configure(yscrollcommand=bar.set)
            bar.pack(side="right", fill="y")
            listing.pack(side="left", fill="both", expand=True)
            matches = []

            def filter_results(*_):
                query = search.get().strip().lower()
                matches[:] = [(key, name) for key, name in self._prefab_list
                              if query in name.lower() or query == str(key)]
                listing.delete(0, "end")
                for key, name in matches[:500]:
                    listing.insert("end", f"{name}   [{key}]")
                suffix = " (showing first 500)" if len(matches) > 500 else ""
                count.configure(text=f"{len(matches)} results{suffix}")

            def use_selected(_event=None):
                selected = listing.curselection()
                if selected:
                    target_var.set(str(matches[selected[0]][0]))
                    self._back()

            search.trace_add("write", filter_results)
            listing.bind("<Double-Button-1>", use_selected)
            listing.bind("<Return>", use_selected)
            button(inner, "Use selected", use_selected, primary=True).pack(anchor="e", pady=(8, 0))
            filter_results()
            return panel

        self._open_detail("Browse prefabs", build, self.focus_get())

    def destroy(self):
        self._stop.set()
        for job in tuple(self._jobs):
            self.after_cancel(job)
        if self._ws_client is not None:
            threading.Thread(target=self._ws_client.disconnect, daemon=True).start()
        super().destroy()


class _ReorderPage(tk.Frame):
    _build = ReorderDialog._build
    _move = ReorderDialog._move
    _refresh_listbox = ReorderDialog._refresh_listbox

    def __init__(self, parent, tabs, on_saved, back):
        super().__init__(parent, bg=BG)
        self._registry = tabs
        self._on_saved = on_saved
        self._back = back
        self._title_text = "Tab order"
        self._keys = [item["key"] for item in tabs.ordered_items()]
        self._labels = {item["key"]: item.get("label", item["key"]) for item in tabs.all_items()}
        self._build()

    def _save(self):
        self._registry.save_order(self._keys)
        self._on_saved()
        self._back()
