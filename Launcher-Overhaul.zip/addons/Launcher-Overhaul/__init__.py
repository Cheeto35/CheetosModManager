"""TavernLauncher Overhaul."""
