"""Local Continue Playing and pinned server data."""

from dataclasses import asdict, dataclass, replace
import ipaddress
import json
import os
from pathlib import Path
import re
import tempfile
from threading import Lock
import unicodedata

from client.core.config import PLATFORM_DISPLAY_TO_BACKEND, PLATFORM_LEGACY_TO_DISPLAY
from tavern_shared.paths import _tavern_data_dir


DEFAULT_PORT = "1757"
_LABEL_LIMIT = 96
_HOST_CHARS = re.compile(r"[\w.-]+")
_PLATFORMS = {name.casefold(): name for name in PLATFORM_DISPLAY_TO_BACKEND}
_PLATFORMS.update({backend.casefold(): name for name, backend in PLATFORM_DISPLAY_TO_BACKEND.items()})
_PLATFORMS.update({legacy.casefold(): name for legacy, name in PLATFORM_LEGACY_TO_DISPLAY.items()})
_PLATFORMS["none"] = "Fly"
_WRITE_LOCK = Lock()


def _host(value):
    if not isinstance(value, str):
        raise ValueError("Enter the server hostname or IP address.")
    host = value.strip()
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    if ":" in host:
        base, separator, scope = host.partition("%")
        if separator and (not scope or not _HOST_CHARS.fullmatch(scope)):
            raise ValueError("Enter a valid IPv6 scope.")
        try:
            address = ipaddress.IPv6Address(base).compressed
        except ipaddress.AddressValueError:
            raise ValueError("Enter the server hostname or IP address.") from None
        return address + (f"%{scope}" if separator else "")
    if not host or len(host) > 253 or not _HOST_CHARS.fullmatch(host) or not host.strip(".-"):
        raise ValueError("Enter the server hostname or IP address.")
    return host


def _port(value):
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ValueError("Enter a port from 1 to 65535.")
    text = str(value).strip()
    if len(text) > 5 or not text.isascii() or not text.isdecimal() or not 1 <= int(text) <= 65535:
        raise ValueError("Enter a port from 1 to 65535.")
    return str(int(text))


def _label(value):
    if not isinstance(value, str):
        return None
    # Plain server names may be Unicode. Strip control and bidi formatting
    # characters so that a name cannot obscure the separate address text.
    plain = "".join(char for char in value if unicodedata.category(char) not in {"Cc", "Cf", "Cs"})
    return " ".join(plain.split())[:_LABEL_LIMIT] or None


@dataclass(frozen=True)
class LaunchTarget:
    host: str
    port: str
    kind: str
    platform: str | None = None
    label: str | None = None

    def __post_init__(self):
        kind = self.kind.strip().casefold() if isinstance(self.kind, str) else None
        if kind == "join":
            kind = "official"
        if kind not in ("official", "headless"):
            raise ValueError("Choose a server type.")
        platform = _PLATFORMS.get(self.platform.strip().casefold()) if isinstance(self.platform, str) else None
        object.__setattr__(self, "host", _host(self.host))
        object.__setattr__(self, "port", _port(self.port))
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "platform", platform)
        object.__setattr__(self, "label", _label(self.label))

    @property
    def key(self):
        return self.host.rstrip(".").casefold(), self.port, self.kind


@dataclass(frozen=True)
class LaunchHistory:
    last_launch: LaunchTarget | None = None
    pins: tuple[LaunchTarget, ...] = ()


def saved_target(server):
    """Accept stock favorites, which stored address/name with an optional port."""
    if not isinstance(server, dict):
        return None
    try:
        return LaunchTarget(
            host=server.get("ip") or server.get("host"),
            port=server.get("port") or DEFAULT_PORT,
            kind=server.get("kind", "official"),
            platform=server.get("platform"),
            label=server.get("name") or server.get("label"),
        )
    except ValueError:
        return None


def _history_file():
    return Path(_tavern_data_dir()) / "launcher_overhaul_launch_history.json"


def _read_target(value):
    if not isinstance(value, dict):
        return None
    try:
        return LaunchTarget(value.get("host"), value.get("port"), value.get("kind"),
                            value.get("platform"), value.get("label"))
    except ValueError:
        return None


def load_history():
    try:
        data = json.loads(_history_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return LaunchHistory()
    if not isinstance(data, dict):
        return LaunchHistory()
    last_launch = _read_target(data.get("last_launch"))
    if last_launch is not None and last_launch.platform is None:
        last_launch = None
    pins = {}
    values = data.get("pins")
    if isinstance(values, list):
        for value in values:
            target = _read_target(value)
            if target is not None:
                pins.setdefault(target.key, target)
    return LaunchHistory(last_launch, tuple(pins.values()))


def _save_history(history):
    destination = _history_file()
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=destination.parent,
                                         prefix="launch-history-", suffix=".tmp", delete=False) as output:
            temporary = Path(output.name)
            json.dump(asdict(history), output, indent=2, ensure_ascii=False)
            output.write("\n")
        os.replace(temporary, destination)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return history


def record_launch(target):
    """Remember a successful join; callers verify that its process started."""
    if target.platform is None:
        raise ValueError("A launch needs a known play mode.")
    with _WRITE_LOCK:
        history = load_history()
        if history.last_launch == target:
            return history
        return _save_history(replace(history, last_launch=target))


def _set_pin(history, target, pinned):
    existing = next((pin for pin in history.pins if pin.key == target.key), None)
    if pinned:
        if existing is not None:
            return history
        pins = (*history.pins, target)
    elif existing is not None:
        pins = tuple(pin for pin in history.pins if pin.key != target.key)
    else:
        return history
    return _save_history(replace(history, pins=pins))


def set_pinned(target, pinned):
    with _WRITE_LOCK:
        return _set_pin(load_history(), target, pinned)


def toggle_pin(target):
    with _WRITE_LOCK:
        history = load_history()
        return _set_pin(history, target, not any(pin.key == target.key for pin in history.pins))
