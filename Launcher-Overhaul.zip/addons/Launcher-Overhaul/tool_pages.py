"""Embed the launcher's remote console, support tickets, and mod tools."""

import os
import threading
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

from client.core import remote_console, tickets_window as tickets
from tavern_shared import mods_window as mods
from tavern_shared.theme import BG

from .library_pages import SavedServersPage, _remove_window_header
from .widgets import BORDER, FIELD, SECONDARY, SURF, button, card, frame, label, scrollbar, styles, text_field


def _wrap(widget, width):
    if int(widget.cget("wraplength")) != width:
        widget.configure(wraplength=width)


class _ToolPage(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=BG)
        self._owner = self.winfo_toplevel()
        self._ui_thread = threading.get_ident()
        self._closed = False
        self._viewport_bind = None

    def _track_viewport(self, launcher, reflow):
        dashboard = getattr(launcher, "_launcher_overhaul", None)
        self._viewport = dashboard.pane.canvas if dashboard is not None else self.master
        self._viewport_bind = self._viewport.bind("<Configure>", reflow, add="+")
        reflow()

    def _page_width(self):
        width = self._viewport.winfo_width()
        return max(275, width - 36) if width > 1 else 300

    def after(self, delay, callback=None, *args):
        if callback is None or threading.get_ident() == self._ui_thread:
            return super().after(delay, callback, *args)
        if self._closed:
            return None

        def deliver():
            if not self._closed:
                callback(*args)

        # The owner outlives the panel. Scheduling on the panel would leave
        # a timer pointing at a deleted Tcl command after Back.
        try:
            return self._owner.after(delay, deliver)
        except (RuntimeError, tk.TclError):
            return None

    def destroy(self):
        self._closed = True
        if self._viewport_bind is not None:
            self._viewport.unbind("<Configure>", self._viewport_bind)
        super().destroy()


class RemoteConsolePage(_ToolPage):
    _build_console_ui = remote_console.RemoteConsoleWindow._build_console_ui
    _append = remote_console.RemoteConsoleWindow._append
    _send = remote_console.RemoteConsoleWindow._send
    _on_disconnected = remote_console.RemoteConsoleWindow._on_disconnected

    def __init__(self, parent, launcher):
        super().__init__(parent)
        self._ws_client = None
        self._connected = False
        self._pending_lines = []
        self._early_disconnect = None
        self.v_host = tk.StringVar(self, launcher.v_ip.get().strip())
        self.v_token = tk.StringVar(self)
        self._connect_status = tk.StringVar(self)
        panel, content = card(self, "Server connection")
        panel.pack(fill="x")
        host, host_entry = text_field(content, "Server address", self.v_host)
        host.pack(fill="x", pady=(8, 6))
        token, token_entry = text_field(content, "Console token", self.v_token)
        token_entry.configure(show="●")
        token.pack(fill="x")
        label(content, "Ask the server owner for their console token.", size=9,
              color=SECONDARY, wraplength=240, justify="left").pack(fill="x", pady=(4, 8))
        label(content, textvariable=self._connect_status, size=9, color="STATUS_ERROR",
              wraplength=240, justify="left").pack(fill="x")
        self._connect_btn = button(content, "Connect", self._attempt_connect, primary=True)
        self._connect_btn.pack(fill="x", pady=(8, 0))
        host_entry.bind("<Return>", lambda event: token_entry.focus_set())
        token_entry.bind("<Return>", lambda event: self._attempt_connect())

    # The stock console builder sizes a standalone window. This panel fills
    # the dashboard and uses its viewport for narrow layouts.
    def geometry(self, _size):
        pass

    def minsize(self, _width, _height):
        pass

    def _attempt_connect(self):
        if self._connect_btn.cget("state") == "disabled":
            return
        host = self.v_host.get().strip() or "127.0.0.1"
        token = self.v_token.get().strip()
        if not token:
            self._connect_status.set("Enter the console token.")
            return
        self._connect_btn.configure(state="disabled", text="Connecting…")
        self._connect_status.set("")
        self._pending_lines.clear()
        self._early_disconnect = None
        client = self._ws_client = remote_console.WsConsoleClient()

        def worker():
            try:
                ok, message = client.connect(
                    host, token, on_line=lambda line: self.after(0, self._receive, client, line),
                    on_disc=lambda reason: self.after(0, self._lost, client, reason))
            except Exception as error:
                ok, message = False, str(error)
            if self._closed:
                client.disconnect()
                return
            self.after(0, self._connection_result, client, host, ok, message)

        threading.Thread(target=worker, daemon=True).start()

    def _receive(self, client, line):
        if client is self._ws_client:
            if hasattr(self, "out"):
                self._append(line)
            elif len(self._pending_lines) < 250:
                self._pending_lines.append(line)

    def _lost(self, client, reason):
        if client is self._ws_client:
            if hasattr(self, "out"):
                self._on_disconnected(reason)
            else:
                self._early_disconnect = reason

    def _connection_result(self, client, host, ok, message):
        if client is not self._ws_client:
            return
        if not ok:
            self._ws_client = None
            self._connect_btn.configure(state="normal", text="Connect")
            self._connect_status.set(message)
            return
        self.v_token.set("")
        self._host = host
        self._connected = True
        for child in self.winfo_children():
            child.destroy()
        self._build_console_ui()
        _remove_window_header(self)
        log, actions = self.pack_slaves()[:2]
        context = frame(self, SURF, border=True)
        context.pack(fill="x", before=log, pady=(0, 5))
        label(context, host, size=9, wraplength=160, justify="left").pack(
            side="left", fill="x", expand=True, padx=9, pady=5)
        label(context, textvariable=self._status_var, size=8, color=SECONDARY).pack(
            side="right", padx=9, pady=5)
        for child in actions.pack_slaves():
            if isinstance(child, tk.Entry):
                child.configure(width=12)
        self.out.configure(width=21, height=14)
        self._append("[Connected]\n", "ok")
        for line in self._pending_lines:
            self._append(line)
        self._pending_lines.clear()
        if self._early_disconnect is not None:
            self._on_disconnected(self._early_disconnect)

    def destroy(self):
        client, self._ws_client = self._ws_client, None
        super().destroy()
        # Closing a websocket can wait for its peer. Keep Back responsive.
        if client is not None:
            threading.Thread(target=client.disconnect, daemon=True).start()


class TicketsPage(_ToolPage):
    _current_host_username = tickets.TicketsWindow._current_host_username
    _apply_tickets = tickets.TicketsWindow._apply_tickets
    _read_ticket = tickets.TicketsWindow._on_select
    _selected_ticket_id = tickets.TicketsWindow._selected_ticket_id

    def __init__(self, parent, launcher, pick_server=None):
        super().__init__(parent)
        self._pick_server = pick_server
        self._saved = None
        self._composer = None
        self._ticket_view = []
        self._tickets = []
        self._selected_ticket = None
        self._read_id = 0
        self._sending = False
        self._wide = None
        self._list_note = tk.StringVar(self)
        host, username, self._recent_hosts = tickets._get_last_ticket_state()
        self._build(host or launcher.v_ip.get().strip(), username or launcher.v_username.get().strip())
        self._track_viewport(launcher, self._reflow)
        for var in (self.v_host, self.v_username):
            var.trace_add("write", self._reset_account)
        self._reset_account()
        self._refresh(silent=True)

    def _build(self, host, username):
        account, content = card(self, "Ticket account")
        account.pack(fill="x", pady=(0, 12))
        self.v_host = tk.StringVar(self, host)
        self.v_username = tk.StringVar(self, username)
        self._account_fields = frame(content)
        self._account_fields.pack(fill="x", pady=(10, 0))
        self._server_field = frame(self._account_fields)
        self._server_field.columnconfigure(0, weight=1)
        label(self._server_field, "Server address", size=9, weight="bold", color=SECONDARY).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 5))
        self._host_input = ttk.Combobox(self._server_field, textvariable=self.v_host, values=self._recent_hosts,
                                        font=("Segoe UI", 10), style="Overhaul.TCombobox", width=5)
        self._host_input.grid(row=1, column=0, sticky="nsew")
        self._pick_button = button(self._server_field, "Pick saved", self._pick_saved_server, compact=True)
        self._pick_button.grid(row=1, column=1, sticky="nsew", padx=(6, 0))
        self._name_field, self._username_input = text_field(self._account_fields, "Username", self.v_username, size=10)
        self._account_actions = frame(self._account_fields)
        button(self._account_actions, "New ticket", self._new_ticket, primary=True, compact=True).pack(side="right")
        button(self._account_actions, "Refresh", self._refresh, compact=True).pack(side="right", padx=(0, 6))
        for action in self._account_actions.pack_slaves():
            action.configure(padx=8)
        for entry in (self._host_input, self._username_input):
            entry.bind("<Return>", lambda event: self._refresh())

        self._body = frame(self)
        self._body.pack(fill="x")
        self._list_card, list_content = card(self._body, "Your tickets")
        self._list_state = label(list_content, textvariable=self._list_note, color=SECONDARY,
                                 justify="left", wraplength=225)
        self._list_state.pack(fill="x", pady=(8, 2))
        self._tree_box = frame(list_content, FIELD, border=True)
        self.tree = ttk.Treeview(self._tree_box, columns=("title", "status", "updated"), show="headings",
                                 selectmode="browse", height=1, style="Overhaul.Treeview")
        for column, caption, width in (("title", "Subject", 104), ("status", "Status", 52), ("updated", "Updated", 104)):
            self.tree.heading(column, text=caption)
            self.tree.column(column, width=width, minwidth=width, stretch=column == "title")
        tree_scroll = scrollbar(self._tree_box, self.tree.yview)
        tree_scroll.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=tree_scroll.set)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Escape>", self._clear_selection)

        self._detail_card, detail = card(self._body, "Conversation")
        self._detail_empty = label(detail, "Select a ticket to read updates and reply.", color=SECONDARY,
                                   justify="left", wraplength=225)
        self._detail_empty.pack(fill="x", pady=(8, 2))
        self._detail_body = frame(detail)
        subject_row = frame(self._detail_body)
        subject_row.pack(fill="x", pady=(0, 8))
        self.v_detail_title = tk.StringVar(self)
        self._clear_button = button(subject_row, "Clear selection", self._clear_selection, compact=True)
        self._clear_button.pack(side="right", padx=(6, 0))
        self._subject = label(subject_row, textvariable=self.v_detail_title, weight="bold", justify="left", wraplength=144)
        self._subject.pack(side="left", fill="x", expand=True)
        thread = frame(self._detail_body, FIELD, border=True)
        thread.pack(fill="both", expand=True)
        self.thread_text = tk.Text(thread, width=16, height=5, state="disabled", wrap="word", relief="flat", bd=0,
                                   font=("Segoe UI", 10), padx=8, pady=6)
        styles(self.thread_text).bind(self.thread_text, bg=FIELD, fg="FIELD_TEXT", insertbackground="FIELD_TEXT",
                                      selectbackground="ACTIVE_TAB", selectforeground="ACTIVE_TEXT")
        for tag in ("owner", "player"):
            self.thread_text.tag_config(tag, font=("Segoe UI", 10, "bold"))
        thread_scroll = scrollbar(thread, self.thread_text.yview)
        thread_scroll.pack(side="right", fill="y")
        self.thread_text.configure(yscrollcommand=thread_scroll.set)
        self.thread_text.pack(fill="both", expand=True)

        self._reply_box = frame(self._detail_body)
        self.v_reply = tk.StringVar(self)
        reply_field, reply = text_field(self._reply_box, "Reply", self.v_reply, size=9)
        reply_field.pack(fill="x", pady=(0, 8))
        reply.bind("<Return>", lambda event: self._respond())
        actions = frame(self._reply_box)
        actions.pack(fill="x")
        button(actions, "Reply", self._respond, primary=True, compact=True).pack(side="right")
        button(actions, "Close ticket", self._close_ticket, compact=True).pack(side="left")

    def _reflow(self, _event=None):
        width = self._page_width()
        wide = width >= 740
        actions = self._account_actions.pack_slaves()
        field_height = max(widget.winfo_reqheight() for widget in
                           (self._pick_button, self._host_input, self._username_input, *actions))
        self._server_field.rowconfigure(1, minsize=field_height)
        for widget in (self._username_input, *actions):
            widget.pack_configure(ipady=(field_height - widget.winfo_reqheight()) // 2)
        if wide != self._wide:
            self._wide = wide
            self._host_input.configure(width=10 if wide else 5)
            self._clear_button.configure(text="Clear selection" if wide else "Clear")
            self._account_fields.columnconfigure(0, weight=3)
            self._account_fields.columnconfigure(1, weight=2 if wide else 0)
            self._server_field.grid(row=0, column=0, sticky="sew", padx=(0, 12 if wide else 0))
            self._name_field.grid(row=0 if wide else 1, column=1 if wide else 0, sticky="sew",
                                  padx=(0, 12 if wide else 0), pady=(0 if wide else 8, 0))
            self._account_actions.grid(row=0 if wide else 2, column=2 if wide else 0, sticky="se",
                                       pady=(0 if wide else 8, 0))
            self._body.columnconfigure(0, weight=4)
            self._body.columnconfigure(1, weight=5 if wide else 0)
            self._list_card.grid(row=0, column=0, sticky="nsew", padx=(0, 12 if wide else 0))
        list_width = int(width * .42) - 32 if wide else width - 32
        detail_width = int(width * .50) - 32 if wide else width - 32
        _wrap(self._list_state, max(190, width - 40 if not self._tickets else list_width))
        _wrap(self._detail_empty, max(190, detail_width))
        _wrap(self._subject, max(95, detail_width - self._clear_button.winfo_reqwidth() - 10))
        line_height = int(self.tk.call("font", "metrics", self.thread_text.cget("font"), "-linespace"))
        height = max(5, min(11 if wide else 7, self._viewport.winfo_height() // (3 * line_height)))
        if int(self.thread_text.cget("height")) != height:
            self.thread_text.configure(height=height)
        self._layout_tickets()

    def _layout_tickets(self):
        if self._tickets:
            self._list_state.pack_forget()
            rows = min(len(self._tickets), 8 if self._wide else 5)
            if int(self.tree.cget("height")) != rows:
                self.tree.configure(height=rows)
            if not self._tree_box.winfo_manager():
                self._tree_box.pack(fill="both", expand=True, pady=(8, 0))
            self._list_card.grid_configure(columnspan=1, padx=(0, 12 if self._wide else 0))
            self._detail_card.grid(row=0 if self._wide else 1, column=1 if self._wide else 0,
                                   sticky="nsew", pady=(0 if self._wide else 12, 0))
        else:
            self._tree_box.pack_forget()
            if not self._list_state.winfo_manager():
                self._list_state.pack(fill="x", pady=(8, 2))
            self._list_card.grid_configure(columnspan=2 if self._wide else 1, padx=0)
            self._detail_card.grid_remove()

    def _reset_account(self, *_):
        self._read_id += 1
        self._tickets = []
        self.tree.delete(*self.tree.get_children())
        ready = all(self._current_host_username(silent=True))
        self._list_note.set("Refresh to see tickets for this account." if ready else
                            "Choose a server and enter your username to see your tickets.")
        self._clear_selection()
        self._layout_tickets()

    def _clear_selection(self, event=None):
        if self._clear_button.focus_get() == self._clear_button:
            self.tree.focus_set()
        selected = self.tree.selection()
        if selected:
            self.tree.selection_remove(*selected)
        self._selected_ticket = None
        self.v_detail_title.set("")
        self.v_reply.set("")
        self.thread_text.configure(state="normal")
        self.thread_text.delete("1.0", "end")
        self.thread_text.configure(state="disabled")
        self._detail_body.pack_forget()
        if not self._detail_empty.winfo_manager():
            self._detail_empty.pack(fill="x", pady=(8, 2))
        if event is not None:
            return "break"

    def _on_select(self, event=None):
        previous = self._selected_ticket
        self._read_ticket(event)
        if self._selected_ticket is None:
            return
        if previous is not self._selected_ticket:
            self.v_reply.set("")
        self._detail_empty.pack_forget()
        if not self._detail_body.winfo_manager():
            self._detail_body.pack(fill="both", expand=True, pady=(8, 0))
        if self._selected_ticket.get("status") == "open":
            if not self._reply_box.winfo_manager():
                self._reply_box.pack(fill="x", pady=(8, 0))
        else:
            self._reply_box.pack_forget()

    def _pick_saved_server(self):
        def chosen(host, _name, _port="1757"):
            if not self._closed:
                self.v_host.set(host)
                self._refresh(silent=True)

        if self._pick_server is not None:
            self._pick_server(chosen)
            return
        if self._saved is not None and self._saved.winfo_exists():
            self._saved.destroy()
            return
        self._saved = SavedServersPage(self, chosen)
        for tabs in self._saved.pack_slaves():
            if isinstance(tabs, ttk.Notebook):
                for tab in tabs.winfo_children():
                    toolbar = tab.pack_slaves()[-1]
                    for action in toolbar.pack_slaves():
                        if isinstance(action, tk.Button):
                            caption = action.cget("text")
                            caption = {"+ Add IP": "Add IP", "✕ Remove": "Remove",
                                       "★ Save as Fav": "Favourite"}.get(caption, caption)
                            action.configure(text=caption, padx=6, font=("Segoe UI", 8))
        self._saved.bind("<Destroy>", self._closed_picker, add="+")
        self._pick_button.configure(text="Hide saved")
        self._saved.pack(fill="x", before=self._body, pady=(0, 12))

    def _closed_picker(self, event):
        if event.widget is self._saved and not self._closed:
            self._saved = None
            self._pick_button.configure(text="Pick saved")

    def _request(self, context, action, success, error, **payload):
        host, username = context

        def resolve():
            try:
                resolved = tickets._resolve_ip_for_game(host)
            except Exception as exc:
                self.after(0, error, str(exc))
                return
            self.after(0, authorize, resolved)

        def authorize(resolved):
            # Keep token file creation serialized with the launcher's other UI actions.
            try:
                token, _ = tickets._get_or_create_token(resolved, username)
            except Exception as exc:
                error(str(exc))
                return
            threading.Thread(target=send, args=(resolved, token), daemon=True).start()

        def send(resolved, token):
            try:
                response = tickets.ticket_request(resolved, action, username, token, **payload)
                if response.get("status") != "ok":
                    self.after(0, error, response.get("message", "Unknown error"))
                    return
            except Exception as exc:
                self.after(0, error, str(exc))
                return
            self.after(0, success, resolved, response)

        threading.Thread(target=resolve, daemon=True).start()

    def _refresh(self, silent=False):
        context = self._current_host_username(silent=silent)
        if not context[0]:
            return
        tickets._remember_ticket_state(*context)
        self._read_id += 1
        request_id = self._read_id
        self._list_note.set("Loading tickets…")

        def done(resolved, response):
            if request_id == self._read_id:
                self._clear_selection()
                self._apply_tickets(response.get("tickets", []), resolved)
                self._list_note.set("No tickets for this account yet. Use New ticket to ask the server for help.")
                self._layout_tickets()

        def error(message):
            if request_id == self._read_id:
                self._list_note.set("Couldn't load tickets. Check the server address and username, then refresh.")
                if not silent:
                    messagebox.showerror("Couldn't fetch tickets", message, parent=self)

        self._request(context, "list_mine", done, error)

    def _new_ticket(self):
        context = self._current_host_username()
        if not context[0] or self._composer is not None or self._sending:
            return
        self._ticket_view = [(child, child.pack_info()) for child in self.pack_slaves()]
        for child, _ in self._ticket_view:
            child.pack_forget()
        self._composer, content = card(self, "New ticket")
        self._composer.pack(fill="x")
        title = tk.StringVar(self)
        title_row, _entry = text_field(content, "Title", title)
        title_row.pack(fill="x", pady=(8, 7))
        label(content, "Description", size=9, weight="bold").pack(fill="x")
        description = tk.Text(content, width=18, height=6, wrap="word", relief="flat", padx=7, pady=6)
        styles(description).bind(description, bg=FIELD, fg="FIELD_TEXT", insertbackground="FIELD_TEXT")
        description.pack(fill="x", pady=(4, 8))
        status = tk.StringVar(self)
        label(content, textvariable=status, size=9, color="STATUS_ERROR",
              justify="left", wraplength=240).pack(fill="x")
        actions = frame(content)
        actions.pack(fill="x", pady=(6, 0))

        def submit():
            if self._sending:
                return
            subject = title.get().strip()
            body = description.get("1.0", "end").strip()
            if not subject or not body:
                status.set("Title and description are both required.")
                return
            save.configure(state="disabled")
            cancel.configure(state="disabled")
            status.set("")

            def done(_server, _response):
                self._sending = False
                self.go_back()
                self._refresh()

            def error(message):
                self._sending = False
                status.set(message)
                save.configure(state="normal")
                cancel.configure(state="normal")

            self._sending = True
            self._request(context, "create", done, error, title=subject, description=body, server=context[0])

        cancel = button(actions, "Cancel", self.go_back, compact=True)
        cancel.pack(side="left")
        save = button(actions, "Submit ticket", submit, primary=True, compact=True)
        save.pack(side="right")

    @property
    def busy(self):
        return self._sending

    def go_back(self):
        if self._sending:
            return True
        if self._composer is not None:
            self._composer.destroy()
            self._composer = None
            for child, options in self._ticket_view:
                if child.winfo_exists():
                    child.pack(**options)
            self._ticket_view = []
            return True
        if self._saved is not None:
            self._saved.destroy()
            return True
        return False

    def _change_ticket(self, action, **payload):
        context = self._current_host_username()
        if not context[0] or self._sending:
            return
        self._sending = True

        def done(_server, _response):
            self._sending = False
            self.v_reply.set("")
            self._refresh()

        def error(message):
            self._sending = False
            messagebox.showerror("Couldn't update the ticket", message, parent=self)

        self._request(context, action, done, error, **payload)

    def _respond(self):
        ticket_id = self._selected_ticket_id()
        message = self.v_reply.get().strip()
        if not ticket_id or not message:
            return
        if self._selected_ticket.get("status") != "open":
            messagebox.showinfo("Ticket closed", "This ticket is already closed.", parent=self)
            return
        self._change_ticket("respond", ticket_id=ticket_id, message=message)

    def _close_ticket(self):
        ticket_id = self._selected_ticket_id()
        if not ticket_id:
            return
        if self._selected_ticket.get("status") != "open":
            messagebox.showinfo("Already closed", "This ticket is already closed.", parent=self)
            return
        message = simpledialog.askstring("Close ticket", "Optional closing message", parent=self) or ""
        if messagebox.askyesno("Close ticket", "Close this ticket? It will be closed to replies.", parent=self):
            self._change_ticket("close", ticket_id=ticket_id, message=message)


class ModsPage(_ToolPage):
    _STATE_STYLE = mods.ModsWindow._STATE_STYLE
    _STATE_NOTE = mods.ModsWindow._STATE_NOTE
    _refresh_states = mods.ModsWindow._refresh_states
    _apply_states = mods.ModsWindow._apply_states
    _set_busy = mods.ModsWindow._set_busy
    _on_melonloader_click = mods.ModsWindow._on_melonloader_click
    _on_tavernlib_click = mods.ModsWindow._on_tavernlib_click
    _on_tavernessentials_click = mods.ModsWindow._on_tavernessentials_click
    _on_circuitsvoicechat_click = getattr(mods.ModsWindow, "_on_circuitsvoicechat_click", None)
    _on_tavernvoice_click = getattr(mods.ModsWindow, "_on_tavernvoice_click", None)
    _finish_install = mods.ModsWindow._finish_install

    def __init__(self, parent, launcher):
        super().__init__(parent)
        self._exe = launcher.v_exe.get().strip()
        self._game_dir = os.path.dirname(self._exe)
        self._busy = False
        self._on_status_change = launcher._refresh_mods_alert
        self._rows = []
        self._group_mode = None
        self._row_mode = None
        if not os.path.isfile(self._exe):
            panel, content = card(self, "Game executable required")
            panel.pack(fill="x")
            label(content, "Choose the game executable in Setup & Tools before managing mods.",
                  color=SECONDARY, wraplength=244, justify="left").pack(fill="x", pady=(6, 0))
            return
        self._build()
        self._track_viewport(launcher, self._reflow)
        self._refresh_states()

    def _build(self):
        self._hint = label(self, "Install MelonLoader before the other mods. The launcher can use bundled files "
                                 "if the update server is unavailable.",
                           color=SECONDARY, wraplength=230, justify="left")
        self._hint.pack(fill="x", pady=(0, 12))
        self._status = tk.StringVar(self)
        self._banner = frame(self, SURF, border=True)
        self._progress = label(self._banner, textvariable=self._status, weight="bold", size=9,
                               justify="left", wraplength=225)
        self._progress.pack(fill="x", padx=12, pady=8)

        self._groups = frame(self)
        self._groups.pack(fill="x")
        self._required, required = card(self._groups, "Required mods")
        self._ml_btn = self._mod_row(required, "MelonLoader", "Loads game mods.", self._on_melonloader_click)
        self._tl_btn = self._mod_row(required, "TavernLib", "Adds support for The Modding Tavern servers.",
                                     self._on_tavernlib_click, divider=True)

        self._optional, optional = card(self._groups, "Optional mods")
        self._group_headings = (required.pack_slaves()[0], optional.pack_slaves()[0])
        if self._on_tavernvoice_click is not None:
            self._tv_btn = self._mod_row(optional, "TavernVoice", "Proximity voice chat for players on this server.",
                                         self._on_tavernvoice_click)
        else:
            self._cvc_btn = self._mod_row(optional, "CircuitsVoiceChat", "Proximity voice chat for players on this server.",
                                          self._on_circuitsvoicechat_click)
        self._te_btn = self._mod_row(optional, "TavernEssentials",
                                     "Restores original main menu features and adds social features. Created by Shadow.",
                                     self._on_tavernessentials_click, divider=True)
        self._status.trace_add("write", self._show_progress)

    def _mod_row(self, parent, title, description, on_click, *, divider=False):
        if divider:
            frame(parent, BORDER, height=1).pack(fill="x", pady=(10, 0))
        row = frame(parent)
        row.pack(fill="x", pady=(10, 0))
        row.columnconfigure(0, weight=1)
        details = frame(row)
        details.grid(row=0, column=0, sticky="ew")
        label(details, title, weight="bold").pack(fill="x")
        copy = label(details, description, size=9, color=SECONDARY, wraplength=225, justify="left")
        copy.pack(fill="x", pady=(3, 0))
        note = label(details, size=9, color="STATUS_WARNING", wraplength=225, justify="left")

        controls = frame(row)
        state = label(controls, "Checking…", size=8, color=SECONDARY)
        action = button(controls, "…", on_click, compact=True)
        action.configure(width=10)
        action._state_label = state
        action._compat_note = note
        self._rows.append((details, copy, note, controls, state, action))
        return action

    def _apply_row_state(self, action, state):
        _, _, caption = self._STATE_STYLE[state]
        status, color = {
            "missing": ("Not installed", SECONDARY),
            "outdated": ("Update available", "STATUS_WARNING"),
            "unknown": ("Installed", SECONDARY),
            "replace": ("Replacement available", "STATUS_WARNING"),
            "current": ("Up to date", "STATUS_OK"),
        }[state]
        action.configure(text=caption)
        action._state_label.configure(text=status)
        styles(action).bind(action._state_label, fg=color)
        note = action._compat_note
        if state == "replace":
            note.configure(text=self._STATE_NOTE[state])
            if not note.winfo_manager():
                note.pack(fill="x", pady=(3, 0))
        else:
            note.pack_forget()

    def _show_progress(self, *_):
        if self._status.get():
            if not self._banner.winfo_manager():
                self._banner.pack(fill="x", before=self._groups, pady=(0, 12))
        else:
            self._banner.pack_forget()

    def _reflow(self, _event=None):
        width = self._page_width()
        side_by_side = width >= 760
        panel_width = (width - 12) // 2 if side_by_side else width
        action_width = max(action.winfo_reqwidth() for *_, action in self._rows)
        stacked = panel_width - 36 - action_width < 210
        if self._group_mode != side_by_side:
            self._group_mode = side_by_side
            self._groups.columnconfigure(0, weight=1, uniform="mod_group")
            self._groups.columnconfigure(1, weight=int(side_by_side), uniform="mod_group" if side_by_side else "")
            self._required.grid(row=0, column=0, sticky="nsew", padx=(0, 6 if side_by_side else 0))
            self._optional.grid(row=0 if side_by_side else 1, column=int(side_by_side), sticky="nsew",
                                padx=(6 if side_by_side else 0, 0),
                                pady=(0 if side_by_side else 12, 0))
        if self._row_mode != stacked:
            self._row_mode = stacked
            for details, _, _, controls, state, action in self._rows:
                controls.grid(row=int(stacked), column=int(not stacked), sticky="ew" if stacked else "e",
                              padx=(0 if stacked else 12, 0), pady=(7 if stacked else 0, 0))
                controls.columnconfigure(0, weight=int(stacked))
                state.grid(row=0, column=0, sticky="w" if stacked else "e", padx=(0, 6 if stacked else 0))
                action.grid(row=int(not stacked), column=int(stacked), sticky="e",
                            pady=(0 if stacked else 4, 0))
        _wrap(self._hint, width)
        _wrap(self._progress, max(190, width - 28))
        for heading in self._group_headings:
            _wrap(heading, max(180, panel_width - 36))
        for _, copy, note, _, state, _ in self._rows:
            rail = 0 if stacked else max(action_width, state.winfo_reqwidth()) + 12
            available = max(140, panel_width - 36 - rail)
            _wrap(copy, available)
            _wrap(note, available)

    @property
    def busy(self):
        return self._busy

    def _fit_height(self):
        self._reflow()
