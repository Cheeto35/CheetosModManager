"""Apply the launcher's palette to the legacy Tk views it opens."""

import tkinter as tk
from tkinter import ttk
from weakref import WeakSet

from tavern_shared import theme as stock

from .appearance import _ink, _readable


_SURFACES = {
    stock.BG: "BG", stock.SURF: "SURF", stock.SURF2: "SURF2", stock.BORDER: "BORDER",
    stock.AMBER: "AMBER", stock.AMBERDIM: "ACTIVE_TAB", stock.RED: "ALERT_SURFACE",
    "#3d2a0a": "AMBER", "#5a3d0e": "PRIMARY_HOVER", "#1f1713": "FIELD",
}
_MUTED = {stock.MUTED, "#b09a78", "#c0ad90", "#c2ae91"}
_ACCENTS = {stock.AMBER, stock.AMBERDIM, "#ffd080"}
_INK = {stock.PARCH, "#ffffff", "#000000", "black", "white"}
_INPUTS = {"Entry", "Spinbox", "Text", "Listbox", "TEntry", "TSpinbox", "TCombobox", "Treeview"}
_FOREGROUND_OPTIONS = {
    "foreground": "background", "activeforeground": "activebackground", "selectforeground": "selectbackground",
    "disabledforeground": "disabledbackground", "insertbackground": "background", "arrowcolor": "background",
}
_DEFAULT_SURFACES = {
    "selectbackground": "ACTIVE_TAB", "activebackground": "SECONDARY_HOVER", "disabledbackground": "FIELD",
    "readonlybackground": "FIELD", "fieldbackground": "FIELD", "troughcolor": "BG", "bordercolor": "BORDER",
    "highlightbackground": "BORDER", "highlightcolor": "FOCUS", "selectcolor": "FIELD",
    "lightcolor": "SURF2", "darkcolor": "SURF2",
}
_OPTIONS = _DEFAULT_SURFACES.keys() | _FOREGROUND_OPTIONS.keys() | {"background"}
_ALIASES = {"bg": "background", "fg": "foreground"}
_TTK_OPTIONS = {
    "TCombobox": {"background", "fieldbackground", "foreground", "selectbackground", "selectforeground", "arrowcolor"},
    "TEntry": {"fieldbackground", "foreground", "selectbackground", "selectforeground", "insertbackground"},
    "TScrollbar": {"background", "troughcolor", "arrowcolor", "bordercolor", "lightcolor", "darkcolor"},
    "Treeview": {"background", "foreground", "fieldbackground"},
    "Treeview.Heading": {"background", "foreground"},
    "TNotebook": {"background", "bordercolor"},
    "TNotebook.Tab": {"background", "foreground", "bordercolor"},
}


def _hex(value):
    value = str(value).lower()
    if len(value) in (4, 7) and value.startswith("#") and all(ch in "0123456789abcdef" for ch in value[1:]):
        return value if len(value) == 7 else "#" + "".join(ch * 2 for ch in value[1:])
    return None


def _background(raw, option, default, colors):
    value = str(raw).lower()
    if option == "highlightcolor":
        return colors["FOCUS"]
    if value in _SURFACES:
        return colors[_SURFACES[value]]
    return _hex(value) or colors[_DEFAULT_SURFACES.get(option, default)]


def _foreground(raw, option, bg, colors):
    value = str(raw).lower()
    if option == "disabledforeground":
        return _readable(bg, colors["DISABLED"], 3)
    if bg in (colors["AMBER"], colors["PRIMARY_HOVER"]) and (value in _ACCENTS or value in _INK):
        return colors["PRIMARY_TEXT"]
    if value in _ACCENTS:
        return _readable(bg, colors["AMBER"])
    if value in _MUTED:
        return _readable(bg, colors["BG_SECONDARY"] if bg == colors["BG"] else colors["SECONDARY"])
    if value in _INK or _hex(value) is None:
        return _ink(bg)
    return _readable(bg, value)


class _WidgetTheme:
    def __init__(self, widget, manager):
        self.widget = widget
        self.manager = manager
        self.default_surface = "FIELD" if widget.winfo_class() in _INPUTS else "BG"
        if isinstance(widget, (tk.Button, tk.Menubutton)):
            self.default_surface = "SURF2"
        self.configure = widget.configure
        self.raw = {}
        self.tags = {}
        self.tag_configure = None
        self.style = None
        if isinstance(widget, ttk.Widget):
            self._set_style(widget.cget("style"))
        else:
            self.raw = {name: widget.cget(name) for name in _OPTIONS.intersection(widget.keys())}
            if "background" in self.raw:
                self.raw["background"] = self._original_background(self.raw["background"])
        if isinstance(widget, (tk.Text, ttk.Treeview)):
            self._track_tags()
        widget.configure = widget.config = self._configure

    def _original_background(self, value):
        parent = self.widget.master
        owner = getattr(parent, "_overhaul_dialog_widget", None)
        if owner is not None and "background" in owner.raw and value == parent.cget("background"):
            return owner.raw["background"]
        return value

    def _set_style(self, name):
        widget = self.widget
        first_style = self.style is None
        if not name:
            name = widget.winfo_class()
            if isinstance(widget, ttk.Scrollbar):
                name = f"{str(widget.cget('orient')).title()}.{name}"
        self.style = str(name).removeprefix("OverhaulDialog.")
        self.configure(style=self._style_name)
        self.manager.styles_ready.discard(self.style)
        if first_style and isinstance(widget, ttk.Combobox):
            for sequence in ("<Button-1>", "<Alt-Down>"):
                widget.bind(sequence, lambda event: widget.after_idle(self._combobox_popdown), add="+")

    @property
    def _style_name(self):
        return "OverhaulDialog." + self.style

    def _combobox_popdown(self):
        widget = self.widget
        c = self.manager.colors()
        try:
            window = widget.tk.call("ttk::combobox::PopdownWindow", str(widget))
            widget.tk.call(f"{window}.f.l", "configure", "-background", c["FIELD"],
                           "-foreground", c["FIELD_TEXT"], "-selectbackground", c["ACTIVE_TAB"],
                           "-selectforeground", c["ACTIVE_TEXT"])
        except tk.TclError:
            pass

    def _options(self, raw, options, colors):
        result = {}
        for option in options:
            if option in _FOREGROUND_OPTIONS:
                background = _FOREGROUND_OPTIONS[option]
                bg = _background(raw.get(background) or raw.get("background"), background,
                                 self.default_surface, colors)
                value = raw[option]
                name = str(value).lower()
                if name.isalpha() and not name.startswith("system") and name not in _INK:
                    try:
                        value = "#" + "".join(f"{channel // 257:02x}" for channel in self.widget.winfo_rgb(name))
                    except tk.TclError:
                        pass
                result[option] = _foreground(value, option, bg, colors)
            elif option in raw:
                result[option] = _background(raw[option], option, self.default_surface, colors)
        return result

    def _configure(self, cnf=None, **options):
        if isinstance(cnf, dict):
            options = {**cnf, **options}
            cnf = None
        if cnf is not None or not options:
            return self.configure(cnf, **options)
        colors = self.manager.colors()
        options = {_ALIASES.get(name, name): value for name, value in options.items()}
        if self.style is not None and "style" in options:
            self._set_style(options.pop("style"))
            self._paint_style(colors)
        changes = _OPTIONS.intersection(options)
        if changes:
            if "background" in changes:
                options["background"] = self._original_background(options["background"])
            self.raw.update({name: options[name] for name in changes})
            # A change of surface may also require fresh contrast for existing text.
            options.update(self._options(self.raw, self.raw.keys(), colors))
        return self.configure(**options)

    def _paint_style(self, colors):
        if self.style in self.manager.styles_ready:
            return
        styles = self.manager.styles
        family = self.widget.winfo_class()
        suffixes = {"Treeview": ("", ".Heading"), "TNotebook": ("", ".Tab")}.get(family, ("",))
        for suffix in suffixes:
            source = self.style + suffix
            target = self._style_name + suffix
            configured = styles.configure(source) or {}
            options = _TTK_OPTIONS.get(family + suffix, {"background", "foreground"})
            if family in ("TFrame", "TScrollbar", "TPanedwindow", "TNotebook") and not suffix:
                options = options - {"foreground"}
            raw = {name: styles.lookup(source, name) for name in options}
            raw.update({name: value for name, value in configured.items() if name in _OPTIONS})
            if raw:
                styles.configure(target, **self._options(raw, raw.keys(), colors))
            mapped = styles.map(source) or {}
            color_map = {}
            for option, states in mapped.items():
                if option not in _OPTIONS:
                    continue
                values = []
                for *state, value in states:
                    context = dict(raw, **{option: value})
                    if option in _FOREGROUND_OPTIONS:
                        background = _FOREGROUND_OPTIONS[option]
                        context[background] = styles.lookup(source, background, state) or raw.get(background)
                    values.append((*state, self._options(context, (option,), colors)[option]))
                color_map[option] = values
            if color_map:
                styles.map(target, **color_map)
        self.manager.styles_ready.add(self.style)

    def _track_tags(self):
        widget = self.widget
        original = self.tag_configure = widget.tag_configure
        text = isinstance(widget, tk.Text)
        names = widget.tag_names() if text else widget.tk.splitlist(widget.tk.call(widget, "tag", "names"))
        for tag in names:
            if tag != "sel":
                options = {name: widget.tag_cget(tag, name) if text else original(tag, name)
                           for name in ("background", "foreground")}
                if any(options.values()):
                    self.tags[tag] = options

        def configure_tag(tag, option=None, **kwargs):
            if isinstance(option, dict):
                kwargs = {**option, **kwargs}
                option = None
            if kwargs and tag != "sel":
                changes = {name: value for name, value in kwargs.items() if name in ("background", "foreground")}
                if changes:
                    self.tags.setdefault(tag, {}).update(changes)
                    kwargs.update(self._tag_colors(tag, self.manager.colors()))
            return original(tag, option, **kwargs)

        widget.tag_configure = configure_tag
        if text:
            widget.tag_config = configure_tag

    def _tag_colors(self, tag, colors):
        values = self.tags[tag]
        raw = dict(self.raw, **{name: value for name, value in values.items() if value})
        if not raw.get("background") and self.style is not None:
            raw["background"] = self.manager.styles.lookup(self.style, "background")
        return self._options(raw, (name for name, value in values.items() if value), colors)

    def paint(self, colors):
        if self.style is not None:
            self._paint_style(colors)
        elif self.raw:
            self.configure(**self._options(self.raw, self.raw.keys(), colors))
        for tag in self.tags:
            self.tag_configure(tag, **self._tag_colors(tag, colors))


class _DialogTheme:
    def __init__(self, root, color_source):
        self.root = root
        self.colors = color_source
        self.styles = ttk.Style(root)
        self.styles_ready = set()
        self.windows = WeakSet()
        self.embedded = WeakSet()
        self.pending = set()
        self.job = None
        root.bind_all("<Map>", self._mapped, add="+")

    def _mapped(self, event):
        widget = event.widget
        while isinstance(widget, tk.Misc) and widget is not self.root:
            if getattr(widget, "_overhaul_theme_exempt", False):
                return
            if isinstance(widget, tk.Toplevel) or widget in self.embedded:
                self.windows.add(widget)
                self._queue(widget)
                return
            widget = widget.master

    def _queue(self, widget):
        self.pending.add(widget)
        if self.job is None:
            self.job = self.root.after_idle(self._flush)

    def _flush(self):
        self.job = None
        windows, self.pending = self.pending, set()
        colors = self.colors()
        for window in windows:
            if window.winfo_exists():
                self._paint(window, colors)

    def _paint(self, widget, colors):
        if getattr(widget, "_overhaul_theme_exempt", False):
            return
        dashboard = getattr(self.root, "_overhaul_widget_colors", None)
        if dashboard is None or widget not in dashboard.widgets:
            styling = getattr(widget, "_overhaul_dialog_widget", None)
            if styling is None:
                styling = widget._overhaul_dialog_widget = _WidgetTheme(widget, self)
            styling.paint(colors)
        for child in tuple(widget.children.values()):
            if not isinstance(child, tk.Toplevel):
                self._paint(child, colors)

    def restyle(self):
        self.styles_ready.clear()
        colors = self.colors()
        for window in tuple(self.windows | self.embedded):
            if window.winfo_exists():
                self._paint(window, colors)


def attach(root, color_source):
    if getattr(root, "_overhaul_dialog_theme", None) is None:
        root._overhaul_dialog_theme = _DialogTheme(root, color_source)
    return root._overhaul_dialog_theme


def watch(root, frame):
    theme = root._overhaul_dialog_theme
    theme.embedded.add(frame)
    theme._queue(frame)


def restyle(root):
    theme = getattr(root, "_overhaul_dialog_theme", None)
    if theme is not None:
        theme.restyle()
