"""User-selected launcher colors and their live editor."""

import json
import os
from pathlib import Path
import re
import tempfile
import tkinter as tk

from tavern_shared.paths import _tavern_data_dir

from .viewport import ScrollPane
from .widgets import BG, BORDER, FIELD, FOCUS, SECONDARY, SURF, UI, button, card, frame, label, styles


DEFAULT_COLORS = {"accent": "#e8a840", "background": "#1a1210", "panel": "#241c17"}
PRESETS = {
    "Tavern": DEFAULT_COLORS,
    "Moonlit": {"accent": "#8cbbff", "background": "#111725", "panel": "#1c2638"},
    "Evergreen": {"accent": "#b5cf88", "background": "#152119", "panel": "#24362c"},
}
_COLOR = re.compile(r"#?([0-9a-fA-F]{6})")
_PARCH = "#f0e6cc"
_DARK_INK = "#181515"


def _normalize(value):
    match = _COLOR.fullmatch(value.strip()) if isinstance(value, str) else None
    return "#" + match[1].lower() if match else None


def _settings_file():
    return Path(_tavern_data_dir()) / "launcher_overhaul_appearance.json"


def load_colors():
    try:
        data = json.loads(_settings_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return DEFAULT_COLORS.copy()
    if not isinstance(data, dict):
        return DEFAULT_COLORS.copy()
    return {name: _normalize(data.get(name)) or fallback for name, fallback in DEFAULT_COLORS.items()}


def save_colors(colors):
    clean = {name: _normalize(colors.get(name)) for name in DEFAULT_COLORS}
    if None in clean.values():
        raise ValueError("Enter a six-digit hex color for each field.")
    settings = _settings_file()
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=settings.parent,
                                         prefix="appearance-", suffix=".tmp", delete=False) as file:
            temporary = Path(file.name)
            json.dump(clean, file, indent=2)
            file.write("\n")
        os.replace(temporary, settings)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def rgb(color):
    return tuple(int(color[index:index + 2], 16) for index in (1, 3, 5))


def _blend(color, other, amount):
    channels = [round(start + (end - start) * amount) for start, end in zip(rgb(color), rgb(other))]
    return "#" + "".join(f"{channel:02x}" for channel in channels)


def _luminance(color):
    def linear(channel):
        value = channel / 255
        return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4

    return sum(weight * linear(channel) for weight, channel in zip((0.2126, 0.7152, 0.0722), rgb(color)))


def _contrast(a, b):
    low, high = sorted((_luminance(a), _luminance(b)))
    return (high + 0.05) / (low + 0.05)


def _ink(background):
    for color in (_PARCH, _DARK_INK, "#ffffff", "#000000"):
        if _contrast(background, color) >= 4.5:
            return color


def _readable(background, color, minimum=4.5):
    ink = _ink(background)
    for amount in (0, .18, .36, .54, .72, .9):
        candidate = _blend(color, ink, amount)
        if _contrast(background, candidate) >= minimum:
            return candidate
    return ink


def palette(colors):
    clean = {name: _normalize(colors.get(name)) or fallback for name, fallback in DEFAULT_COLORS.items()}
    accent, background, panel = (clean[name] for name in ("accent", "background", "panel"))
    if clean == DEFAULT_COLORS:
        return {
            "BG": background, "SURF": panel, "SURF2": "#2e2218", "BORDER": "#4a3828",
            "AMBER": accent, "PARCH": _PARCH, "SECONDARY": "#c2ae91", "FIELD": "#1f1713",
            "FOCUS": "#99723e", "PRIMARY_TEXT": background, "PRIMARY_HOVER": "#f3be66",
            "SECONDARY_HOVER": "#483322", "DISABLED": "#88765c", "ACTIVE_TAB": "#2e2218",
            "ACTIVE_TEXT": accent, "MUTED": "#c2ae91", "BG_TEXT": _PARCH, "BG_SECONDARY": "#c2ae91",
            "FIELD_TEXT": _PARCH, "SURF2_TEXT": _PARCH, "PANEL_ACCENT": accent,
            "BG_ACCENT": accent, "HERO_TEXT": _PARCH, "SECONDARY_HOVER_TEXT": _PARCH,
            "FIELD_ACCENT": accent, "STATUS_OK": "#6acc72", "STATUS_WARNING": accent,
            "STATUS_ERROR": "#d06666", "ALERT_SURFACE": _readable(_PARCH, "#c45c5c"),
        }

    panel_ink = _ink(panel)
    background_ink = _ink(background)
    surface = _blend(panel, panel_ink, .08)
    field = _blend(panel, panel_ink, .035)
    active = _blend(panel, _readable(panel, accent), .13)
    secondary_hover = _blend(surface, _ink(surface), .13)
    primary_ink = _ink(accent)
    primary_hover = _blend(accent, "#000000" if _luminance(primary_ink) < .5 else "#ffffff", .14)
    if _contrast(primary_ink, primary_hover) < 4.5:
        primary_hover = _blend(accent, "#ffffff" if _luminance(primary_ink) < .5 else "#000000", .14)
    panel_secondary = _readable(panel, _blend(panel, panel_ink, .64))
    return {
        "BG": background, "SURF": panel, "SURF2": surface, "BORDER": _blend(panel, panel_ink, .24),
        "AMBER": accent, "PARCH": panel_ink, "SECONDARY": panel_secondary, "FIELD": field,
        "FOCUS": _readable(panel, accent, 3), "PRIMARY_TEXT": primary_ink, "PRIMARY_HOVER": primary_hover,
        "SECONDARY_HOVER": secondary_hover, "DISABLED": _readable(surface, _blend(surface, _ink(surface), .4), 3),
        "ACTIVE_TAB": active, "ACTIVE_TEXT": _readable(active, accent), "MUTED": panel_secondary,
        "BG_TEXT": background_ink, "BG_SECONDARY": _readable(background, _blend(background, background_ink, .64)),
        "FIELD_TEXT": _ink(field), "SURF2_TEXT": _ink(surface), "PANEL_ACCENT": _readable(panel, accent),
        "BG_ACCENT": _readable(background, accent), "HERO_TEXT": _PARCH,
        "SECONDARY_HOVER_TEXT": _ink(secondary_hover),
        "FIELD_ACCENT": _readable(field, accent), "STATUS_OK": _readable(panel, "#6acc72"),
        "STATUS_WARNING": _readable(panel, "#e8a840"), "STATUS_ERROR": _readable(panel, "#d06666"),
        "ALERT_SURFACE": _readable(_ink(surface), "#c45c5c"),
    }


class AppearancePage(tk.Frame):
    def __init__(self, parent, colors, on_preview, on_save, on_close, *, action_parent=None):
        super().__init__(parent)
        styles(self).bind(self, bg=BG)
        self.original = colors.copy()
        self.colors = colors.copy()
        self.on_preview = on_preview
        self.on_save = on_save
        self.on_close = on_close
        self.color_vars = {}
        self.preset_buttons = {}
        self.swatches = {}
        self._preview_job = None
        self._layout_modes = {}
        self._color_traces = {}
        self._color_tiles = []
        self._preset_tiles = {}
        self._docked = action_parent is not None
        self._pane = parent
        while self._pane is not None and not isinstance(self._pane, ScrollPane):
            self._pane = self._pane.master
        self._build(action_parent)
        self._paint_swatches()
        self.bind("<Configure>", self._resize)
        if self._pane is not None:
            self._viewport_binding = self._pane.canvas.bind("<Configure>", self._resize, add="+")
        self._resize()

    def _build(self, action_parent):
        self.color_card, color_body = card(self, "Custom colors")
        self.color_card.pack(fill="x")
        self._intro = label(color_body, "Choose a color or enter a hex value to preview it across the launcher.",
                            size=9, color=SECONDARY, wraplength=200, justify="left")
        self._intro.pack(fill="x", pady=(6, 12))
        self._color_grid = frame(color_body)
        self._color_grid.pack(fill="x")
        for key, caption, use in (("accent", "Accent", "Buttons and highlights"),
                                  ("background", "Background", "Launcher workspace"),
                                  ("panel", "Panels", "Cards and surfaces")):
            self._add_color(key, caption, use)

        self.presets_card, presets_body = card(self, "Presets")
        self.presets_card.pack(fill="x", pady=(12, 0))
        self._preset_grid = frame(presets_body)
        self._preset_grid.pack(fill="x", pady=(8, 0))
        for name, colors in PRESETS.items():
            self._add_preset(name, colors)

        self.action_bar = frame(action_parent if self._docked else self, SURF, border=True)
        self.action_bar.pack(fill="x", pady=0 if self._docked else (12, 0))
        body = frame(self.action_bar)
        body.pack(fill="x", padx=12 if self._docked else 16, pady=6 if self._docked else 12)
        self.message = label(body, size=9, color="STATUS_ERROR", width=1, wraplength=200, justify="left")
        self._actions = frame(body)
        self._actions.pack(fill="x")
        self.reset_button = button(self._actions, "Reset defaults", lambda: self._set(DEFAULT_COLORS), compact=True)
        self.cancel_button = button(self._actions, "Cancel", self.cancel, compact=True)
        self.save_button = button(self._actions, "Save colors", self._save, primary=True, compact=True)
        if self._docked:
            for control in (self.reset_button, self.cancel_button, self.save_button):
                control.configure(font=(UI, 9, "bold"), padx=8)
            self.action_bar.bind("<Configure>", lambda event: self._layout_commands(event.width - 26), add="+")

    def _add_color(self, key, caption, use):
        tile = frame(self._color_grid, border=True)
        body = frame(tile)
        body.pack(fill="x", padx=10, pady=8)
        label(body, caption, weight="bold").pack(fill="x")
        help_text = label(body, use, size=8, color=SECONDARY, wraplength=150, justify="left")
        help_text.pack(fill="x", pady=(1, 6))
        fields = frame(body)
        fields.pack(fill="x")
        fields.columnconfigure(0, weight=1)

        variable = self.color_vars[key] = tk.StringVar(self, value=self.original[key])
        self._color_traces[key] = variable.trace_add("write", self._queue_preview)
        entry = tk.Entry(fields, textvariable=variable, width=7, bd=5, relief="flat", font=("Consolas", 9),
                         highlightthickness=1)
        styles(entry).bind(entry, bg=FIELD, fg="FIELD_TEXT", insertbackground="FIELD_TEXT",
                           selectbackground="ACTIVE_TAB", selectforeground="ACTIVE_TEXT",
                           highlightbackground=BORDER, highlightcolor=FOCUS)
        entry.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        if key == "accent":
            self.accent_field = entry
        swatch = tk.Button(fields, text="Pick color", command=lambda: self._pick(key), relief="flat", bd=0,
                           cursor="hand2", takefocus=True, highlightthickness=1,
                           font=(UI, 9, "bold"), padx=10, pady=4)
        styles(swatch).bind(swatch, highlightbackground=BORDER, highlightcolor=FOCUS)
        swatch.grid(row=0, column=1, sticky="nsew")
        self.swatches[key] = swatch
        self._color_tiles.append((tile, fields, help_text, entry, swatch))

    def _add_preset(self, name, colors):
        tile = frame(self._preset_grid, border=True)
        sample = frame(tile, cursor="hand2")
        sample.pack(fill="x", padx=6, pady=(6, 0))
        sample.columnconfigure((0, 1, 2), weight=1, uniform="preset")
        preset = button(tile, name, lambda: self._set(colors), compact=True)
        preset.pack(fill="x", padx=6, pady=(3, 4))
        for index, color in enumerate(colors.values()):
            band = tk.Frame(sample, background=color, height=20, cursor="hand2")
            band.grid(row=0, column=index, sticky="ew")
            band.bind("<Button-1>", lambda event: preset.invoke())
        self.preset_buttons[name] = preset
        self._preset_tiles[name] = tile

    def _resize(self, event=None):
        width = self.winfo_width()
        if self._pane is not None:
            viewport = self._pane.canvas.winfo_width()
            width = min(width, viewport - 2 * self.master.winfo_x())
        inner = max(0, width - 34) if width > 1 else 236
        self._intro.configure(wraplength=max(60, inner - 4))

        color_min = 30 + max(entry.winfo_reqwidth() + swatch.winfo_reqwidth()
                             for _, _, _, entry, swatch in self._color_tiles)
        color_columns = 3 if inner >= max(560, color_min * 3 + 16) else 1
        color_width = (inner - 8 * (color_columns - 1)) // color_columns
        for _, fields, help_text, entry, swatch in self._color_tiles:
            help_text.configure(wraplength=max(60, color_width - 26))
            stacked = color_width < color_min
            if self._layout_modes.get(fields) != stacked:
                self._layout_modes[fields] = stacked
                entry.grid_configure(padx=0 if stacked else (0, 8))
                swatch.grid_configure(row=int(stacked), column=int(not stacked), pady=(6, 0) if stacked else 0)
        self._arrange_tiles(self._color_grid, [tile for tile, *_ in self._color_tiles], color_columns)

        preset_min = max(tile.winfo_reqwidth() for tile in self._preset_tiles.values())
        preset_columns = 3 if inner >= max(240, preset_min * 3 + 16) else 1
        self._arrange_tiles(self._preset_grid, list(self._preset_tiles.values()), preset_columns)

        width = self.action_bar.winfo_width()
        self._layout_commands(width - 26 if self._docked and width > 1 else inner)

    def _layout_commands(self, inner):
        self.message.configure(wraplength=max(60, inner - 4))
        actions = (self.reset_button, self.cancel_button, self.save_button)
        reset_width, cancel_width, save_width = (control.winfo_reqwidth() for control in actions)
        columns = 1
        if inner >= reset_width + cancel_width + save_width + 16:
            columns = 3
        elif inner >= cancel_width + save_width + 8:
            columns = 2
        if self._layout_modes.get(self._actions) != columns:
            self._layout_modes[self._actions] = columns
            positions = {
                1: ((0, 0), (1, 0), (2, 0)),
                2: ((0, 0), (1, 0), (1, 1)),
                3: ((0, 0), (0, 1), (0, 2)),
            }
            for control, (row, column) in zip(actions, positions[columns]):
                alone = columns == 2 and control is self.reset_button
                control.grid(row=row, column=column, columnspan=2 if alone else 1,
                             sticky="w" if alone else "ew",
                             padx=(0, 8) if column < columns - 1 and not alone else 0,
                             pady=(8, 0) if row else 0)

    def _arrange_tiles(self, group, tiles, columns):
        if self._layout_modes.get(group) == columns:
            return
        self._layout_modes[group] = columns
        for column in range(len(tiles)):
            group.columnconfigure(column, weight=int(column < columns), uniform="tiles" if column < columns else "")
        for index, tile in enumerate(tiles):
            row, column = divmod(index, columns)
            tile.grid(row=row, column=column, sticky="nsew",
                      padx=(0, 8) if column < columns - 1 else 0, pady=(8, 0) if row else 0)

    def _paint_swatches(self):
        for key, swatch in self.swatches.items():
            value = self.colors[key]
            swatch.configure(bg=value, fg=_ink(value), activebackground=value, activeforeground=_ink(value))
        for name, tile in self._preset_tiles.items():
            active = PRESETS[name] == self.colors
            styles(tile).bind(tile, highlightbackground=FOCUS if active else BORDER)
            self.preset_buttons[name].configure(text=f"✓ {name}" if active else name)

    def _show_error(self, message):
        self.message.configure(text=message)
        if message:
            self.message.pack(fill="x", pady=(0, 8), before=self._actions)
        else:
            self.message.pack_forget()

    def _set(self, colors):
        for name, color in colors.items():
            self.color_vars[name].set(color)

    def _pick(self, name):
        try:
            chosen = self.tk.call("tk_chooseColor", "-parent", self.winfo_toplevel()._w, "-title", "Choose a color",
                                  "-initialcolor", _normalize(self.color_vars[name].get()) or self.colors[name])
        except tk.TclError:
            self._show_error("Enter a hex color such as #e8a840.")
            return
        if chosen:
            self.color_vars[name].set(str(chosen))

    def _queue_preview(self, *_):
        if self._preview_job is None:
            self._preview_job = self.after_idle(self._preview)

    def _preview(self):
        self._preview_job = None
        values = {name: _normalize(var.get()) for name, var in self.color_vars.items()}
        if None in values.values():
            self._show_error("Enter six hex digits for each color.")
            self.save_button.configure(state="disabled")
            return None
        self._show_error("")
        self.save_button.configure(state="normal")
        if values != self.colors:
            self.colors = values
            self._paint_swatches()
            self.on_preview(values.copy())
        return values

    def _save(self):
        self._cancel_job()
        colors = self._preview()
        if colors is None:
            return
        try:
            self.on_save(colors.copy())
        except (OSError, ValueError):
            self._show_error("Could not save colors. Try again or select Cancel.")
            return
        self.original = colors.copy()
        self.on_close()

    def cancel(self):
        self.close()
        self.on_close()

    def close(self):
        """Roll back unsaved colors before the host leaves the detail view."""
        self._cancel_job()
        if self.colors != self.original:
            self.colors = self.original.copy()
            self.on_preview(self.original.copy())

    def _cancel_job(self):
        if self._preview_job is not None:
            self.after_cancel(self._preview_job)
            self._preview_job = None

    def destroy(self):
        self._cancel_job()
        if self._pane is not None:
            self._pane.canvas.unbind("<Configure>", self._viewport_binding)
        for key, trace in self._color_traces.items():
            self.color_vars[key].trace_remove("write", trace)
        if self._docked and self.action_bar.winfo_exists():
            self.action_bar.destroy()
        super().destroy()
