"""Embed the stock game configuration editor in the launcher workspace."""

import re
import tkinter as tk

from client.core import game_settings_window as stock

from .viewport import ScrollPane
from .widgets import BG, BORDER, FIELD, FOCUS, SECONDARY, SURF, UI, _mk_combobox, button, card, frame, label, styles


_GROUPS = (
    ("Movement", (
        ("IsUsingSmoothLocomotion", "Smooth locomotion"),
        ("SmoothLocomotionActiveHand", "Movement hand"),
        ("TouchLocomotionMode", "Touch movement direction"),
        ("PressLocomotionMode", "Press movement direction"),
        ("SmoothLocomotionRunMode", "Run mode"),
        ("IsInvertingSmoothWalkAndRun", "Invert walk and run"),
        ("IsBendingBodyOnLocalBody", "Bend local player body"),
    )),
    ("Turning & comfort", (
        ("SnapRotation", "Turning style"),
        ("SnapRotationMode", "Snap turning input"),
        ("SmoothRotationSpeed", "Smooth turning speed"),
        ("SwipeSensitivityLevelValue", "Swipe sensitivity"),
        ("IsSmoothRotationOnSwipe", "Smooth turning on swipe"),
        ("MovementComfortStrength", "Movement comfort strength"),
        ("MovementComfortSpeed", "Movement comfort timing"),
    )),
    ("Audio & haptics", (
        ("AudioFXVolumeMultiplier", "Sound effects volume multiplier"),
        ("SelfStepVolume", "Own footstep volume"),
        ("HasHapticsWhenToggleHolding", "Haptics when toggling hold"),
        ("HapticsStrengthMultiplier", "Haptics strength multiplier"),
    )),
    ("Display & cameras", (
        ("HasAmbientOcclusionEnabled", "Ambient occlusion"),
        ("PixelLightCount", "Pixel light count"),
        ("DefaultCullingDistance", "Culling distance"),
        ("PlayerNamesToggle", "Show player names"),
        ("CameraPhotoResolutionScale", "Photo resolution scale"),
        ("StreamingResolutionScale", "Streaming resolution scale"),
        ("ViewFinderResolutionScale", "Viewfinder resolution scale"),
        ("ScreenshotDockHideOptions", "Hide screenshot dock"),
        ("RenderOneCameraFromOtherPlayers", "Render one other player's camera"),
    )),
    ("Accessibility", (
        ("HasAccessibilityFeatures", "Accessibility features"),
        ("HeightAssistValue", "Height assist"),
        ("HasGrabAssist", "Grab assist"),
        ("UseGrabPositionMemory", "Remember grab positions"),
        ("AccessibleDocksAreToggle", "Toggle accessible docks"),
    )),
    ("Gameplay & file paths", (
        ("IsUsingFreeGestureMode", "Free gesture mode"),
        ("CanSellSkillsWithChildren", "Allow selling skills with dependent skills"),
        ("ModsDirectoryPath", "Mods directory"),
        ("LogSettingsPath", "Log settings path"),
    )),
)


class SettingsPage(tk.Frame):
    _load = stock.GameSettingsWindow._load
    _reset_to_defaults = stock.GameSettingsWindow._reset_to_defaults
    _save = stock.GameSettingsWindow._save

    def __init__(self, parent, *, action_parent=None):
        super().__init__(parent)
        styles(self).bind(self, bg=BG)
        self._status = tk.StringVar(self)
        self._status_trace = self._status.trace_add("write", self._show_status)
        self._rows = []
        self._groups = []
        self._stacked = None
        self._actions_stacked = None
        self._buttons_stacked = None
        self._layout_width = None
        self._command_width = None
        self._docked = action_parent is not None
        self._pane = parent
        while self._pane is not None and not isinstance(self._pane, ScrollPane):
            self._pane = self._pane.master

        toolbar = frame(self, SURF, border=True)
        toolbar.pack(fill="x")
        self._toolbar = frame(toolbar)
        self._toolbar.pack(fill="x", padx=16, pady=12)
        self._toolbar.columnconfigure(0, weight=1)
        self._description = label(self._toolbar, size=9, color=SECONDARY, width=1, wraplength=200, justify="left")
        self._description.grid(row=0, column=0, sticky="ew")
        self.action_bar = toolbar
        self._command_body = self._toolbar
        if self._docked:
            self.action_bar = frame(action_parent, SURF, border=True)
            self.action_bar.pack(fill="x")
            self._command_body = frame(self.action_bar)
            self._command_body.pack(fill="x", padx=12, pady=6)
            self._command_body.columnconfigure(0, weight=1)
        self._actions = frame(self._command_body)
        self.defaults_button = button(self._actions, "Defaults", self._reset_to_defaults, compact=True)
        self.save_button = button(self._actions, "Save settings", self._save, primary=True, compact=True)
        self._status_label = label(self._command_body, size=9, color="PANEL_ACCENT", textvariable=self._status,
                                   width=1, wraplength=200, justify="left")
        if self._docked:
            for control in (self.defaults_button, self.save_button):
                control.configure(font=(UI, 9, "bold"), padx=8)
            self.action_bar.bind("<Configure>", self._on_resize, add="+")

        self._form = frame(self)
        self._form.pack(fill="x")
        self.bind("<Configure>", self._on_resize)
        if self._pane is not None:
            self._viewport_binding = self._pane.canvas.bind("<Configure>", self._on_resize, add="+")
        self.reload()

    def reload(self):
        self._path = stock.find_game_config_path()
        self._data = {}
        self._widgets = {}
        self._rows.clear()
        self._groups.clear()
        self._stacked = None
        self._layout_width = None
        self._status.set("")
        for child in tuple(self._form.children.values()):
            child.destroy()

        state = "normal" if self._path else "disabled"
        self.defaults_button.configure(state=state)
        self.save_button.configure(state=state)
        if not self._path:
            self._description.configure(text="GameConfiguration.json was not found. Launch the game once, "
                                            "close it, then reopen Game settings.")
            self._on_resize()
            return

        self._description.configure(text="Close the game before editing. It can overwrite your changes when it exits.")
        self._load()
        fields = {field: (kind, choices) for field, kind, choices in stock.FIELDS}
        for name, group in _GROUPS:
            entries = [(field, title, *fields.pop(field)) for field, title in group if field in fields]
            if entries:
                self._add_group(name, entries)
        if fields:
            self._add_group("Other settings", [
                (field, re.sub(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", " ", field), kind, choices)
                for field, (kind, choices) in fields.items()
            ])
        self._on_resize()

    def _add_group(self, name, entries):
        panel, content = card(self._form, name)
        panel.pack(fill="x", pady=(12, 0))
        form = frame(content)
        form.pack(fill="x", pady=(8, 0))
        self._groups.append(form)
        for row, (field, caption, kind, choices) in enumerate(entries):
            title = label(form, caption, size=9, weight="bold", wraplength=200, justify="left")
            holder = frame(form)
            self._add_field(holder, field, kind, choices)
            note = stock.FIELD_NOTES.get(field)
            if note:
                note = label(holder, note, size=8, color=SECONDARY, wraplength=200, justify="left")
                note.pack(fill="x", pady=(3, 0))
            divider = frame(form, BORDER, height=1) if row < len(entries) - 1 else None
            self._rows.append((form, row, title, holder, note, divider))

    def _add_field(self, parent, field, kind, choices):
        current = self._data.get(field)
        if kind == "bool":
            variable = tk.BooleanVar(self, value=bool(current))
            state_text = tk.StringVar(self)
            control = tk.Checkbutton(parent, variable=variable, textvariable=state_text, anchor="w", bd=0,
                                     padx=5, pady=5, takefocus=True, highlightthickness=1, font=(UI, 9))
            styles(control).bind(control, bg=FIELD, fg="FIELD_TEXT", activebackground=FIELD,
                                 activeforeground="FIELD_TEXT", selectcolor=FIELD, highlightbackground=BORDER,
                                 highlightcolor=FOCUS)
            trace = variable.trace_add("write", lambda *_: state_text.set("On" if variable.get() else "Off"))
            control.bind("<Destroy>", lambda event: variable.trace_remove("write", trace), add="+")
            state_text.set("On" if variable.get() else "Off")
            control.pack(fill="x")
        elif kind == "enum":
            variable = tk.StringVar(self, value=current if current in choices else choices[0])
            control = _mk_combobox(parent, variable, choices)
            control.configure(width=1, font=(UI, 9))
            control.bind("<MouseWheel>", self._scroll_form)
            control.bind("<Shift-MouseWheel>", self._scroll_form)
        else:
            if kind == "text":
                value = current if isinstance(current, str) else ""
            else:
                value = str(current) if current is not None else ""
            variable = tk.StringVar(self, value=value)
            control = tk.Entry(parent, textvariable=variable, width=1, font=(UI, 9), relief="flat", bd=5,
                               highlightthickness=1)
            styles(control).bind(control, bg=FIELD, fg="FIELD_TEXT", insertbackground="FIELD_TEXT",
                                 selectbackground="ACTIVE_TAB", selectforeground="ACTIVE_TEXT",
                                 highlightbackground=BORDER, highlightcolor=FOCUS)
            control.pack(fill="x")
        self._widgets[field] = (kind, variable)

    def _scroll_form(self, event):
        if self._pane is not None:
            self._pane.wheel(event)
        return "break"

    def _show_status(self, *_):
        if self._status.get():
            if self._docked:
                stacked = self._actions_stacked
                self._status_label.grid(row=0, column=0, sticky="ew", columnspan=1,
                                        pady=(0, 6) if stacked else 0, padx=0 if stacked else (0, 10))
            else:
                self._status_label.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        else:
            self._status_label.grid_remove()

    def _layout_commands(self, inner):
        action_width = self.defaults_button.winfo_reqwidth() + self.save_button.winfo_reqwidth() + 8
        if (inner, action_width) == self._command_width:
            return action_width
        self._command_width = (inner, action_width)
        buttons_stacked = inner < action_width
        if buttons_stacked != self._buttons_stacked:
            self._buttons_stacked = buttons_stacked
            self.defaults_button.grid(row=0, column=0, sticky="ew", padx=0 if buttons_stacked else (0, 8))
            self.save_button.grid(row=1 if buttons_stacked else 0, column=0 if buttons_stacked else 1,
                                  sticky="ew", pady=(6, 0) if buttons_stacked else 0)
        self._actions_stacked = inner < action_width + (165 if self._docked else 270)
        stacked = self._actions_stacked
        self._actions.grid(row=1 if stacked else 0, column=0 if stacked else 1,
                           sticky="e", padx=0 if stacked else (12, 0),
                           pady=(8, 0) if stacked and not self._docked else 0)
        status_width = inner - (action_width + 22 if self._docked and not stacked else 0)
        self._status_label.configure(wraplength=max(60, status_width - 4))
        self._show_status()
        return action_width

    def _on_resize(self, event=None):
        width = self.winfo_width()
        if self._pane is not None:
            viewport = self._pane.canvas.winfo_width()
            width = min(width, viewport - 2 * self.master.winfo_x())
        if width <= 1:
            width = 270
        inner = width - 34
        dock_width = self.action_bar.winfo_width()
        command_inner = dock_width - 26 if self._docked and dock_width > 1 else inner
        action_width = self._layout_commands(command_inner)
        layout_width = (inner, action_width)
        if layout_width == self._layout_width:
            return
        self._layout_width = layout_width
        description_width = inner - (action_width + 12 if not self._docked and not self._actions_stacked else 0)
        self._description.configure(wraplength=max(60, description_width - 4))

        stacked = inner < 440
        if stacked != self._stacked:
            self._stacked = stacked
            self._layout_rows()
        title_width = inner if stacked else round(inner * .53)
        field_width = inner if stacked else inner - title_width - 12
        for group in self._groups:
            group.columnconfigure(0, weight=int(stacked), minsize=0 if stacked else title_width)
            group.columnconfigure(1, weight=int(not stacked))
        for _, _, title, _, note, _ in self._rows:
            title.configure(wraplength=max(60, title_width - 8))
            if note:
                note.configure(wraplength=max(60, field_width - 4))

    def _layout_rows(self):
        stacked = self._stacked
        for group, index, title, holder, _, divider in self._rows:
            row = index * 3
            title.grid(row=row, column=0, sticky="ew", pady=(8, 3) if stacked else 6)
            holder.grid(row=row + 1 if stacked else row, column=0 if stacked else 1, sticky="ew",
                        padx=0 if stacked else (12, 0), pady=(0, 8) if stacked else 6)
            if divider is not None:
                divider.grid(row=row + 2, column=0, columnspan=2, sticky="ew")

    def destroy(self):
        if self._pane is not None:
            self._pane.canvas.unbind("<Configure>", self._viewport_binding)
        self._status.trace_remove("write", self._status_trace)
        if self._docked and self.action_bar.winfo_exists():
            self.action_bar.destroy()
        super().destroy()
