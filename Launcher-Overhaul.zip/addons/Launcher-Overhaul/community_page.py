"""Search and browse the public server list in the launcher workspace."""

import os
import queue
import threading
import tkinter as tk

from client.core import community_browser as stock

from .launch_history import saved_target
from .library_pages import ServerActions, ServerList, favorite_key, split_address
from .widgets import BG, SECONDARY, SURF, UI, _mk_combobox, button, frame, label, styles, text_field


_SCENES = {"All scenes": "all", "Tutorial": "tutorial", "Normal": "normal", "Quest": "quest"}
_SORT_OPTIONS = {
    "Default": stock.DEFAULT_SORT, "Name": "name", "Address": "address", "Players": "players",
    "Access": "locked", "Type": "type", "Scene": "scene",
    "Region": "region", "Version": "version", "Ping": "ping",
}
_SORT_LABELS = {value: key for key, value in _SORT_OPTIONS.items()}


class CommunityPage(tk.Frame):
    _SORT_KEYS = stock.CommunityBrowser._SORT_KEYS
    _MAX_CONCURRENT_PINGS = stock.CommunityBrowser._MAX_CONCURRENT_PINGS

    def __init__(self, parent, on_select, *, is_pinned=None, on_pin=None, action_parent=None):
        super().__init__(parent)
        styles(self).bind(self, bg=BG)
        self.closed = False
        self.loading = False
        self._on_select = on_select
        self._servers = []
        self._callbacks = queue.SimpleQueue()
        self._poll_job = None
        self._ping_sema = threading.Semaphore(self._MAX_CONCURRENT_PINGS)
        self._load_preferences()
        self._error = False
        self._build(is_pinned, on_pin, action_parent)
        self._poll_job = self.after(30, self._service_callbacks)
        self._refresh()

    def _load_preferences(self):
        config = stock.load_cfg()
        entries = config.get("saved_servers", [])
        self._favorites = entries if isinstance(entries, list) else []
        preferences = config.get("sort_prefs")
        self._sort = {}
        for scope in _SCENES.values():
            preference = preferences.get(scope) if isinstance(preferences, dict) else None
            column = preference.get("col") if isinstance(preference, dict) else None
            if isinstance(column, str) and column in self._SORT_KEYS and column in _SORT_LABELS:
                self._sort[scope] = [column, preference.get("reverse") is True]
            else:
                self._sort[scope] = [stock.DEFAULT_SORT, False]

    def _build(self, is_pinned, on_pin, action_parent):
        panel = frame(self, SURF, border=True)
        panel.pack(fill="x")
        inner = frame(panel)
        inner.pack(fill="x", padx=12, pady=12)
        self._filters = frame(inner)
        self._filters.pack(fill="x", pady=(0, 10))
        self._filters.columnconfigure(0, weight=1)
        self._search_row = frame(self._filters)
        self._search_row.columnconfigure(0, weight=1)
        self._choice_row = frame(self._filters)
        self.v_search = tk.StringVar(self)
        self.v_scene = tk.StringVar(self, "All scenes")
        self.v_sort = tk.StringVar(self, _SORT_LABELS[self._sort["all"][0]])
        search, _entry = text_field(self._search_row, "Search", self.v_search, size=7)
        search.grid(row=0, column=0, sticky="ew")
        scene, self.scene_control = self._filter_choice("Scene", self.v_scene, _SCENES, self._change_scene)
        scene.grid(row=0, column=0, sticky="ew")
        sort, self.sort_control = self._filter_choice("Sort by", self.v_sort, _SORT_OPTIONS, self._change_sort)
        sort.grid(row=0, column=1, sticky="ew", padx=(8, 0))
        self.sort_order_button = button(self._choice_row, "↑", self._reverse_sort, compact=True)
        self.sort_order_button.grid(row=0, column=2, sticky="se", padx=(6, 0))
        self.refresh_button = button(self._search_row, "Refresh", self._refresh, compact=True)
        self.refresh_button.grid(row=0, column=1, sticky="se", padx=(6, 0))
        self._filter_breakpoint = round(550 * float(self.tk.call("tk", "scaling")) / (96 / 72))
        self._compact_filters = None
        self._layout_filters(True)
        self._filters.bind("<Configure>", self._resize, add="+")

        controls = self._actions = self.action_bar = ServerActions(inner, is_pinned, on_pin,
                                                                    action_parent=action_parent)
        self.save_button = button(controls, "Favorite", self._save_favorite, compact=True)
        self.pin_button = controls.add_pin_button()
        self.connect_button = button(controls, "Connect", self._connect, primary=True, compact=True)
        for control in (self.save_button, self.connect_button, self.refresh_button, self.sort_order_button):
            control.configure(font=(UI, 9, "bold"), padx=7)
        controls.show_controls(self.save_button, self.connect_button)
        self._status = tk.StringVar(self)
        status = label(inner, textvariable=self._status, color=SECONDARY, size=9,
                       width=1, wraplength=200, justify="left")
        status.pack(fill="x", pady=(0, 6))
        status.bind("<Configure>", lambda event: status.configure(wraplength=max(40, event.width)), add="+")
        self.server_list = ServerList(inner, self._describe, self._update_actions, self._connect)
        self.server_list.pack(fill="x")
        self.v_search.trace_add("write", lambda *_: self._populate())
        self._update_sort_order()

    def _filter_choice(self, title, variable, options, callback):
        field = frame(self._choice_row)
        label(field, title, size=9, color=SECONDARY, weight="bold").pack(fill="x", pady=(0, 5))
        combo = _mk_combobox(field, variable, tuple(options))
        combo.configure(font=(UI, 9))
        combo.bind("<<ComboboxSelected>>", callback)
        return field, combo

    def _resize(self, event):
        self._layout_filters(event.width < self._filter_breakpoint)

    def _layout_filters(self, compact):
        if compact == self._compact_filters:
            return
        self._compact_filters = compact
        self._choice_row.columnconfigure(0, weight=2 if compact else 0)
        self._choice_row.columnconfigure(1, weight=int(compact))
        for combo in (self.scene_control, self.sort_control):
            combo.configure(width=1 if compact else 11)
        self._search_row.grid(row=0, column=0, sticky="ew")
        self._choice_row.grid(row=1 if compact else 0, column=0 if compact else 1,
                              sticky="ew", padx=0 if compact else (12, 0), pady=(8, 0) if compact else 0)

    def _dispatch(self, callback, *args):
        if not self.closed:
            self._callbacks.put((callback, args))

    def _service_callbacks(self):
        self._poll_job = None
        try:
            for _ in range(50):
                if self.closed:
                    break
                try:
                    callback, args = self._callbacks.get_nowait()
                except queue.Empty:
                    break
                callback(*args)
        finally:
            if not self.closed:
                self._poll_job = self.after(30, self._service_callbacks)

    def destroy(self):
        self.closed = True
        if self._poll_job is not None:
            self.after_cancel(self._poll_job)
            self._poll_job = None
        self.action_bar.close_dock()
        super().destroy()

    def _refresh(self):
        if self.loading:
            return
        self.loading = True
        self._error = False
        self.refresh_button.configure(state="disabled")
        self._populate()
        threading.Thread(target=self._fetch, daemon=True).start()

    def _fetch(self):
        try:
            request = stock.urllib.request.Request(stock.COMMUNITY_API, headers={"User-Agent": "TavernLauncher/1.0"})
            with stock.urllib.request.urlopen(request, timeout=6) as response:
                servers = stock.json.load(response)
        except (OSError, ValueError):
            self._dispatch(self._show_error)
            return
        self._dispatch(self._show_servers, servers)

    def _show_error(self):
        self.loading = False
        self._error = True
        self.refresh_button.configure(state="normal")
        self._populate()

    def _show_servers(self, servers):
        self.loading = False
        self.refresh_button.configure(state="normal")
        previous = self.server_list.selected or {}
        self._servers = ([server for server in servers if isinstance(server, dict) and
                          isinstance(server.get("address"), str) and split_address(server["address"])[0]]
                         if isinstance(servers, list) else [])
        self._populate()
        if previous:
            current = next((row.server for row in self.server_list.rows
                            if self._server_key(row.server) == self._server_key(previous)), None)
            self.server_list.select(current)
        self._start_pings()

    def _start_pings(self):
        for server in self._servers:
            host, _ = split_address(server["address"])
            threading.Thread(target=self._ping_one, args=(server, host), daemon=True).start()

    def _ping_one(self, server, host):
        with self._ping_sema:
            if self.closed:
                return
            try:
                _response, elapsed = stock.ping_server(host, timeout=5)
            except Exception:
                elapsed = -1
        self._dispatch(self._update_current_ping, server, elapsed)

    def _update_current_ping(self, server, elapsed):
        server["_ping_ms"] = elapsed
        self.server_list.set_ping(server, *self._ping(elapsed))

    @staticmethod
    def _ping(elapsed):
        if elapsed is None:
            return "Ping…", SECONDARY
        if elapsed < 0:
            return "Offline", SECONDARY
        role = "STATUS_OK" if elapsed < 120 else "STATUS_WARNING" if elapsed < 350 else "STATUS_ERROR"
        return f"{elapsed} ms", role

    def _describe(self, server):
        address = server["address"]
        name = server.get("name") or address
        metadata = [stock._scene_label(server), "Official" if server.get("kind", "official") == "official" else "Headless"]
        for detail in (server.get("region"), server.get("version")):
            if detail and str(detail).lower() != "unknown":
                metadata.append(str(detail))
        if server.get("has_password"):
            metadata.append("Password")
        players = f"{server.get('player_count', 0)}/{server.get('player_limit', 50)} players"
        return name, address, "  ·  ".join(metadata), players, self._ping(server.get("_ping_ms"))

    def _change_scene(self, _event):
        column = self._sort[_SCENES[self.v_scene.get()]][0]
        self.v_sort.set(_SORT_LABELS[column])
        self._update_sort_order()
        self._populate()

    def _change_sort(self, _event):
        scope, column = _SCENES[self.v_scene.get()], _SORT_OPTIONS[self.v_sort.get()]
        if scope == "all" and column == stock.DEFAULT_SORT:
            for state in self._sort.values():
                state[:] = [stock.DEFAULT_SORT, False]
        else:
            self._sort[scope] = [column, False]
        self._update_sort_order()
        self._save_sort_pref()
        self._populate()

    def _reverse_sort(self):
        selected = self._sort[_SCENES[self.v_scene.get()]]
        selected[1] = not selected[1]
        self._update_sort_order()
        self._save_sort_pref()
        self._populate()

    def _update_sort_order(self):
        column, reverse = self._sort[_SCENES[self.v_scene.get()]]
        self.sort_order_button.configure(state="disabled" if column == stock.DEFAULT_SORT else "normal",
                                         text="↓" if reverse else "↑")

    def _save_sort_pref(self):
        config = stock.load_cfg()
        if not config and os.path.exists(stock.CONFIG_FILE):
            return
        config["sort_prefs"] = {scope: {"col": column, "reverse": reverse}
                                for scope, (column, reverse) in self._sort.items()}
        stock.save_cfg(config)

    def _ordered(self, servers, scope):
        column, reverse = self._sort[scope]
        if column == stock.DEFAULT_SORT:
            return sorted(servers, key=stock._default_sort_key)
        if column == "ping":
            available = [server for server in servers if server.get("_ping_ms", -1) >= 0]
            pending = [server for server in servers if server.get("_ping_ms", -1) < 0]
            return sorted(available, key=self._SORT_KEYS[column], reverse=reverse) + pending
        return sorted(servers, key=lambda server: self._sort_key(server, column), reverse=reverse)

    def _sort_key(self, server, column):
        try:
            value = self._SORT_KEYS[column](server)
            if column == "players":
                return int(value or 0)
            return bool(value) if column == "locked" else str(value or "").casefold()
        except (AttributeError, TypeError, ValueError):
            return 0 if column == "players" else ""

    def _populate(self):
        query = self.v_search.get().strip().casefold()
        scope = _SCENES[self.v_scene.get()]
        visible = []
        groups = {key: [] for key, _ in stock._SECTIONS}
        for server in self._servers:
            scene = stock._scene_label(server).lower()
            if scope == "all" or scene == scope:
                if not query or query in str(server.get("name") or "").casefold() or query in server["address"].casefold():
                    groups[scene].append(server)
                    visible.append(server)
        if scope == "all" and self._sort[scope][0] == stock.DEFAULT_SORT:
            ordered = [server for scene, members in groups.items() for server in self._ordered(members, scene)]
        else:
            ordered = self._ordered(visible, scope)
        if self._error:
            status = "Could not refresh the community list."
            empty = "Use Refresh to try again."
        elif self.loading:
            status = "Fetching server list…"
            empty = "Servers will appear here when the list loads."
        elif not self._servers:
            status = "0 servers"
            empty = "No servers are listed yet."
        elif not ordered:
            status = "0 matching servers"
            empty = "Try another search or choose a different scene."
        else:
            status = f"{len(ordered)} of {len(self._servers)} servers" if len(ordered) != len(self._servers) else (
                f"{len(ordered)} server" if len(ordered) == 1 else f"{len(ordered)} servers")
            empty = ""
        self._status.set(status)
        self.server_list.set_servers(ordered, empty)

    @staticmethod
    def _server_key(server):
        return server["address"], server.get("kind", "official")

    def _connect(self):
        server = self.server_list.selected
        if server is not None:
            host, port = split_address(server["address"])
            self._on_select(host, server.get("name") or host, server.get("kind", "official"), port)
            if self.winfo_exists():
                self.destroy()

    @staticmethod
    def _favorite_record(server):
        host, port = split_address(server["address"])
        return {"name": server.get("name") or host, "ip": host, "port": port,
                "kind": server.get("kind", "official")}

    def _find_favorite(self, record):
        key = favorite_key(record)
        return any(favorite_key(entry) == key for entry in self._favorites)

    def _update_actions(self):
        server = self.server_list.selected
        record = self._favorite_record(server) if server is not None else None
        saved = record is not None and self._find_favorite(record)
        self.save_button.configure(text="Saved" if saved else "Favorite",
                                   state="normal" if server is not None and not saved else "disabled")
        self.connect_button.configure(state="normal" if server is not None else "disabled")
        self._actions.update_pin(saved_target(record))

    def _save_favorite(self):
        server = self.server_list.selected
        if server is None:
            return
        record = self._favorite_record(server)
        config = stock.load_cfg()
        saved = config.get("saved_servers", [])
        self._favorites = saved if isinstance(saved, list) else []
        if not self._find_favorite(record):
            self._favorites.append(record)
            config["saved_servers"] = self._favorites
            stock.save_cfg(config)
        self._update_actions()
