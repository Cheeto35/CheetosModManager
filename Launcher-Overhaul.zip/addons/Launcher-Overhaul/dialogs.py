"""Show launcher-owned notices and input prompts in the current window."""

import tkinter as tk
from tkinter import messagebox, simpledialog

from .widgets import BG, BORDER, DISPLAY, FIELD, FOCUS, SECONDARY, SURF, UI, button, frame, label, scrollbar, styles


BUTTONS = {
    "ok": (("ok", "OK"),),
    "okcancel": (("ok", "OK"), ("cancel", "Cancel")),
    "yesno": (("yes", "Yes"), ("no", "No")),
    "yesnocancel": (("yes", "Yes"), ("no", "No"), ("cancel", "Cancel")),
    "retrycancel": (("retry", "Retry"), ("cancel", "Cancel")),
    "abortretryignore": (("abort", "Abort"), ("retry", "Retry"), ("ignore", "Ignore")),
}


def _exists(widget):
    try:
        return bool(widget is not None and widget.winfo_exists())
    except tk.TclError:
        return False


def active(root):
    """Return the current in-window prompt, if one is open."""
    overlay = getattr(root, "_overhaul_prompt", None)
    return overlay if _exists(overlay) else None


def prompt_surface(root, owner):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if owner is root and dashboard is not None and dashboard.workspace.winfo_viewable():
        return dashboard.workspace
    return owner


def install(root):
    original_show = messagebox._show
    readers = {name: getattr(simpledialog, name) for name in ("askstring", "askinteger", "askfloat")}

    def launcher_owner(parent):
        parent = parent or tk._default_root
        if not isinstance(parent, tk.Misc) or not _exists(parent):
            return None
        owner = parent.winfo_toplevel()
        while parent is not None and parent is not root:
            parent = getattr(parent, "master", None)
        return owner if parent is root and owner.winfo_viewable() else None

    def show(title=None, message=None, _icon=None, _type=None, **options):
        owner = launcher_owner(options.get("parent"))
        kind = options.get("type") or _type or "ok"
        if owner is None or kind not in BUTTONS:
            return original_show(title, message, _icon, _type, **options)
        detail = options.get("detail")
        text = str(message or "")
        if detail:
            text += "\n\n" + str(detail)
        return _present(root, owner, title, text, kind, default=options.get("default"),
                        icon=options.get("icon") or _icon)

    def query(name):
        original = readers[name]
        accepted = {"parent", "initialvalue", "minvalue", "maxvalue"}
        if name == "askstring":
            accepted.add("show")

        def ask(title, prompt, **options):
            owner = launcher_owner(options.get("parent"))
            if owner is None or options.keys() - accepted:
                return original(title, prompt, **options)
            return _present(root, owner, title, str(prompt), "okcancel", query=(name, options))

        return ask

    messagebox._show = show
    queries = {name: query(name) for name in readers}
    for name, ask in queries.items():
        setattr(simpledialog, name, ask)

    def restore(event):
        if event.widget is not root:
            return
        if messagebox._show is show:
            messagebox._show = original_show
        for name, ask in queries.items():
            if getattr(simpledialog, name) is ask:
                setattr(simpledialog, name, readers[name])

    root.bind("<Destroy>", restore, add="+")


def _present(root, owner, title, text, kind, **options):
    # A stock tool can still have its own window. Its prompts stay within that
    # window and borrow the dashboard palette only while they are on screen.
    borrowed = not hasattr(owner, "_overhaul_widget_colors")
    if borrowed:
        owner._overhaul_widget_colors = root._overhaul_widget_colors
    try:
        return _Overlay(root, owner, title, text, kind, **options).run()
    finally:
        if borrowed:
            del owner._overhaul_widget_colors


class _Overlay(tk.Frame):
    def __init__(self, root, owner, title, text, kind, *, default=None, icon=None, query=None,
                 caption=None, width_limit=490, minimum_lines=2):
        super().__init__(prompt_surface(root, owner))
        self._overhaul_theme_exempt = True
        styles(self).bind(self, bg=BG)
        self.root = root
        self.owner = owner
        self.message = text
        self.query = query
        self.width_limit = width_limit
        self.minimum_lines = minimum_lines
        choices = BUTTONS[kind]
        available = {value for value, _ in choices}
        self.preferred = default if default in available else choices[0][0]
        self.dismiss = next(value for value in ("cancel", "no", "ok", "abort") if value in available)
        self.result = None if query else self.dismiss
        self.entry = None
        self.buttons = {}
        self._fit_job = None

        self.panel = frame(self, SURF, border=True)
        self.panel.place(relx=.5, rely=.5, anchor="center", width=1)
        header = frame(self.panel)
        header.pack(fill="x", padx=13, pady=(10, 7))
        self.back_button = button(header, "← Back", self.cancel, compact=True)
        self.back_button.pack(side="left", padx=(0, 10))
        heading_block = frame(header)
        heading_block.pack(side="left", fill="x", expand=True)
        self.heading = label(heading_block, title or "The Modding Tavern", size=13, family=DISPLAY,
                             weight="bold", justify="left")
        self.heading.pack(fill="x")
        self.caption = None
        if caption:
            self.caption = label(heading_block, caption, size=9, color=SECONDARY, justify="left")
            self.caption.pack(fill="x", pady=(3, 0))

        controls = frame(self.panel)
        controls.pack(side="bottom", fill="x", padx=13, pady=(0, 11))
        controls.columnconfigure(tuple(range(len(choices))), weight=1, uniform="actions")
        for index, (value, caption) in enumerate(choices):
            action = button(controls, caption, lambda value=value: self._answer(value),
                            primary=value == self.preferred, compact=True)
            action.grid(row=0, column=index, sticky="ew", padx=(6 if index else 0, 0))
            self.buttons[value] = action

        if query is not None:
            self._build_input(query[1])

        body = frame(self.panel, SURF, border=True)
        body.pack(fill="both", expand=True, padx=13, pady=(0, 8))
        marker = frame(body, width=3)
        marker.pack(side="left", fill="y")
        styles(self).bind(marker, bg={"error": "STATUS_ERROR", "warning": "STATUS_WARNING"}.get(icon, "PANEL_ACCENT"))
        self.text = tk.Text(body, font=(UI, 10), width=1, height=minimum_lines, relief="flat", bd=0,
                            highlightthickness=1, wrap="word", padx=9, pady=5, takefocus=True)
        styles(self).bind(self.text, bg=SURF, fg="PARCH", highlightbackground=SURF, highlightcolor=FOCUS,
                          selectbackground="ACTIVE_TAB", selectforeground="ACTIVE_TEXT")
        self.bar = scrollbar(body, self.text.yview)
        self.text.configure(yscrollcommand=self._scrollbar_state)
        self.text.insert("1.0", text)
        self.text.configure(state="disabled")
        self.text.pack(fill="both", expand=True)
        self._bind_keys()
        self.bind("<Configure>", self._resize)

    def _build_input(self, options):
        body = frame(self.panel)
        body.pack(side="bottom", fill="x", padx=13, pady=(0, 9))
        self.entry = tk.Entry(body, width=1, show=options.get("show") or "", font=(UI, 10),
                              relief="flat", bd=5, highlightthickness=1)
        styles(self).bind(self.entry, bg=FIELD, fg="FIELD_TEXT", insertbackground="FIELD_TEXT",
                          highlightbackground=BORDER, highlightcolor=FOCUS,
                          selectbackground="ACTIVE_TAB", selectforeground="ACTIVE_TEXT")
        self.entry.pack(fill="x")
        if options.get("initialvalue") is not None:
            self.entry.insert(0, options["initialvalue"])
            self.entry.select_range(0, "end")
        self.error = label(body, size=9, color="STATUS_ERROR", justify="left")

    def _bind_keys(self):
        self.focus_order = [self.back_button, self.text]
        if self.entry is not None:
            self.focus_order.append(self.entry)
        self.focus_order.extend(self.buttons.values())
        values = {widget: value for value, widget in self.buttons.items()}
        for widget in self.focus_order:
            widget.bind("<Escape>", self.cancel)
            widget.bind("<F1>", lambda event: "break")
            widget.bind("<Tab>", lambda event, control=widget: self._focus_next(control, 1))
            widget.bind("<Shift-Tab>", lambda event, control=widget: self._focus_next(control, -1))
            widget.bind("<ISO_Left_Tab>", lambda event, control=widget: self._focus_next(control, -1))
            choice = self.dismiss if widget is self.back_button else values.get(widget, self.preferred)
            for sequence in ("<Return>", "<KP_Enter>"):
                widget.bind(sequence, lambda event, value=choice: self._answer(value))

    def _focus_next(self, widget, step):
        index = (self.focus_order.index(widget) + step) % len(self.focus_order)
        self.focus_order[index].focus_set()
        return "break"

    def _scrollbar_state(self, first, last):
        self.bar.set(first, last)
        if float(last) - float(first) < 1:
            if not self.bar.winfo_manager():
                self.bar.pack(side="right", fill="y", before=self.text)
        elif self.bar.winfo_manager():
            self.bar.pack_forget()

    def _resize(self, event=None):
        width = min(self.width_limit, max(1, self.winfo_width() - 20))
        heading_width = max(80, width - self.back_button.winfo_reqwidth() - 45)
        self.heading.configure(wraplength=heading_width)
        if self.caption is not None:
            self.caption.configure(wraplength=heading_width)
        font = self.text.cget("font")
        available = max(100, width - 65)
        lines = sum(max(1, (int(self.tk.call("font", "measure", font, line)) + available - 1) // available)
                    for line in self.message.split("\n"))
        self.text.configure(height=min(15, max(self.minimum_lines, lines)))
        if self.query:
            self.error.configure(wraplength=max(80, width - 30))
        self.panel.place_configure(width=width)
        if self._fit_job is None:
            self._fit_job = self.after_idle(self._fit)

    def _fit(self):
        self._fit_job = None
        self.panel.place_configure(height=min(self.panel.winfo_reqheight(), max(1, self.winfo_height() - 20)))

    def _invalid(self, reason):
        self.error.configure(text=reason)
        if not self.error.winfo_manager():
            self.error.pack(fill="x", pady=(5, 0))
        self.entry.focus_set()
        self._resize()
        return "break"

    def _answer(self, choice):
        if self.query is not None and choice == "ok":
            name, options = self.query
            read = {"askstring": str, "askinteger": self.getint, "askfloat": self.getdouble}[name]
            try:
                result = read(self.entry.get())
            except (ValueError, tk.TclError):
                return self._invalid("Enter a whole number." if name == "askinteger" else "Enter a number.")
            minimum, maximum = options.get("minvalue"), options.get("maxvalue")
            if minimum is not None and result < minimum:
                return self._invalid(f"Use a value of at least {minimum}.")
            if maximum is not None and result > maximum:
                return self._invalid(f"Use a value no greater than {maximum}.")
            self.result = result
        elif self.query is None:
            self.result = choice
        self.destroy()
        return "break"

    def cancel(self, event=None):
        return self._answer(self.dismiss)

    def run(self):
        previous = active(self.root)
        try:
            previous_focus = self.owner.focus_get()
        except KeyError:
            previous_focus = None
        previous_grab = self.owner.grab_current()
        grab_status = previous_grab.grab_status() if previous_grab is not None else None
        self.root._overhaul_prompt = self
        try:
            self.place(x=0, y=0, relwidth=1, relheight=1)
            self.lift()
            self.owner.update_idletasks()
            self.grab_set()
            (self.entry if self.entry is not None else self.buttons[self.preferred]).focus_set()
            self.owner.wait_window(self)
        finally:
            self.root._overhaul_prompt = previous
            if _exists(self):
                self.destroy()
            if _exists(previous_grab) and previous_grab.winfo_viewable():
                (previous_grab.grab_set_global if grab_status == "global" else previous_grab.grab_set)()
            if _exists(previous_focus) and previous_focus.winfo_viewable():
                previous_focus.focus_set()
        return self.result

    def destroy(self):
        if self._fit_job is not None:
            self.after_cancel(self._fit_job)
            self._fit_job = None
        super().destroy()
