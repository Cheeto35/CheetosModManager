# The Modding Tavern Launcher Overhaul

The Overhaul add-on replaces Small Screen Support for the TavernLauncher client. It keeps the tavern palette and organizes the client around four views.

- **Play** has server entry, saved and community servers, Join Server, Main Menu, and recent activity.
- **Setup & Tools** has the game path, patching, mods, and preferences alongside TavernKeeper, Remote Console, tickets, Add-ons, and cache controls.
- **Activity** has the live game log and its archive action.
- **Help** opens the launcher guides and support links inside the window. Press **F1** to open it from the launcher.

The workspace adapts to narrow windows and scrolls when needed. Keyboard focus moves clipped controls into view.

Play keeps Join and launch progress within reach as you scroll. Continue playing appears after the launcher successfully starts the game on a server. Pin a server in Saved & Recent or Community Servers to add a shortcut to Play. The launcher remembers your window size and position after the first run.

Browse Saved & Recent and Community Servers in the launcher. Use scene, search, and sort controls to narrow the community list. Game Settings groups options by what they control, and Server Tickets shows the conversation beside the ticket list when the window is wide enough.

Open **Setup & Tools → Launcher colors → Edit** to preview and save your accent, background, and panel colors. Choose a preset, use the color picker, or enter hex values. **Reset** returns to the tavern palette and **Save** keeps the new colors for future launches.

Launcher tools, Appearance, server lists, and add-on settings open in the main window. **← Back** returns to the previous page. Confirmations and input prompts use the same launcher colors. Windows supplies the file and color pickers.

Prefabulator is a separate add-on. When enabled, its shortcut appears in **Setup & Tools** and opens the add-on's own editor. When **Main Menu Launch** is enabled, the **Main Menu** button on Play uses that add-on. Otherwise it uses TavernLauncher's built-in action.

## Install on TavernLauncher Client 1.8.5

1. Close the launcher and back up the previous Launcher Overhaul folder outside `addons`.
2. Extract the new `small_screen` folder into `addons`. Enable **Launcher Overhaul** in the Add-ons manager, save, and restart.
3. Keep **Sheikah Mods** installed as its own add-on. With Sheikah Mods 1.2.2 enabled, its controls and launch review open in the launcher. Its next-launch status appears in Play.

