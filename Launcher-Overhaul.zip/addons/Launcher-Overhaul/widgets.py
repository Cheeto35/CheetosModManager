"""Theme-aware Tk controls used by the launcher dashboard."""

import tkinter as tk
from tkinter import ttk
from weakref import WeakKeyDictionary

from tavern_shared import theme as stock


BG, SURF, SURF2, BORDER, AMBER, PARCH, SECONDARY, FIELD, FOCUS = (
    "BG", "SURF", "SURF2", "BORDER", "AMBER", "PARCH", "SECONDARY", "FIELD", "FOCUS"
)
UI = "Segoe UI"
DISPLAY = "Georgia"


class WidgetColors:
    def __init__(self, root, colors):
        self.colors = colors
        self.widgets = WeakKeyDictionary()
        self.styles = ttk.Style(root)
        self._update_styles()

    def bind(self, widget, **roles):
        options = self.widgets.setdefault(widget, {})
        options.update(roles)
        tk.Misc.configure(widget, **{key: self.colors[role] for key, role in roles.items()})
        return widget

    def apply(self, colors):
        self.colors = colors
        for widget, roles in list(self.widgets.items()):
            if widget.winfo_exists():
                tk.Misc.configure(widget, **{key: colors[role] for key, role in roles.items()})
        self._update_styles()

    def _update_styles(self):
        c = self.colors
        name = "Overhaul.TCombobox"
        self.styles.configure(name, fieldbackground=c[FIELD], background=c[SURF2],
                              foreground=c["FIELD_TEXT"], arrowcolor=c["SURF2_TEXT"],
                              borderwidth=1, padding=(8, 5), arrowsize=12,
                              lightcolor=c[FIELD], darkcolor=c[FIELD], bordercolor=c[BORDER])
        self.styles.map(name, bordercolor=[("focus", c[FOCUS])],
                        background=[("active", c["SECONDARY_HOVER"])],
                        fieldbackground=[("readonly", c[FIELD])],
                        foreground=[("readonly", c["FIELD_TEXT"])],
                        selectbackground=[("readonly", c[FIELD])],
                        selectforeground=[("readonly", c["FIELD_TEXT"])])
        self._update_list_styles(c)
        for orient in ("Vertical", "Horizontal"):
            name = f"Overhaul.{orient}.TScrollbar"
            self.styles.configure(name, background=c[SURF2], troughcolor=c[BG], bordercolor=c[BORDER],
                                  arrowcolor=c["SURF2_TEXT"], darkcolor=c[SURF2], lightcolor=c[SURF2],
                                  arrowsize=11, gripcount=0, relief="flat")
            self.styles.map(name, background=[("active", c["SECONDARY_HOVER"]), ("pressed", c[FOCUS])])

    def _update_list_styles(self, c):
        line_height = int(self.styles.tk.call("font", "metrics", (UI, 10), "-linespace"))
        self.styles.configure("Overhaul.Treeview", font=(UI, 10), rowheight=line_height + 10,
                              background=c[SURF], fieldbackground=c[SURF], foreground=c[PARCH],
                              borderwidth=0, relief="flat", lightcolor=c[SURF], darkcolor=c[SURF])
        self.styles.map("Overhaul.Treeview", background=[("selected", c["ACTIVE_TAB"])],
                        foreground=[("selected", c["ACTIVE_TEXT"])])
        self.styles.configure("Overhaul.Treeview.Heading", font=(UI, 9, "bold"), padding=(8, 6),
                              background=c[SURF2], foreground=c["SURF2_TEXT"], borderwidth=0,
                              relief="flat", lightcolor=c[SURF2], darkcolor=c[SURF2])
        self.styles.map("Overhaul.Treeview.Heading", background=[("active", c["SECONDARY_HOVER"])])

def styles(widget):
    return widget.winfo_toplevel()._overhaul_widget_colors


def style_status(widget):
    roles = {stock.GREEN: "STATUS_OK", stock.RED: "STATUS_ERROR", stock.AMBER: "STATUS_WARNING",
             stock.MUTED: SECONDARY}
    original = widget.configure

    def configure(cnf=None, **options):
        if isinstance(cnf, dict):
            options = {**cnf, **options}
            cnf = None
        role = roles.get(options.get("fg"))
        if role is not None:
            styles(widget).bind(widget, fg=role)
            del options["fg"]
        return original(cnf, **options)

    widget.configure = widget.config = configure
    widget.configure(fg=widget.cget("fg"))


def background(parent):
    return styles(parent).widgets.get(parent, {}).get("bg", BG)


def frame(parent, surface=None, *, border=False, **options):
    widget = tk.Frame(parent, highlightthickness=int(border), **options)
    roles = {"bg": surface or background(parent)}
    if border:
        roles["highlightbackground"] = BORDER
    return styles(widget).bind(widget, **roles)


def label(parent, text="", *, size=10, color=PARCH, weight="normal", family=UI, anchor="w", **options):
    surface = background(parent)
    if color == PARCH:
        color = {BG: "BG_TEXT", FIELD: "FIELD_TEXT", SURF2: "SURF2_TEXT"}.get(surface, PARCH)
    elif color == SECONDARY and surface == BG:
        color = "BG_SECONDARY"
    widget = tk.Label(parent, text=text, font=(family, size, weight), anchor=anchor, **options)
    return styles(widget).bind(widget, bg=surface, fg=color)


class ActionButton(tk.Button):
    # The stock launcher animates some buttons and restores their stock colors.
    def configure(self, cnf=None, **options):
        if isinstance(cnf, dict):
            options = {**cnf, **options}
            cnf = None
        if "bg" in options or "fg" in options:
            color = styles(self).colors
            for option, replacements in (
                ("bg", {stock.SURF2: color[SURF2], stock.AMBERDIM: color["ACTIVE_TAB"],
                        stock.RED: color["ALERT_SURFACE"]}),
                ("fg", {stock.PARCH: color["SURF2_TEXT"], stock.AMBER: color["ACTIVE_TEXT"]}),
            ):
                if option in options:
                    options[option] = replacements.get(options[option], options[option])
        return super().configure(cnf, **options)

    config = configure


def button(parent, text, command, *, primary=False, compact=False):
    widget = ActionButton(parent, text=text, command=command, relief="flat", bd=0, takefocus=True,
                          highlightthickness=1, cursor="hand2", font=(UI, 10, "bold"),
                          padx=10, pady=5 if compact else 9)
    set_button_priority(widget, primary)
    return styles(widget).bind(widget, disabledforeground="DISABLED", highlightcolor=FOCUS,
                               highlightbackground=background(parent))


def set_button_priority(widget, primary):
    return styles(widget).bind(widget, bg=AMBER if primary else SURF2,
                               fg="PRIMARY_TEXT" if primary else "SURF2_TEXT",
                               activebackground="PRIMARY_HOVER" if primary else "SECONDARY_HOVER",
                               activeforeground="PRIMARY_TEXT" if primary else "SECONDARY_HOVER_TEXT")


def card(parent, title, subtitle=None):
    outer = frame(parent, SURF, border=True)
    inner = frame(outer)
    inner.pack(fill="both", expand=True, padx=16, pady=14)
    label(inner, title, size=15, weight="bold", family=DISPLAY, wraplength=255, justify="left").pack(fill="x")
    if subtitle:
        label(inner, subtitle, color=SECONDARY, justify="left", wraplength=235).pack(anchor="w", pady=(5, 0))
    return outer, inner


def text_field(parent, title, variable, size=12):
    outer = frame(parent)
    label(outer, title, size=9, color=SECONDARY, weight="bold").pack(fill="x", pady=(0, 5))
    widget = tk.Entry(outer, textvariable=variable, width=size, font=(UI, 10), relief="flat", bd=7,
                      highlightthickness=1)
    styles(widget).bind(widget, bg=FIELD, fg="FIELD_TEXT", insertbackground="FIELD_TEXT", selectbackground="ACTIVE_TAB",
                        selectforeground="ACTIVE_TEXT", highlightbackground=BORDER, highlightcolor=FOCUS)
    widget.pack(fill="x")
    return outer, widget


def _mk_combobox(parent, variable, values):
    widget = ttk.Combobox(parent, textvariable=variable, values=values, state="readonly", style="Overhaul.TCombobox")
    widget.pack(fill="x")

    def style_popdown(event=None):
        def configure():
            c = styles(widget).colors
            try:
                popdown = widget.tk.call("ttk::combobox::PopdownWindow", str(widget))
                widget.tk.call(f"{popdown}.f.l", "configure", "-background", c[FIELD], "-foreground", c["FIELD_TEXT"],
                               "-selectbackground", c["ACTIVE_TAB"], "-selectforeground", c["ACTIVE_TEXT"])
            except tk.TclError:
                pass
        widget.after_idle(configure)

    widget.bind("<Button-1>", style_popdown, add="+")
    widget.bind("<Alt-Down>", style_popdown, add="+")
    return widget


def scrollbar(parent, command):
    return ttk.Scrollbar(parent, orient="vertical", command=command, style="Overhaul.Vertical.TScrollbar")
