"""Install the client dashboard through TavernLauncher's add-on loader."""

import sys
import tkinter as tk

from client.core import launcher_window as stock
from tavern_shared.theme import BG, RED, SURF2

from . import dialog_theme, dialogs, sheikah_page
from .addon_compat import main_menu_action, suppress_menu_button
from .interface import BRAND, Dashboard, button
from .widgets import FOCUS, SURF, SURF2 as CONTROL_SURFACE, style_status, styles


Launcher = stock.ClientLauncher
original_init = Launcher.__init__
original_build = Launcher._build_ui
original_help = stock.attach_help_tab
original_menu = Launcher._refresh_menu_btn
original_token = Launcher._show_token_button
original_token_click = Launcher._on_token_button_click
original_print = Launcher._print
original_join = Launcher._on_join_clicked
original_archive = Launcher._archive_log_with_tailer_paused
original_launch = Launcher._do_launch
original_headless = Launcher._do_launch_headless
original_menu_launch = Launcher._do_launch_menu
original_patch = Launcher._on_patch_click
original_tools = Launcher._refresh_tool_states
original_check_ok = Launcher._check_ok
original_mods_alert = Launcher._set_mods_alert
original_start_patch_alert = Launcher._start_patch_animation
original_stop_patch_alert = Launcher._stop_patch_animation


def _initialize(self, *args, **kwargs):
    self._overhaul_main_menu = main_menu_action()
    with suppress_menu_button(self):
        original_init(self, *args, **kwargs)
    dashboard = getattr(self, "_launcher_overhaul", None)
    if dashboard is not None:
        self.after(0, dashboard.fit_opening_window)


def _build_dashboard(self, *args, **kwargs):
    # Build the stock widgets in an unmapped frame to initialize the launcher's
    # variables, callbacks, and add-on hooks before installing the new views.
    stock_widgets = tk.Frame(self, bg=BG)
    setup = tk.BaseWidget._setup

    def use_stock_frame(widget, master, options):
        if master is self and not isinstance(widget, tk.Toplevel):
            master = stock_widgets
        setup(widget, master, options)

    tk.BaseWidget._setup = use_stock_frame
    try:
        result = original_build(self, *args, **kwargs)
    finally:
        tk.BaseWidget._setup = setup

    # Sheikah discovers the Mods widget by its caption during its idle hook.
    self._mods_btn.configure(text="")
    registered = getattr(self, "_named_buttons", {})
    prefabulator = getattr(sys.modules.get("addons.prefab_editor.client"), "open_prefabulator", None)
    self._launcher_overhaul = dashboard = Dashboard(self, self.log, prefabulator)
    dialog_theme.attach(self, lambda: dashboard.palette)
    dialogs.install(self)
    self.title(f"{BRAND} — Launcher")
    # Newer clients have their own viewport. The dashboard supplies the sizing
    # for its visible window while the stock viewport is unmapped.
    original_fit = getattr(self, "_screen_fit", None)
    if original_fit is not None:
        original_fit._fitted = True

    if registered:
        visible = {
            "patch": self._patch_btn, "mods": self._mods_btn, "join": self._action_btn,
            "check": self._check_btn, "menu": self._menu_btn, "tickets": self._tickets_btn,
            "saved": dashboard.saved, "community": dashboard.community,
            "remote_console": dashboard.console, "tavernkeeper": dashboard.keeper,
        }
        for name, widget in tuple(registered.items()):
            if name not in visible:
                action = button(dashboard.extra_actions, widget.cget("text"), widget.invoke, compact=True)
                action.pack(fill="x", pady=(5, 0))
                visible[name] = action
        registered.update(visible)

    stock.start_flashing_button(self._tickets_btn, lambda: self._has_unseen_ticket_reply,
                                normal_bg=SURF2, alert_bg=RED)
    self.after_idle(lambda: self.after_idle(lambda: _place_sheikah(self)))
    return result


def _place_sheikah(launcher):
    addon = sys.modules.get("addons.sheikah_mods.client")
    sheikah_page.attach(launcher, addon)
    attach = getattr(addon, "_ensure_button", None)
    if attach is not None:
        existing = getattr(launcher, "_sheikah_button", None)
        if existing is not None and existing.master is not launcher._mods_btn.master:
            existing.destroy()
            launcher._sheikah_button = None
        attach(launcher)
    status = getattr(launcher, "_sheikah_next_status", None)
    if status is not None:
        status.master.unbind("<Configure>")
        styles(launcher).bind(status.master, bg=SURF)
        styles(launcher).bind(status, bg=SURF)
        style_status(status)
        status.configure(width=1, height=2, anchor="w", wraplength=190)
        dashboard = launcher._launcher_overhaul
        dashboard._resize(dashboard.winfo_width(), dashboard.pane.winfo_width())
    widget = getattr(launcher, "_sheikah_button", None)
    if widget is not None:
        widget.configure(takefocus=True, highlightthickness=1, font=("Segoe UI", 10, "bold"),
                         padx=10, pady=5)
        widget.pack_configure(side="top", fill="x", padx=0, pady=(5, 0))
        styles(launcher).bind(widget, bg=CONTROL_SURFACE, fg="SURF2_TEXT", activebackground="SECONDARY_HOVER",
                              activeforeground="SECONDARY_HOVER_TEXT", highlightbackground=SURF, highlightcolor=FOCUS)


def _attach_help(root):
    if getattr(root, "_launcher_overhaul", None) is None:
        return original_help(root)


def _refresh_main_menu(root):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is None:
        return original_menu(root)
    dashboard.refresh()


def _show_token(root):
    result = original_token(root)
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is not None:
        dashboard.refresh_token()
    return result


def _open_token(root):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is not None:
        return dashboard.open_token()
    return original_token_click(root)


def _print(root, msg, tag=""):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is not None:
        dashboard.launch_flow.observe(msg, tag)
    result = original_print(root, msg, tag)
    if dashboard is not None:
        dashboard.update_recent_activity()
    return result


def _join(root):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is None:
        return original_join(root)
    return dashboard.launch_flow.request_join(lambda: original_join(root))


def _archive(root, on_done):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is None:
        return original_archive(root, on_done)
    return dashboard.launch_flow.archive(on_done)


def _track_launch(original, mode):
    def launch(root, *args, **kwargs):
        dashboard = getattr(root, "_launcher_overhaul", None)
        if dashboard is None:
            return original(root, *args, **kwargs)
        return dashboard.launch_flow.launch(mode, lambda: original(root, *args, **kwargs))
    return launch


def _launch_menu(root, *args, **kwargs):
    provider = getattr(root, "_overhaul_main_menu", None)
    call = (lambda: provider(root)) if provider is not None else lambda: original_menu_launch(root, *args, **kwargs)
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is None:
        return call()
    return dashboard.launch_flow.launch("menu", call)


def _patch(root):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is None:
        return original_patch(root)
    return dashboard.launch_flow.patch()


def _refresh_tools(root):
    result = original_tools(root)
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is not None:
        dashboard.refresh_launch()
    return result


def _check_ok(root, host, message, game_port=None):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is not None and dashboard.launch_flow.busy:
        game_port = None
    result = original_check_ok(root, host, message, game_port)
    if dashboard is not None:
        dashboard.refresh_launch()
    return result


def _mods_alert(root, needed):
    dashboard = getattr(root, "_launcher_overhaul", None)
    if dashboard is None:
        return original_mods_alert(root, needed)
    dashboard.tool_warning("mods", needed)


def _patch_alert(original, needed):
    def update(root):
        dashboard = getattr(root, "_launcher_overhaul", None)
        if dashboard is None:
            return original(root)
        dashboard.tool_warning("patch", needed)
    return update


Launcher.__init__ = _initialize
Launcher._build_ui = _build_dashboard
Launcher._refresh_menu_btn = _refresh_main_menu
Launcher._show_token_button = _show_token
Launcher._on_token_button_click = _open_token
Launcher._print = _print
Launcher._on_join_clicked = _join
Launcher._archive_log_with_tailer_paused = _archive
Launcher._do_launch = _track_launch(original_launch, "join")
Launcher._do_launch_headless = _track_launch(original_headless, "join")
Launcher._do_launch_menu = _launch_menu
Launcher._on_patch_click = _patch
Launcher._refresh_tool_states = _refresh_tools
Launcher._check_ok = _check_ok
Launcher._set_mods_alert = _mods_alert
Launcher._start_patch_animation = _patch_alert(original_start_patch_alert, True)
Launcher._stop_patch_animation = _patch_alert(original_stop_patch_alert, False)
stock.attach_help_tab = _attach_help
