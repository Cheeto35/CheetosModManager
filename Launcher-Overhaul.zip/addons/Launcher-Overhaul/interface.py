"""The client launcher dashboard and its in-window Help view."""

import os
import re
import tkinter as tk
import webbrowser
from dataclasses import dataclass
from tkinter import messagebox

from client.core import launcher_window as stock
from client.version import APP_VERSION
from tavern_shared import help_pane

from .appearance import AppearancePage, _readable as readable, load_colors, palette, rgb, save_colors as persist_colors
from .community_page import CommunityPage
from . import dialog_theme, dialogs
from .help_reader import guide_html
from .keeper_page import TavernKeeperPage
from .launch_center import LaunchCenter, _fit_two_lines
from .launch_flow import LaunchFlow
from .launch_history import LaunchTarget, load_history, record_launch, set_pinned, toggle_pin
from .library_pages import AddonsPage, SavedServersPage, server_address
from .settings_page import SettingsPage
from .tool_pages import ModsPage, RemoteConsolePage, TicketsPage
from .viewport import ScrollPane, fit_window, opening_size
from .widgets import (
    AMBER, BG, BORDER, DISPLAY, FIELD, FOCUS, PARCH, SECONDARY, SURF, SURF2, UI,
    WidgetColors, _mk_combobox, button, card, frame, label, scrollbar, set_button_priority, style_status, styles,
    text_field,
)


BRAND = "The Modding Tavern"
SETUP_TOOLS = "Setup & Tools"
PAGE_PADDING_Y = (16, 20)


@dataclass
class DetailPage:
    title: str
    frame: tk.Frame
    source: tk.Widget
    previous_scroll: tuple
    content: tk.Widget = None


GLYPHS = {
    "Play": ((6, 4, 17, 11, 6, 18, 6, 4),),
    SETUP_TOOLS: ((4, 7, 18, 7), (4, 15, 18, 15), (9, 4, 9, 10), (14, 12, 14, 18)),
    "Activity": ((4, 17, 4, 13), (9, 17, 9, 8), (14, 17, 14, 11), (19, 17, 19, 4)),
    "Help": ((3, 5, 8, 5, 11, 8, 14, 5, 19, 5, 19, 16, 14, 16, 11, 19, 8, 16, 3, 16, 3, 5),
             (11, 8, 11, 19)),
}


def _navigation_icon(master, lines):
    # Use a transparent bitmap so the native button paints the icon's background.
    width, height = 28, 22
    stride = (width + 7) // 8
    pixels = bytearray(stride * height)
    for line in lines:
        points = list(zip(line[::2], line[1::2]))
        for (x, y), (end_x, end_y) in zip(points, points[1:]):
            dx, dy = end_x - x, end_y - y
            distance = max(abs(dx), abs(dy), 1)
            for step in range(distance + 1):
                px = x + round(dx * step / distance)
                py = y + round(dy * step / distance)
                pixels[py * stride + px // 8] |= 1 << (px % 8)
    bits = ", ".join(f"0x{value:02x}" for value in pixels)
    return tk.BitmapImage(master=master, data=(
        f"#define glyph_width {width}\n#define glyph_height {height}\n"
        f"static unsigned char glyph_bits[] = {{ {bits} }};"
    ))


class Banner(tk.Canvas):
    def __init__(self, parent):
        super().__init__(parent, width=1, height=1, highlightthickness=0, bd=0, takefocus=False)
        styles(self).bind(self, bg=SURF)
        self.art = self.create_image(0, 0, anchor="nw")
        self.mark = self.create_rectangle(24, 49, 56, 52, outline="")
        self.heading = self.create_text(22, 91, text=BRAND, anchor="w",
                                        font=(DISPLAY, 32, "bold"))
        self.photo = None
        self.render_job = None
        self.compact = False
        self.bind("<Configure>", self.queue)

    def set_compact(self, compact):
        self.compact = compact
        self.configure(height=126 if compact else 1)
        for item in (self.mark, self.heading):
            self.itemconfigure(item, state="normal" if compact else "hidden")
        self.queue()

    def queue(self, event=None):
        if self.render_job is not None:
            self.after_cancel(self.render_job)
        self.render_job = self.after(35, self.redraw)

    def redraw(self):
        self.render_job = None
        width, height = self.winfo_width(), self.winfo_height()
        if width < 2 or height < 2:
            return
        colors = styles(self).colors
        source = stock._HEADER_BANNER_IMG
        if self.compact:
            desired = 28 if width >= 630 else 23
            self.itemconfigure(self.heading, font=(DISPLAY, desired, "bold"),
                               fill=colors["HERO_TEXT"] if source is not None else colors[PARCH])
            left, _, right, _ = self.bbox(self.heading)
            if right - left > width - 44:
                fitted = max(10, int(desired * (width - 44) / (right - left)))
                self.itemconfigure(self.heading, font=(DISPLAY, fitted, "bold"))
            self.coords(self.heading, 22, height // 2 + 12)
            self.coords(self.mark, 24, height // 2 - 25, 56, height // 2 - 22)
            self.itemconfigure(self.mark, fill=colors[AMBER])
        if source is None:
            return
        image = stock._PILImage
        crop_w = min(source.width, round(source.height * width / height))
        crop_h = min(source.height, round(source.width * height / width))
        x = round((source.width - crop_w) * .63)
        y = round((source.height - crop_h) * .46)
        base = source.crop((x, y, x + crop_w, y + crop_h)).resize((width, height), image.LANCZOS)
        shade = image.new("RGBA", (width, 1))
        tone = (19, 14, 13) if self.compact else rgb(colors[SURF])
        if self.compact:
            opacity = [int(70 + 168 * max(0, 1 - x / (width * .85))) for x in range(width)]
        else:
            opacity = [int(20 + 235 * max(0, 1 - x / (width * .48)) ** 2) for x in range(width)]
        shade.putdata([(*tone, alpha) for alpha in opacity])
        base = image.alpha_composite(base.convert("RGBA"), shade.resize((width, height)))
        self.photo = stock._PILImageTk.PhotoImage(base, master=self)
        self.itemconfigure(self.art, image=self.photo)


class Dashboard(tk.Frame):
    def __init__(self, launcher, old_log, prefabulator_action=None):
        width, height = opening_size(launcher)
        self.colors = load_colors()
        self.palette = palette(self.colors)
        launcher._overhaul_widget_colors = WidgetColors(launcher, self.palette)
        super().__init__(launcher, width=width, height=height)
        styles(self).bind(self, bg=BG)
        styles(self).bind(launcher, bg=BG)
        self.launcher = launcher
        self.prefabulator_action = prefabulator_action
        self.grid_propagate(False)
        self.columnconfigure(1, weight=1)
        self.pack(fill="both", expand=True)
        self.pages = {}
        self.tabs = {}
        self.nav_icons = {}
        self.details = []
        self.page_titles = []
        self.current = None
        self.compact = None
        self.stacked = None
        self.tight = None
        self.tab_size = None
        self.help_doc = None
        self.help_slug = "index"
        self.help_topics = {name: slug for slug, name, _ in help_pane.PAGES}
        self.history = load_history()
        self.tool_warnings = {"patch": False, "mods": False}
        self.selected_label = None
        self.launch_flow = LaunchFlow(launcher, self.refresh_launch, self._current_target, self._record_launch)
        self._header()
        self.navigation = frame(self, SURF)
        self.nav_status = label(self.navigation, color=SECONDARY, size=9, justify="left", wraplength=132)
        self.workspace = frame(self, BG)
        self.detail_footer = frame(self.workspace, BG)
        self.detail_bar = frame(self.workspace, SURF, border=True)
        self.back_button = button(self.detail_bar, "← Back", self.back, compact=True)
        self.back_button.pack(side="left", padx=(10, 12), pady=6)
        self.detail_title = label(self.detail_bar, size=15, family=DISPLAY, weight="bold",
                                  wraplength=232, justify="left")
        self.detail_title.pack(side="left", fill="x", expand=True, pady=6)
        self.pane = ScrollPane(self.workspace)
        self.pane.pack(fill="both", expand=True)
        for widget in (self.pane, self.pane.canvas, self.pane.body):
            styles(self).bind(widget, bg=BG)
        self.pane.vertical.configure(style="Overhaul.Vertical.TScrollbar")
        self.pane.horizontal.configure(style="Overhaul.Horizontal.TScrollbar")
        for title in ("Play", SETUP_TOOLS, "Activity", "Help"):
            icon = _navigation_icon(self.navigation, GLYPHS[title])
            tab = button(self.navigation, title, lambda title=title: self.show(title), compact=True)
            tab.configure(compound="left")
            tab.bind("<Enter>", lambda event, icon=icon: icon.configure(
                foreground=event.widget.cget("activeforeground")), add="+")
            tab.bind("<Leave>", lambda event, icon=icon: icon.configure(
                foreground=event.widget.cget("foreground")), add="+")
            self.tabs[title] = tab
            self.nav_icons[title] = icon
            self.pages[title] = frame(self.pane.body, BG)

        self._play(self.pages["Play"])
        self._setup_tools(self.pages[SETUP_TOOLS])
        self._activity(self.pages["Activity"], old_log)
        self._help(self.pages["Help"])
        self.show("Play")
        self._resize(width, width - 170)
        self.bind("<Configure>", self._on_resize)
        self.pane.bind("<Configure>", self._on_resize)
        launcher.bind("<F1>", self._open_help, add="+")
        launcher.bind("<Escape>", self._escape_detail, add="+")
        for var in (launcher.v_exe, launcher.v_platform, launcher.v_ip, launcher.v_port):
            var.trace_add("write", self.refresh)
        launcher.v_ip.trace_add("write", self._clear_selected_label)
        launcher.v_port.trace_add("write", self._clear_selected_label)
        launcher.v_username.trace_add("write", self.refresh_launch)
        launcher._check_status.trace_add("write", self.refresh_notes)
        self.refresh()

    def _header(self):
        bar = frame(self, SURF)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        self.crest = tk.Canvas(bar, width=39, height=38, bd=0, highlightthickness=0, takefocus=False)
        styles(self).bind(self.crest, bg=SURF2)
        self.crest.create_line(19, 6, 30, 10, 29, 22, 24, 28, 19, 32, 14, 28, 9, 22, 8, 10, 19, 6,
                               width=1.5, joinstyle="round", tags="crest")
        self.crest.create_line(14, 15, 25, 15, 19.5, 15, 19.5, 25, width=1.5, tags="crest")
        self.crest.pack(side="left", padx=(13, 10), pady=9)
        label(bar, "TavernLauncher", size=15, weight="bold", family=DISPLAY).pack(side="left")
        self.build_label = label(bar, f"Client  ·  {APP_VERSION}", color=SECONDARY, size=9)
        self.build_label.pack(side="right", padx=14)

    def _play(self, page):
        root = self.launcher
        self.launch_center = LaunchCenter(page, lambda target: self._launch_saved(target, resume=True),
                                          self._launch_saved, self.open_saved, on_unpin=self._unpin)
        self.hero = frame(page, SURF, border=True)
        self.hero.pack(fill="x")
        self.banner = Banner(self.hero)
        self.join_card = frame(self.hero, SURF)
        join = frame(self.join_card, SURF)
        join.pack(fill="both", expand=True, padx=19, pady=16)
        self.play_title = label(join, BRAND, size=25, family=DISPLAY, weight="bold", wraplength=400, justify="left")
        self.play_title.pack(fill="x")
        self.side = frame(page, BG)
        self.side.pack(fill="x", pady=(12, 0))
        form = frame(join, SURF)
        form.pack(fill="x", pady=(12, 0))
        form.columnconfigure(0, weight=3)
        form.columnconfigure(1, weight=2)
        name, self.username_entry = text_field(form, "Player name", root.v_username)
        name.grid(row=0, column=0, padx=(0, 9), sticky="ew")
        platform = frame(form, SURF)
        platform.grid(row=0, column=1, sticky="ew")
        label(platform, "Play mode", size=9, color=SECONDARY, weight="bold").pack(fill="x", pady=(0, 5))
        holder = frame(platform, FIELD, border=True)
        holder.pack(fill="x")
        self.platform_combo = combo = _mk_combobox(holder, root.v_platform, ("SteamVR", "Quest", "Fly"))
        combo.configure(width=7, font=(UI, 10))
        combo.pack_configure(padx=3, pady=3, ipady=2)
        address, self.address_entry = text_field(form, "Server address", root.v_ip)
        address.grid(row=1, column=0, padx=(0, 9), pady=(11, 0), sticky="ew")
        port, self.port_entry = text_field(form, "Port", root.v_port, 5)
        port.grid(row=1, column=1, pady=(11, 0), sticky="ew")
        self.notes = frame(join, SURF)
        self.notes.columnconfigure(0, weight=1)
        self.destination_hint = label(self.notes, color=SECONDARY, size=9, wraplength=240, justify="left")
        self.destination_hint.grid(row=0, column=0, sticky="ew")
        root._check_label = label(self.notes, textvariable=root._check_status, color=SECONDARY, size=9,
                                  justify="left", wraplength=270)
        style_status(root._check_label)
        root._check_label.grid(row=1, column=0, sticky="ew")

        self.secondary_actions = secondary_actions = frame(join, SURF)
        secondary_actions.pack(fill="x", pady=(7, 0))
        secondary_actions.columnconfigure((0, 1), weight=1, uniform="launch")
        root._check_btn = button(secondary_actions, "Check server", root._do_check, compact=True)
        root._check_btn.grid(row=0, column=0, padx=(0, 5), sticky="ew")
        root._menu_btn = button(secondary_actions, "Main Menu", root._do_launch_menu, compact=True)
        root._menu_btn.grid(row=0, column=1, sticky="ew")

        self.server_card, servers = card(self.side, "Find a server")
        self.community = button(servers, "Community servers", self.open_community, compact=True)
        self.community.pack(fill="x", pady=(8, 5))
        self.saved = button(servers, "Saved & recent", self.open_saved, compact=True)
        self.saved.pack(fill="x")
        self.install_card, install = card(self.side, "Game installation")
        self.play_game_status = label(install, size=9, color=SECONDARY, wraplength=240, justify="left")
        self.play_game_status.pack(fill="x", pady=(6, 10))
        self.setup_button = button(install, SETUP_TOOLS, lambda: self.show(SETUP_TOOLS), compact=True)
        self.setup_button.pack(side="bottom", fill="x")

        latest = frame(page, SURF, border=True)
        latest.pack(fill="both", expand=True, pady=(12, 0))
        latest_inner = frame(latest, SURF)
        latest_inner.pack(fill="both", expand=True, padx=16, pady=10)
        self.activity_toolbar = toolbar = frame(latest_inner, SURF)
        toolbar.pack(fill="x")
        toolbar.columnconfigure(0, weight=1)
        label(toolbar, "Recent activity", size=14, weight="bold", family=DISPLAY).grid(row=0, column=0, sticky="w")
        self.view_log = button(toolbar, "View full log", lambda: self.show("Activity"), compact=True)
        self.view_log.grid(row=0, column=1, sticky="e")
        self.recent_activity = label(latest_inner, size=9, color=SECONDARY, family="Consolas",
                                     height=2, wraplength=244, justify="left")
        self.recent_activity.configure(anchor="nw")
        self.recent_activity.pack(fill="both", expand=True, pady=(4, 0))
        self._build_launch_dock()

    def _build_launch_dock(self):
        self.operation_dock = frame(self.workspace, SURF, border=True)
        self.launch_body = body = frame(self.operation_dock)
        body.pack(fill="x", padx=12, pady=8)
        body.columnconfigure(0, weight=1)
        status = frame(body)
        status.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        headline = frame(status)
        headline.pack(fill="x")
        self.launch_dot = label(headline, "●", size=9)
        self.launch_dot.pack(side="left", padx=(0, 6))
        self.launch_title = label(headline, size=10, weight="bold", width=1, justify="left")
        self.launch_title.pack(side="left", fill="x", expand=True)
        self.launch_detail = label(status, size=9, width=1, color=SECONDARY, justify="left")
        self.launch_detail.pack(fill="x", pady=(2, 0))
        self.launch_text = ("", "")
        self.launch_text_width = 180

        def wrap(event):
            width = max(55, event.width - 2)
            if width != self.launch_text_width:
                self.launch_text_width = width
                self._paint_launch_text()

        status.bind("<Configure>", wrap, add="+")
        self.dock_actions = frame(body)
        self.copy_launch_error = button(self.dock_actions, "Copy error", self._copy_launch_error, compact=True)
        self.retry_menu = button(self.dock_actions, "Retry menu", self.launcher._do_launch_menu, compact=True)
        self.launch_choices = frame(body)
        self.launch_choices.grid(row=0, column=1, sticky="ew")
        self.launch_row = frame(self.launch_choices)
        self.launch_row.pack(fill="x")
        self.launcher._action_btn = button(self.launch_row, "Join server", self._run_play_action, primary=True)
        self.launcher._action_btn.pack(fill="x")
        self.patch_retry = button(body, "Retry patch", self.launch_flow.patch, primary=True, compact=True)
        self.patch_retry.grid(row=0, column=1, sticky="e")
        self.patch_retry.grid_remove()

    def _page_title(self, page, name):
        title = label(page, name, size=25, weight="bold", family=DISPLAY)
        title.pack(fill="x", pady=(0, 12))
        self.page_titles.append(title)

    def _setup_tools(self, page):
        root = self.launcher
        self._page_title(page, SETUP_TOOLS)
        folder_card, folder = card(page, "Game installation")
        folder_card.pack(fill="x")
        self.setup_game_status = label(folder, color=SECONDARY, size=9, wraplength=240, justify="left")
        self.setup_game_status.pack(fill="x", pady=(6, 11))
        path, self.path_entry = text_field(folder, "Game executable", root.v_exe, 14)
        path.pack(fill="x")
        install_actions = frame(folder, SURF)
        install_actions.pack(fill="x", pady=(9, 0))
        self.browse = button(install_actions, "Browse for the game", root._browse, primary=True, compact=True)
        self.browse.grid(row=0, column=0, sticky="w")
        self.install_guide = button(install_actions, "Installation guide",
                                    lambda: self.open_guide("base-requirements"), compact=True)
        self.install_guide.grid(row=0, column=1, sticky="w", padx=(8, 0))

        self.setup_layout = frame(page, BG)
        self.setup_layout.pack(fill="x", pady=(12, 0))
        mods_card, mods = card(self.setup_layout, "Patch & mods")
        actions = frame(mods, SURF)
        actions.pack(fill="x", pady=(10, 0))
        actions.columnconfigure(0, weight=1)
        root._patch_btn = self._control_row(actions, 0, "Game files", "Patch", root._on_patch_click)
        label(actions, "Game mods", justify="left").grid(row=1, column=0, sticky="new", pady=(8, 0))
        self.mods_row = frame(actions, SURF)
        self.mods_row.grid(row=1, column=1, sticky="ew", padx=(8, 0))
        root._mods_btn = button(self.mods_row, "Mods", self.open_mods, compact=True)
        root._mods_btn.pack(fill="x")

        prefs_card, prefs = card(self.setup_layout, "Game preferences")
        self.setup_columns = (mods_card, prefs_card)
        self.preference_rows = frame(prefs, SURF)
        self.preference_rows.pack(fill="x", pady=(10, 4))
        self.preference_rows.columnconfigure(0, weight=1)
        self.game_settings = self._control_row(self.preference_rows, 0, "Game settings", "Edit",
                                               self.open_game_settings)
        self.appearance_button = self._control_row(self.preference_rows, 1, "Launcher colors", "Edit",
                                                   self.open_appearance)
        self._toggle(prefs, "Enhanced Debugging", root.v_debug_helper)
        self._toggle(prefs, "Show MelonLoader console", root.v_show_melonloader)
        self._tools()

    def _toggle(self, parent, name, variable):
        toggle = tk.Checkbutton(parent, text=name, variable=variable, command=self.launcher._save,
                                font=(UI, 10), bd=0, padx=0, highlightthickness=1,
                                anchor="w", justify="left", wraplength=240, takefocus=True)
        styles(self).bind(toggle, bg=SURF, fg=PARCH, activebackground=SURF, activeforeground="PANEL_ACCENT",
                          selectcolor=FIELD, highlightbackground=SURF, highlightcolor=FOCUS)
        toggle.pack(fill="x", pady=(1, 0))

    def _control_row(self, parent, row, name, action, callback, *, primary=False):
        label(parent, name, size=10, justify="left", wraplength=150).grid(
            row=row, column=0, sticky="ew", pady=(0, 5))
        control = button(parent, action, callback, primary=primary, compact=True)
        control.configure(width=max(7, len(action)), padx=6)
        control.grid(row=row, column=1, sticky="ew", padx=(8, 0), pady=(0, 5))
        return control

    def _tools(self):
        root = self.launcher
        world, world_inner = card(self.setup_layout, "World & server tools")
        support, support_inner = card(self.setup_layout, "Maintenance & support")
        self.tool_cards = (world, support)
        world_rows = frame(world_inner, SURF)
        support_rows = frame(support_inner, SURF)
        for rows in (world_rows, support_rows):
            rows.pack(fill="x", pady=(10, 0))
            rows.columnconfigure(0, weight=1)
        self.prefabulator = None
        row = 0
        if callable(self.prefabulator_action):
            self.prefabulator = self._control_row(world_rows, row, "Prefabulator", "Open",
                                                  lambda: self.prefabulator_action(root))
            row += 1
        self.keeper = self._control_row(world_rows, row, "TavernKeeper", "Open", self.open_keeper)
        self.console = self._control_row(world_rows, row + 1, "Remote console", "Open", self.open_console)
        root._tickets_btn = self._control_row(support_rows, 0, "Server tickets", "View", self.open_tickets)
        root._addons_btn = self._control_row(support_rows, 1, "Add-ons", "Manage", self.open_addons)
        self.wipe = self._control_row(support_rows, 2, "Game cache", "Wipe", root._wipe_cache)
        self.extra_actions = frame(world_inner, SURF)
        self.extra_actions.pack(fill="x")

    def _activity(self, page, old_log):
        root = self.launcher
        self._page_title(page, "Activity")
        log_card, content = card(page, "Game log")
        log_card.pack(fill="both", expand=True)
        log_frame = frame(content, FIELD, border=True)
        log_frame.pack(fill="both", expand=True, pady=(10, 8))
        root.log = tk.Text(log_frame, width=18, height=16, font=("Consolas", 9),
                           relief="flat", bd=0, highlightthickness=0, padx=10, pady=8,
                           wrap="word", state="disabled")
        styles(self).bind(root.log, bg=FIELD, fg="FIELD_TEXT", selectbackground="ACTIVE_TAB", selectforeground="ACTIVE_TEXT")
        self.log_colors = {tag: old_log.tag_cget(tag, "foreground") for tag in old_log.tag_names() if tag != "sel"}
        self._style_log_tags()
        scroll = scrollbar(log_frame, root.log.yview)
        root.log.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        root.log.pack(side="left", fill="both", expand=True)
        root._archive_log_btn = button(content, "Archive log", root._on_archive_log_click, compact=True)
        root._archive_log_btn.pack(anchor="e")

    def _help(self, page):
        self._page_title(page, "Help & support")
        support = frame(page, SURF, border=True)
        support.pack(fill="x", pady=(0, 12))
        support.columnconfigure(0, weight=1)
        contact = label(support, "Support", size=11, weight="bold", family=DISPLAY)
        contact.grid(row=0, column=0, sticky="w", padx=12, pady=9)
        self.help_links = frame(support, SURF)
        self.help_links.grid(row=0, column=1, sticky="e", padx=9, pady=6)
        button(self.help_links, "Discord", lambda: webbrowser.open(stock.DISCORD_URL), compact=True).pack(
            side="left", padx=(0, 6))
        self.token_button = button(self.help_links, "Account token help", self.open_token, compact=True)
        self.token_button.pack(side="left")

        self.help_layout = frame(page, BG)
        self.help_layout.pack(fill="both", expand=True)
        self.help_layout.rowconfigure(0, weight=1)
        self.help_layout.columnconfigure(1, weight=1)
        self.help_nav = frame(self.help_layout, SURF, border=True)
        self.topic_buttons = {}
        for heading, topics in (
            ("Get started", (("Introduction", "index"), ("Requirements", "base-requirements"),
                             ("Join a server", "joining-full"), ("Joining quick guide", "joining-tldr"))),
            ("Host a server", (("Local server", "local-server-full"), ("Local quick guide", "local-server-tldr"),
                               ("Public server", "public-server-full"), ("Public quick guide", "public-server-tldr"))),
            ("Reference", (("FAQ", "faq"), ("Troubleshooting", "troubleshooting"),
                           ("Technical documentation", "technical-docs"))),
        ):
            label(self.help_nav, heading, size=9, color=SECONDARY, weight="bold").pack(
                fill="x", padx=12, pady=(10, 4))
            for title, slug in topics:
                if slug not in help_pane.PAGE_LOOKUP:
                    continue
                topic = button(self.help_nav, title, lambda slug=slug: self.show_topic(slug), compact=True)
                topic.configure(anchor="w", font=(UI, 9), pady=4, wraplength=185, justify="left")
                topic.pack(fill="x", padx=6, pady=(0, 2))
                self.topic_buttons[slug] = topic
        frame(self.help_nav, SURF, height=6).pack(fill="x")
        reader = frame(self.help_layout, BG)
        reader.grid(row=0, column=1, sticky="nsew")
        self.help_choice = tk.StringVar(master=self, value=help_pane.PAGES[0][1])
        self.help_picker = frame(reader, SURF, border=True)
        label(self.help_picker, "Guide topic", size=9, color=SECONDARY, weight="bold").pack(
            fill="x", padx=10, pady=(8, 4))
        picker_content = frame(self.help_picker, SURF)
        picker_content.pack(fill="x", padx=9, pady=(0, 9))
        self.help_topic_picker = _mk_combobox(picker_content, self.help_choice, tuple(self.help_topics))
        self.help_topic_picker.configure(width=18, font=(UI, 10))
        self.help_topic_picker.bind(
            "<<ComboboxSelected>>", lambda event: self.show_topic(self.help_topics[self.help_choice.get()]))
        self.help_box = frame(reader, SURF, border=True, width=1, height=360)
        self.help_box.keep_wheel = True
        self.help_box.pack(fill="both", expand=True)
        self.help_box.pack_propagate(False)

    def show_topic(self, slug):
        if slug not in help_pane.PAGE_LOOKUP:
            return
        if self.help_doc is None:
            self.help_doc = help_pane.HtmlFrame(self.help_box, messages_enabled=False, on_link_click=self._help_link)
            self.help_doc.pack(fill="both", expand=True)
        self.help_choice.set(help_pane.PAGE_LOOKUP[slug][0])
        self.help_slug = slug
        self._style_topics()
        self.help_doc.load_html(guide_html(slug, self.palette, BRAND))

    def _style_topics(self):
        for key, topic in self.topic_buttons.items():
            active = self.help_slug == key
            surface = "ACTIVE_TAB" if active else SURF
            styles(self).bind(topic, fg="ACTIVE_TEXT" if active else PARCH,
                              bg=surface, highlightbackground=surface)

    def open_appearance(self):
        self.open_detail("Appearance", lambda parent: AppearancePage(
            parent, self.colors, self.apply_colors, self.save_colors, self.back, action_parent=self.detail_footer),
            self.focus_get(), legacy=False)

    def save_colors(self, colors):
        persist_colors(colors)
        if colors != self.colors:
            self.apply_colors(colors)

    def apply_colors(self, colors):
        self.colors = colors.copy()
        self.palette = palette(colors)
        styles(self).apply(self.palette)
        self._style_navigation()
        self._style_log_tags()
        self.refresh()
        self.banner.queue()
        if self.help_doc is not None:
            self.show_topic(self.help_slug)
        dialog_theme.restyle(self.launcher)

    def _style_log_tags(self):
        for tag, color in self.log_colors.items():
            foreground = readable(self.palette[FIELD], color) if color.startswith("#") and len(color) == 7 else self.palette["FIELD_TEXT"]
            self.launcher.log.tag_config(tag, foreground=foreground)

    def _style_navigation(self):
        self.crest.itemconfigure("crest", fill=self.palette["PANEL_ACCENT"])
        for name, tab in self.tabs.items():
            active = name == self.current
            surface = "ACTIVE_TAB" if active else SURF
            foreground = "ACTIVE_TEXT" if active else PARCH
            styles(self).bind(tab, bg=surface, fg=foreground, highlightbackground=surface,
                              activebackground=surface if active else "SECONDARY_HOVER",
                              activeforeground=foreground if active else "SECONDARY_HOVER_TEXT")
            color = tab.cget("activeforeground" if tab.cget("state") == "active" else "foreground")
            self.nav_icons[name].configure(foreground=color)

    def open_guide(self, slug):
        self.show("Help")
        self.show_topic(slug)

    def _help_link(self, url):
        if url.startswith(help_pane.PAGE_LINK_PREFIX):
            self.show_topic(url[len(help_pane.PAGE_LINK_PREFIX):])
        elif url.startswith(("https://", "http://")):
            webbrowser.open(url)

    def _open_help(self, event=None):
        self.show("Help")
        self.tabs["Help"].focus_set()
        return "break"

    def _escape_detail(self, event):
        widget = event.widget
        if dialogs.active(self.launcher):
            return
        if isinstance(widget, tk.Misc) and widget is not self.launcher and widget.bind("<Escape>"):
            return
        if self.detail is not None:
            self.back()
            return "break"

    def open_saved(self):
        def build(parent):
            return SavedServersPage(parent, on_target=lambda target: self._choose_target(parent, target),
                                    is_pinned=self._is_pinned, on_pin=self._toggle_pin,
                                    action_parent=self.detail_footer)
        self.open_detail("Saved & recent", build, self.saved, legacy=False)

    def open_community(self):
        def build(parent):
            return CommunityPage(parent, lambda host, name, kind, port="1757": self._choose_target(
                parent, LaunchTarget(host, port, "headless" if kind == "headless" else "official", label=name)),
                is_pinned=self._is_pinned, on_pin=self._toggle_pin, action_parent=self.detail_footer)
        self.open_detail("Community servers", build, self.community, legacy=False)

    def open_game_settings(self):
        self.open_detail("Game settings", lambda parent: SettingsPage(parent, action_parent=self.detail_footer),
                         self.game_settings, legacy=False)

    def open_addons(self):
        self.open_detail("Manage add-ons", lambda parent: AddonsPage(parent, self.launcher), self.launcher._addons_btn)

    def open_console(self):
        self.open_detail("Remote console", lambda parent: RemoteConsolePage(parent, self.launcher), self.console)

    def open_tickets(self):
        def pick_server(select):
            def chosen(*server):
                select(*server)
                self.back()
            self.open_detail("Choose a saved server", lambda parent: SavedServersPage(parent, chosen),
                             self.focus_get(), legacy=False)

        self.open_detail("Server tickets", lambda parent: TicketsPage(
            parent, self.launcher, pick_server=pick_server), self.launcher._tickets_btn)

    def open_mods(self):
        self.open_detail("Mods", lambda parent: ModsPage(parent, self.launcher), self.launcher._mods_btn)

    def open_keeper(self):
        self.open_detail("TavernKeeper", lambda parent: TavernKeeperPage(
            parent, self.launcher, self.open_detail, self.back), self.keeper)

    def open_token(self):
        root = self.launcher

        def acknowledge():
            config = stock.load_cfg()
            config["token_ack"] = True
            stock.save_cfg(config)
            root._stop_token_animation()
            self.back()

        def build(parent):
            panel, inner = card(parent, "About your token file")
            note = label(inner, text=root._token_note, justify="left", wraplength=360)
            note.pack(fill="x", pady=(8, 14))
            inner.bind("<Configure>", lambda event: note.configure(wraplength=max(100, event.width)), add="+")
            button(inner, "Yes, I understand", acknowledge, primary=True).pack(anchor="w")
            return panel

        self.open_detail("Account token help", build, self.focus_get(), legacy=False)

    def _choose_target(self, parent, target):
        if self.launch_flow.busy:
            return
        self._set_target(target)
        self.launcher._save()
        self.after_idle(lambda: self.back() if self.detail is parent else None)

    def _set_target(self, target, resume=False):
        root = self.launcher
        root.v_ip.set(target.host)
        root.v_port.set(target.port)
        root._selected_kind = target.kind
        self.selected_label = target.label
        if resume and target.platform:
            root.v_platform.set(target.platform)
        self.refresh_launch()

    def _clear_selected_label(self, *_):
        self.selected_label = None

    def _current_target(self):
        root = self.launcher
        try:
            return LaunchTarget(root.v_ip.get().strip() or "127.0.0.1", stock._valid_port(root.v_port.get()),
                                root._selected_kind, root.v_platform.get(), self.selected_label)
        except ValueError:
            return None

    def _launch_saved(self, target, resume=False):
        if self.launch_flow.busy or dialogs.active(self.launcher):
            return
        self._set_target(target, resume)
        self.launcher._on_join_clicked()

    def _record_launch(self, target):
        self.history = record_launch(target)
        config = stock.load_cfg()
        recent = config.get("recent_servers", [])
        if isinstance(recent, list) and recent and isinstance(recent[0], dict) and recent[0].get("ip") == target.host:
            recent[0].update(kind=target.kind, platform=target.platform, port=target.port,
                             name=target.label or recent[0].get("name") or target.host)
            stock.save_cfg(config)

    def _is_pinned(self, target):
        return any(pin.key == target.key for pin in self.history.pins)

    def _toggle_pin(self, target):
        self._update_pins(lambda: toggle_pin(target))

    def _unpin(self, target):
        self._update_pins(lambda: set_pinned(target, False))

    def _update_pins(self, change):
        try:
            self.history = change()
        except (OSError, ValueError) as exc:
            messagebox.showerror("Pinned servers", str(exc), parent=self.launcher)
            return
        self.refresh_launch()

    @property
    def detail(self):
        return self.details[-1].frame if self.details else None

    @property
    def detail_content(self):
        return self.details[-1].content if self.details else None

    def open_detail(self, title, build, source=None, *, legacy=True):
        if self._detail_busy() or dialogs.active(self.launcher):
            return
        canvas = self.pane.canvas
        previous = (canvas.xview()[0], canvas.yview()[0])
        (self.detail or self.pages[self.current]).pack_forget()
        route = DetailPage(title, frame(self.pane.body, BG), source, previous)
        self.details.append(route)
        self._pack_detail(route)
        try:
            route.content = build(route.frame)
            route.content.pack(fill="both", expand=True)
            if legacy:
                dialog_theme.watch(self.launcher, route.content)
        except Exception:
            self.back()
            raise
        self._sync_docks()
        self.pane.queue()
        canvas.xview_moveto(0)
        canvas.yview_moveto(0)
        self.back_button.focus_set()
        self.pane.animate_page()

    def _pack_detail(self, route):
        inset = 10 if self.tight else 18
        route.frame.pack(fill="both", expand=True, padx=inset, pady=(12, PAGE_PADDING_Y[1]))
        self.detail_title.configure(text=route.title)
        self.detail_bar.pack(fill="x", before=self.pane, padx=inset, pady=(12, 0))

    def _detail_busy(self):
        return getattr(self.detail_content, "busy", False) is True

    def _close_detail(self):
        route = self.details.pop()
        close = getattr(route.content, "close", None)
        if close is not None:
            close()
        route.frame.destroy()
        return route

    def back(self):
        if not self.details or self._detail_busy() or dialogs.active(self.launcher):
            return
        handle_back = getattr(self.detail_content, "go_back", None)
        if handle_back is not None and handle_back():
            self.pane.canvas.yview_moveto(0)
            return
        route = self._close_detail()
        if self.details:
            self._pack_detail(self.details[-1])
        else:
            self.detail_bar.pack_forget()
            self._pack_page(self.current)
        self._sync_docks()
        self.update_idletasks()
        self.pane.queue()
        x, y = route.previous_scroll
        self.pane.canvas.xview_moveto(x)
        self.pane.canvas.yview_moveto(y)
        if route.source is not None and route.source.winfo_viewable():
            route.source.focus_set()
        elif self.details:
            self.back_button.focus_set()
        self.pane.animate_page()

    def _pack_page(self, page):
        self.pages[page].pack(fill="both", expand=True, padx=10 if self.tight else 18, pady=PAGE_PADDING_Y)
        self.pane.queue()

    def show(self, page):
        if self._detail_busy() or dialogs.active(self.launcher):
            return
        if self.details:
            while self.details:
                self._close_detail()
            self.detail_bar.pack_forget()
        elif self.current == page:
            return
        previous = self.current
        if previous is not None:
            self.pages[previous].pack_forget()
        self.current = page
        self._pack_page(page)
        self._style_navigation()
        self.refresh_launch()
        if page == "Help" and self.help_doc is None:
            self.show_topic(self.help_slug)
        if page == "Play":
            self.update_recent_activity()
        self.pane.canvas.xview_moveto(0)
        self.pane.canvas.yview_moveto(0)
        if previous is not None:
            self.pane.animate_page()

    def refresh(self, *_):
        root = self.launcher
        path = root.v_exe.get().strip()
        ready = bool(path and os.path.isfile(path))
        self._style_install(ready)
        self.refresh_notes()
        self.nav_status.configure(text=f"{root.v_platform.get()}\n{root.v_ip.get().strip() or 'Localhost'}")
        self.refresh_launch()
        self.refresh_token()

    def tool_warning(self, kind, needed):
        if self.tool_warnings[kind] != needed:
            self.tool_warnings[kind] = needed
            self._style_install(os.path.isfile(self.launcher.v_exe.get().strip()))

    def _style_install(self, ready):
        patch_needed = ready and self.tool_warnings["patch"]
        mods_needed = ready and self.tool_warnings["mods"]
        if not ready:
            state = "Setup needed · Choose your game executable"
        elif patch_needed:
            state = "Needs update · Game patch"
        elif mods_needed:
            state = "Mods need attention"
        else:
            state = "Ready · Game found"
        tone = "STATUS_OK" if ready and not (patch_needed or mods_needed) else "STATUS_WARNING"
        for widget in (self.play_game_status, self.setup_game_status):
            widget.configure(text=f"●  {state}")
            styles(self).bind(widget, fg=tone)
        set_button_priority(self.browse, not ready)
        set_button_priority(self.launcher._patch_btn, patch_needed)
        set_button_priority(self.launcher._mods_btn, mods_needed and not patch_needed)

    def _play_action(self):
        flow = self.launch_flow
        status = flow.status
        if status is None or flow.mode == "patch":
            return "Join server", self.launcher._on_join_clicked
        root = self.launcher
        if status.remedy == "setup" and not os.path.isfile(root.v_exe.get().strip()):
            return "Open setup", lambda: self.show(SETUP_TOOLS)
        name = root.v_username.get().strip()
        if status.remedy == "player" and (not name or len(name) > stock.USERNAME_MAX_LEN
                                           or not stock._is_valid_username(name)):
            return "Enter name", self.username_entry.focus_set
        if status.remedy == "retry" and flow.mode == "join" and self._current_target() == flow.destination:
            return "Retry join", root._on_join_clicked
        return "Join server", root._on_join_clicked

    def _run_play_action(self):
        if not self.launch_flow.busy:
            self._play_action()[1]()

    def _copy_launch_error(self):
        status = self.launch_flow.status
        if status and status.error:
            self.clipboard_clear()
            self.clipboard_append(status.error)
            self.copy_launch_error.configure(text="Copied")
            self.after(1200, lambda: self.copy_launch_error.configure(text="Copy error"))

    def _paint_launch_text(self):
        width = self.launch_text_width
        for widget, parts, available in (
                (self.launch_title, self.launch_text[0], max(55, width - 22)),
                (self.launch_detail, self.launch_text[1], width)):
            text = _fit_two_lines(widget, " ".join(parts.split()), available // 2 if self.tight else available)
            measured = int(widget.tk.call("font", "measure", widget.cget("font"), text))
            widget.configure(text=text, wraplength=available, height=2 if not self.tight and measured > available else 1)

    def refresh_launch(self, *_):
        root = self.launcher
        flow = self.launch_flow
        game_found = os.path.isfile(root.v_exe.get().strip())
        status = flow.status
        has_history = bool(self.history.last_launch or self.history.pins)
        if has_history and not self.launch_center.winfo_manager():
            self.launch_center.pack(fill="x", before=self.hero, pady=(0, 12))
        elif not has_history and self.launch_center.winfo_manager():
            self.launch_center.pack_forget()
        self.launch_center.render(self.history.last_launch, self.history.pins, busy=flow.busy)

        if status:
            title, detail, tone = status.title, status.detail, status.tone
        else:
            name = root.v_username.get().strip()
            player_ready = bool(name and len(name) <= stock.USERNAME_MAX_LEN and stock._is_valid_username(name))
            target = self._current_target()
            address = server_address(target.host, target.port) if target else "Server address needed"
            if not game_found:
                title, detail, tone = "Game setup needed", "Choose your game in Setup & Tools.", "STATUS_WARNING"
            elif not player_ready:
                title, detail, tone = "Player name needed", "Enter your in-game name to join.", "STATUS_WARNING"
            else:
                title, detail, tone = "Ready to launch", f"{address}  ·  {root.v_platform.get()}", "STATUS_OK"
        self.launch_text = title, detail
        self._paint_launch_text()
        styles(self).bind(self.launch_dot, fg=tone)
        for action, visible in (
                (self.copy_launch_error, bool(status and status.error)),
                (self.retry_menu, bool(status and status.remedy == "retry" and flow.mode == "menu"))):
            if visible and not action.winfo_manager():
                action.pack(side="left", padx=(0, 5))
            elif not visible:
                action.pack_forget()
        if self.dock_actions.pack_slaves():
            if not self.dock_actions.winfo_manager():
                self.dock_actions.grid(row=1, column=0, columnspan=2, sticky="w", pady=(5, 0))
        else:
            self.dock_actions.grid_remove()

        ready = not flow.busy
        caption, _ = self._play_action()
        if self.tight and caption == "Join server":
            caption = "Join"
        root._action_btn.configure(text="Working…" if flow.busy else caption, state="normal" if ready else "disabled")
        root._menu_btn.configure(state="normal" if ready and game_found else "disabled")
        root._patch_btn.configure(state="normal" if ready and game_found else "disabled")
        if not root._check_status.get().startswith("Checking "):
            root._check_btn.configure(state="normal" if ready else "disabled")
        for control in (self.username_entry, self.address_entry, self.port_entry, self.path_entry, self.browse):
            control.configure(state="normal" if ready else "disabled")
        self.platform_combo.configure(state="readonly" if ready else "disabled")
        self._sync_docks()

    def _sync_docks(self):
        show_play = self.current == "Play" and self.detail is None
        show_patch = self.current == SETUP_TOOLS and self.detail is None and self.launch_flow.mode == "patch"
        if show_play:
            self.patch_retry.grid_remove()
        if show_play and not self.launch_choices.winfo_manager():
            self.launch_choices.grid()
        elif show_patch:
            self.launch_choices.grid_remove()
            if self.launch_flow.status and self.launch_flow.status.remedy == "retry":
                self.patch_retry.grid()
            else:
                self.patch_retry.grid_remove()
        action_bar = getattr(self.detail_content, "action_bar", None)
        docked = action_bar is not None and action_bar.master is self.detail_footer
        for dock, visible in ((self.operation_dock, show_play or show_patch), (self.detail_footer, docked)):
            if visible:
                inset = 10 if self.tight else 18
                if not dock.winfo_manager():
                    dock.pack(side="bottom", fill="x", before=self.pane, padx=inset, pady=(0, 10))
                elif int(dock.pack_info()["padx"]) != inset:
                    dock.pack_configure(padx=inset)
            elif dock.winfo_manager():
                dock.pack_forget()
        if docked:
            for child in self.detail_footer.winfo_children():
                if child is not action_bar:
                    child.pack_forget()
            if not action_bar.winfo_manager():
                action_bar.pack(fill="x")
        self.pane.queue()

    def refresh_notes(self, *_):
        root = self.launcher
        hint = not root.v_ip.get().strip()
        result = bool(root._check_status.get())
        for widget, show in ((self.destination_hint, hint), (root._check_label, result)):
            if show:
                widget.grid()
            else:
                widget.grid_remove()
        if hint:
            self.destination_hint.configure(text="Leave the address blank for localhost.")
        if hint or result:
            if not self.notes.winfo_manager():
                self.notes.pack(fill="x", pady=(7, 0), before=self.secondary_actions)
        else:
            self.notes.pack_forget()

    def update_recent_activity(self):
        if self.current != "Play":
            return
        lines = self.launcher.log.get("end-3lines", "end-1c").strip()
        self.recent_activity.configure(text=lines)

    def refresh_token(self):
        root = self.launcher
        state = root._header_canvas.itemcget(root._token_btn_item, "state")
        self.token_button.configure(state="normal" if state == "normal" else "disabled")

    def fit_opening_window(self, attempts=8):
        self.update_idletasks()
        geometry = re.match(r"(\d+)x(\d+)", self.launcher.geometry())
        if geometry and attempts and tuple(map(int, geometry.groups())) != (self.winfo_width(), self.winfo_height()):
            self.after(15, lambda: self.fit_opening_window(attempts - 1))
            return
        side_width = self.winfo_width() - self.pane.winfo_width()
        header_height = self.winfo_height() - self.pane.winfo_height()
        page_width = max(page.winfo_reqwidth() for page in self.pages.values())
        play_dock_height = self.operation_dock.winfo_reqheight() + 10
        if self.operation_dock.winfo_ismapped():
            header_height -= self.operation_dock.winfo_height() + 10
        page_height = max(page.winfo_reqheight() + (play_dock_height if name == "Play" else 0)
                          for name, page in self.pages.items())
        width = side_width + page_width + (20 if self.tight else 36)
        height = header_height + page_height + sum(PAGE_PADDING_Y)
        fit_window(self.launcher, width, height)

    def _on_resize(self, event):
        self._resize(self.winfo_width(), self.pane.winfo_width())

    def _resize(self, width, pane_width):
        compact = width < 835
        if compact != self.compact:
            self.compact = compact
            self.navigation.grid_forget()
            self.workspace.grid_forget()
            self.rowconfigure(1, weight=0 if compact else 1)
            self.rowconfigure(2, weight=1 if compact else 0)
            if compact:
                self.nav_status.grid_forget()
                self.navigation.grid(row=1, column=0, columnspan=2, sticky="ew")
                self.workspace.grid(row=2, column=0, columnspan=2, sticky="nsew")
            else:
                self.navigation.grid(row=1, column=0, sticky="ns")
                self.workspace.grid(row=1, column=1, sticky="nsew")
                self.navigation.rowconfigure(len(self.tabs), weight=1)
                self.nav_status.grid(row=len(self.tabs) + 1, column=0, sticky="sw", padx=14, pady=14)
            for index, (name, tab) in enumerate(self.tabs.items()):
                tab.grid_forget()
                self.navigation.columnconfigure(index, weight=1 if compact else 0)
                tab.configure(image="" if compact else self.nav_icons[name],
                              anchor="center" if compact else "w", padx=3 if compact else 10,
                              pady=6 if compact else 10)
                tab.grid(row=0 if compact else index, column=index if compact else 0,
                         sticky="ew", padx=(2, 2) if compact else (8, 8), pady=(3, 4) if compact else (8, 0))
        tab_size = 8 if compact and width < 450 else 10
        if tab_size != self.tab_size:
            self.tab_size = tab_size
            for tab in self.tabs.values():
                tab.configure(font=(UI, tab_size, "bold"))
        if width < 455 and self.build_label.winfo_manager():
            self.build_label.pack_forget()
        elif width >= 455 and not self.build_label.winfo_manager():
            self.build_label.pack(side="right", padx=14)
        wraplength = max(130, pane_width - 100)
        if int(self.recent_activity.cget("wraplength")) != wraplength:
            self.recent_activity.configure(wraplength=wraplength)
        status = getattr(self.launcher, "_sheikah_next_status", None)
        if status is not None:
            status_width = max(108, min(190, self.workspace.winfo_width() // 3))
            if int(status.cget("wraplength")) != status_width:
                status.configure(wraplength=status_width)
            compact_labels = pane_width < 500
            status.configure(font=(UI, 8 if compact_labels else 9), height=1 if compact_labels else 2)
        stacked = pane_width < 720
        if stacked != self.stacked:
            self.stacked = stacked
            self._layout_play(stacked)
            self._layout_setup_cards(stacked)
            if stacked:
                self.help_nav.grid_remove()
                self.help_picker.pack(before=self.help_box, fill="x", pady=(0, 8))
            else:
                self.help_picker.pack_forget()
                self.help_nav.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
            self.launcher._check_label.configure(wraplength=240 if stacked else 365)
        tight = pane_width < 500
        if tight != self.tight:
            self.tight = tight
            self.launch_body.columnconfigure(1, minsize=140 if tight else 205)
            self.launcher._action_btn.configure(wraplength=120 if tight else 0, pady=5 if tight else 9,
                                                font=(UI, 9 if tight else 10, "bold"))
            for action in (self.retry_menu, self.copy_launch_error, self.patch_retry):
                action.configure(font=(UI, 8 if tight else 10, "bold"), padx=7 if tight else 10)
            self.refresh_launch()
            for title in self.page_titles:
                title.configure(font=(DISPLAY, 17 if tight else 25, "bold"))
            self.username_entry.configure(width=7 if tight else 12)
            self.address_entry.configure(width=7 if tight else 12)
            self.platform_combo.configure(width=6 if tight else 7)
            active = self.detail if self.detail is not None else self.pages[self.current]
            active.pack_configure(padx=10 if tight else 18)
            if self.detail is not None:
                self.detail_bar.pack_configure(padx=10 if tight else 18)
            self.detail_title.configure(font=(DISPLAY, 13 if tight else 15, "bold"))
            self.help_links.grid_configure(row=1 if tight else 0, column=0 if tight else 1,
                                           sticky="w" if tight else "e", pady=(0, 9) if tight else 6)
            self.view_log.grid_configure(row=1 if tight else 0, column=0 if tight else 1)
            self.secondary_actions.columnconfigure(0, uniform="" if tight else "launch")
            self.secondary_actions.columnconfigure(1, weight=0 if tight else 1, uniform="" if tight else "launch")
            self.launcher._check_btn.grid_configure(padx=0 if tight else (0, 5))
            self.launcher._menu_btn.grid_configure(row=1 if tight else 0, column=0 if tight else 1,
                                                   pady=(5, 0) if tight else 0)
            self.install_guide.grid_configure(row=1 if tight else 0, column=0 if tight else 1,
                                               padx=0 if tight else (8, 0), pady=(6, 0) if tight else 0)
        self.pane.queue()

    def _layout_play(self, stacked):
        shared = "play_hero" if not stacked else ""
        self.hero.columnconfigure(0, weight=6, uniform=shared)
        self.hero.columnconfigure(1, weight=0 if stacked else 4, uniform=shared)
        self.banner.grid(row=0, column=0 if stacked else 1, sticky="nsew")
        self.join_card.grid(row=1 if stacked else 0, column=0, sticky="nsew")
        self.banner.set_compact(stacked)
        self.play_title.configure(text="Join a server" if stacked else BRAND,
                                  font=(DISPLAY, 17 if stacked else 25, "bold"))
        self._columns(self.side, self.server_card, self.install_card, stacked, (5, 4))

    def _layout_setup_cards(self, stacked):
        self.setup_layout.columnconfigure(0, weight=1)
        self.setup_layout.columnconfigure(1, weight=0 if stacked else 1)
        for index, panel in enumerate((*self.setup_columns, *self.tool_cards)):
            row, column = (index, 0) if stacked else divmod(index, 2)
            panel.grid(row=row, column=column, sticky="nsew", padx=(12, 0) if column else 0,
                       pady=(12, 0) if row else 0)

    @staticmethod
    def _columns(parent, left, right, stacked, weights):
        parent.columnconfigure(0, weight=weights[0])
        parent.columnconfigure(1, weight=0 if stacked else weights[1])
        left.grid(row=0, column=0, sticky="nsew")
        right.grid(row=1 if stacked else 0, column=0 if stacked else 1, sticky="nsew",
                   padx=0 if stacked else (12, 0), pady=(12, 0) if stacked else 0)
