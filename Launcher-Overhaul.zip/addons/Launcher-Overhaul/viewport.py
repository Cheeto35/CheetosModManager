"""Work-area fitting and scrolling for the launcher workspace."""

import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import tempfile
from time import monotonic
import tkinter as tk

from tavern_shared.paths import _tavern_data_dir
from tavern_shared.theme import BG, _mk_scrollbar


WINDOW_SIZE = (1120, 780)
MIN_WINDOW_SIZE = (370, 310)
SPI_GETCLIENTAREAANIMATION = 0x1042
PAGE_SLIDE_PIXELS = 8
PAGE_SLIDE_DURATION = .13


def _client_animations_enabled():
    try:
        enabled = wintypes.BOOL()
        result = ctypes.windll.user32.SystemParametersInfoW(
            SPI_GETCLIENTAREAANIMATION, 0, ctypes.byref(enabled), 0)
        return bool(result and enabled.value)
    except (AttributeError, OSError):
        return False


class MonitorInfo(ctypes.Structure):
    _fields_ = [("size", wintypes.DWORD), ("monitor", wintypes.RECT),
                ("work", wintypes.RECT), ("flags", wintypes.DWORD)]


def window_bounds(root, target=None):
    try:
        user32 = ctypes.windll.user32
        user32.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
        user32.GetAncestor.restype = wintypes.HWND
        user32.MonitorFromWindow.argtypes = (wintypes.HWND, wintypes.DWORD)
        user32.MonitorFromWindow.restype = wintypes.HANDLE
        user32.GetMonitorInfoW.argtypes = (wintypes.HANDLE, ctypes.POINTER(MonitorInfo))
        user32.GetWindowRect.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
        hwnd = user32.GetAncestor(root.winfo_id(), 2)
        if target is None:
            monitor = user32.MonitorFromWindow(hwnd, 2)
        else:
            user32.MonitorFromRect.argtypes = (ctypes.POINTER(wintypes.RECT), wintypes.DWORD)
            user32.MonitorFromRect.restype = wintypes.HANDLE
            monitor = user32.MonitorFromRect(ctypes.byref(target), 2)
        info = MonitorInfo(size=ctypes.sizeof(MonitorInfo))
        frame = wintypes.RECT()
        if user32.GetMonitorInfoW(monitor, ctypes.byref(info)) and user32.GetWindowRect(hwnd, ctypes.byref(frame)):
            return info.work, frame, hwnd
    except (AttributeError, OSError):
        pass
    return wintypes.RECT(0, 0, root.winfo_screenwidth(), root.winfo_screenheight()), None, None


def opening_size(root):
    work, _, _ = window_bounds(root)
    return (min(WINDOW_SIZE[0], max(1, work.right - work.left - 24)),
            min(WINDOW_SIZE[1], max(1, work.bottom - work.top - 64)))


def _client_rect(hwnd):
    if hwnd:
        try:
            client = wintypes.RECT()
            get_client = ctypes.windll.user32.GetClientRect
            get_client.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
            if get_client(hwnd, ctypes.byref(client)):
                return client
        except (AttributeError, OSError):
            pass
    return None


def _window_dpi(hwnd):
    if hwnd:
        try:
            get_dpi = ctypes.windll.user32.GetDpiForWindow
            get_dpi.argtypes = (wintypes.HWND,)
            get_dpi.restype = wintypes.UINT
            return get_dpi(hwnd) or 96
        except (AttributeError, OSError):
            pass
    return 96


def _clamp_window(work, chrome, size, position):
    chrome_w, chrome_h = chrome
    available_w = max(1, work.right - work.left - chrome_w)
    available_h = max(1, work.bottom - work.top - chrome_h)
    min_w, min_h = min(MIN_WINDOW_SIZE[0], available_w), min(MIN_WINDOW_SIZE[1], available_h)
    width = min(max(min_w, size[0]), available_w)
    height = min(max(min_h, size[1]), available_h)
    x = min(max(position[0], work.left), max(work.left, work.right - width - chrome_w))
    y = min(max(position[1], work.top), max(work.top, work.bottom - height - chrome_h))
    return (width, height), (x, y), (min_w, min_h)


def _place_window(root, bounds, size, position):
    work, frame, hwnd = bounds
    client = _client_rect(hwnd)
    if client is not None and frame is not None:
        chrome = (max(0, frame.right - frame.left - (client.right - client.left)),
                  max(0, frame.bottom - frame.top - (client.bottom - client.top)))
    else:
        chrome = (20, 56)
    (width, height), (x, y), minimum = _clamp_window(work, chrome, size, position)
    root.minsize(*minimum)
    root.geometry(f"{width}x{height}")
    root.update_idletasks()
    if hwnd:
        try:
            move = ctypes.windll.user32.SetWindowPos
            move.argtypes = (wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                             ctypes.c_int, ctypes.c_int, wintypes.UINT)
            # Native coordinates support monitors to the left or above the primary display.
            if move(hwnd, None, x, y, width + chrome[0], height + chrome[1], 0x0014):
                root.update_idletasks()
                return
        except (AttributeError, OSError):
            pass
    x = min(max(x, 0), max(0, root.winfo_screenwidth() - width - chrome[0]))
    y = min(max(y, 0), max(0, root.winfo_screenheight() - height - chrome[1]))
    root.geometry(f"{width}x{height}+{x}+{y}")
    root.update_idletasks()


def _load_placement(path):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("version", 1) != 1:
        return None
    coordinates = {key: data.get(key) for key in ("x", "y", "width", "height")}
    if any(type(value) is not int or abs(value) > 1_000_000 for value in coordinates.values()):
        return None
    if min(coordinates["width"], coordinates["height"]) < 1:
        return None
    dpi = data.get("dpi")
    return dict(coordinates, version=1, dpi=dpi if type(dpi) is int and 48 <= dpi <= 768 else 96,
                maximized=data.get("maximized") is True)


def _save_placement(path, data):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix="launcher-window-", suffix=".tmp", delete=False) as file:
            temporary = Path(file.name)
            json.dump(data, file, indent=2)
            file.write("\n")
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


class _WindowPlacement:
    def __init__(self, root):
        self.root = root
        self.path = Path(_tavern_data_dir()) / "launcher_overhaul_window.json"
        self.saved = _load_placement(self.path)
        self.recent = None
        self.job = None

    def restore(self, content_size):
        if self.saved is None:
            bounds = window_bounds(self.root)
            work, frame, _ = bounds
            position = (frame.left, frame.top) if frame is not None else (work.left, work.top)
            size = tuple(max(default, content) for default, content in zip(WINDOW_SIZE, content_size))
            _place_window(self.root, bounds, size, position)
        else:
            saved = self.saved
            x, y = saved["x"], saved["y"]
            target = wintypes.RECT(x, y, x + saved["width"], y + saved["height"])
            bounds = window_bounds(self.root, target)
            dpi = _window_dpi(bounds[2])
            _place_window(self.root, bounds, self._scaled_size(dpi), (x, y))
            # A per-monitor-aware build can receive a new DPI once it moves.
            bounds = window_bounds(self.root)
            current_dpi = _window_dpi(bounds[2])
            if current_dpi != dpi:
                _place_window(self.root, bounds, self._scaled_size(current_dpi), (x, y))

        self.root.bind("<Configure>", self._configured, add="+")
        self.root.bind("<Destroy>", self._destroyed, add="+")
        self._configured()
        if self.saved is not None and self.saved["maximized"]:
            try:
                self.root.state("zoomed")
            except tk.TclError:
                return
            self._configured()

    def _scaled_size(self, dpi):
        return tuple(round(self.saved[key] * dpi / self.saved["dpi"]) for key in ("width", "height"))

    def _configured(self, event=None):
        if event is not None and event.widget is not self.root:
            return
        state = self.root.state()
        if state == "normal":
            _, frame, hwnd = window_bounds(self.root)
            client = _client_rect(hwnd)
            x, y = (frame.left, frame.top) if frame is not None else (self.root.winfo_x(), self.root.winfo_y())
            width, height = (client.right - client.left, client.bottom - client.top) if client is not None else (
                self.root.winfo_width(), self.root.winfo_height())
            if width <= 1 or height <= 1:
                return
            recent = dict(version=1, x=x, y=y, width=width, height=height,
                          dpi=_window_dpi(hwnd), maximized=False)
        elif state == "zoomed" and self.recent is not None:
            recent = dict(self.recent, maximized=True)
        else:
            return
        if recent != self.recent:
            self.recent = recent
            if self.job is not None:
                self.root.after_cancel(self.job)
            self.job = self.root.after(350, self._flush)

    def _flush(self):
        self.job = None
        if self.recent is not None and self.saved != self.recent:
            try:
                _save_placement(self.path, self.recent)
            except OSError:
                return
            self.saved = self.recent

    def _destroyed(self, event):
        if event.widget is self.root:
            if self.job is not None:
                self.root.after_cancel(self.job)
            self._flush()


def fit_window(root, content_width, content_height):
    if getattr(root, "_overhaul_window_placement", None) is None:
        placement = root._overhaul_window_placement = _WindowPlacement(root)
        placement.restore((content_width, content_height))


class ScrollPane(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=BG)
        self.root = self.winfo_toplevel()
        self.canvas = tk.Canvas(self, bg=BG, width=1, height=1, bd=0, highlightthickness=0,
                                xscrollincrement=1, yscrollincrement=1, takefocus=False)
        self.canvas.pack(fill="both", expand=True)
        self.vertical = _mk_scrollbar(self, self.canvas.yview)
        self.horizontal = _mk_scrollbar(self, self.canvas.xview, orient="horizontal")
        self.canvas.configure(xscrollcommand=self.horizontal.set, yscrollcommand=self.vertical.set)
        self.body = tk.Frame(self.canvas, bg=BG)
        self.item = self.canvas.create_window(0, 0, anchor="nw", window=self.body)
        self.size = None
        self.bars = (False, False)
        self.job = None
        self.transition_job = None
        self.transition_size = None
        self.root.bind("<Configure>", self.queue, add="+")
        self.root.bind("<MouseWheel>", self.wheel, add="+")
        self.root.bind("<Shift-MouseWheel>", self.wheel, add="+")
        self.root.bind("<FocusIn>", self.reveal, add="+")

    def queue(self, event=None):
        if self.job is None:
            self.job = self.after_idle(self.layout)

    def animate_page(self):
        self._finish_transition()
        if self.winfo_viewable() and _client_animations_enabled():
            self.canvas.coords(self.item, 0, PAGE_SLIDE_PIXELS)
            self.transition_job = self.after_idle(self._start_transition)

    def _start_transition(self):
        self.transition_size = (self.winfo_width(), self.winfo_height())
        self._slide_frame(monotonic())

    def _slide_frame(self, started):
        self.transition_job = None
        remaining = max(0, 1 - (monotonic() - started) / PAGE_SLIDE_DURATION)
        offset = round(PAGE_SLIDE_PIXELS * remaining ** 2)
        self.canvas.coords(self.item, 0, offset)
        if offset:
            self.transition_job = self.after(16, self._slide_frame, started)
        else:
            self.transition_size = None

    def _finish_transition(self):
        if self.transition_job is not None:
            self.after_cancel(self.transition_job)
            self.transition_job = None
            self.transition_size = None
            self.canvas.coords(self.item, 0, 0)

    def layout(self):
        self.job = None
        width, height = self.winfo_width(), self.winfo_height()
        if self.transition_size is not None and self.transition_size != (width, height):
            self._finish_transition()
        if width <= 1 or height <= 1:
            return
        wanted_width, wanted_height = self.body.winfo_reqwidth(), self.body.winfo_reqheight()
        bar_width, bar_height = self.vertical.winfo_reqwidth(), self.horizontal.winfo_reqheight()
        vertical = wanted_height > height
        horizontal = wanted_width > width - (bar_width if vertical else 0)
        vertical = wanted_height > height - (bar_height if horizontal else 0)
        if vertical != self.bars[0]:
            if vertical:
                self.vertical.pack(side="right", fill="y", before=self.canvas)
            else:
                self.vertical.pack_forget()
        if horizontal != self.bars[1]:
            if horizontal:
                self.horizontal.pack(side="bottom", fill="x", before=self.canvas)
            else:
                self.horizontal.pack_forget()
        self.bars = (vertical, horizontal)
        size = (max(wanted_width, width - (bar_width if vertical else 0)),
                max(wanted_height, height - (bar_height if horizontal else 0)))
        if size != self.size:
            self.size = size
            self.canvas.itemconfigure(self.item, width=size[0], height=size[1])
            self.canvas.configure(scrollregion=(0, 0, *size))
        if not horizontal and self.canvas.xview()[0]:
            self.canvas.xview_moveto(0)
        if not vertical and self.canvas.yview()[0]:
            self.canvas.yview_moveto(0)

    def contains(self, widget, keep_wheel=False):
        while widget is not None and not isinstance(widget, tk.Toplevel):
            if widget is self:
                return True
            if keep_wheel and (isinstance(widget, (tk.Text, tk.Listbox)) or getattr(widget, "keep_wheel", False)):
                return False
            widget = getattr(widget, "master", None)
        return False

    def wheel(self, event):
        try:
            widget = self.winfo_containing(event.x_root, event.y_root) or event.widget
        except KeyError:
            return
        if not self.contains(widget, keep_wheel=True) or not event.delta:
            return
        horizontal = event.state & 1 or widget is self.horizontal
        view = self.canvas.xview if horizontal else self.canvas.yview
        scroll = self.canvas.xview_scroll if horizontal else self.canvas.yview_scroll
        if view() != (0.0, 1.0):
            self._finish_transition()
            distance = max(1, abs(event.delta) * 48 // 120)
            scroll(-distance if event.delta > 0 else distance, "units")
            return "break"

    def reveal(self, event):
        if self.contains(event.widget):
            self.after_idle(self._reveal_focus)

    def _reveal_focus(self):
        try:
            widget = self.focus_get()
        except KeyError:
            return
        if self.size is None or not self.contains(widget) or widget in (self.canvas, self.horizontal, self.vertical):
            return
        x = y = 0
        node = widget
        while node is not self.body:
            if node is None or node is self:
                return
            x += node.winfo_x()
            y += node.winfo_y()
            node = node.master
        canvas = self.canvas
        for start, length, available, origin, total, move in (
            (x, widget.winfo_width(), canvas.winfo_width(), canvas.canvasx(0), self.size[0], canvas.xview_moveto),
            (y, widget.winfo_height(), canvas.winfo_height(), canvas.canvasy(0), self.size[1], canvas.yview_moveto),
        ):
            if length > available:
                continue
            if start < origin:
                move((start - 5) / total)
            elif start + length > origin + available:
                move((start + length + 5 - available) / total)

    def destroy(self):
        self._finish_transition()
        super().destroy()
