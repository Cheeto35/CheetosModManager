"""In-window views for the independently installed Sheikah Mods add-on."""

import os
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

from . import dialogs
from .widgets import BG, SECONDARY, SURF, UI, button, card, frame, label, styles


_SUPPORTED_VERSION = "1.2.2"
_DRAFT_COLORS = {
    "AMBER": "STATUS_WARNING", "GREEN": "STATUS_OK", "RED": "STATUS_ERROR", "MUTED": SECONDARY,
}


class SheikahPage(tk.Frame):
    def __init__(self, parent, root, addon, game_dir):
        super().__init__(parent)
        self.root = root
        self.addon = addon
        self.game_dir = game_dir
        self._plan = None
        styles(self).bind(self, bg=BG)

        status_card, content = card(self, "Mod status")
        status_card.pack(fill="x")
        self.subtitle = label(content, "Check mods for the selected game.", wraplength=245, justify="left")
        self.subtitle.pack(fill="x", pady=(6, 0))
        self.status = label(content, size=9, color=SECONDARY, wraplength=245, justify="left")

        actions = frame(content)
        actions.pack(fill="x", pady=(10, 0))
        self.check_button = button(actions, "Check now", lambda: addon.check(root, game_dir, force=True), compact=True)
        self.check_button.pack(side="left")
        self.apply_button = button(actions, "Check mods", lambda: addon._apply_click(root), primary=True, compact=True)
        self.apply_button.configure(state="disabled")
        self.apply_button.pack(side="right")
        mods_dir = Path(game_dir, "Mods")
        folder = button(content, "Open Mods folder", lambda: os.startfile(str(mods_dir)), compact=True)
        if not mods_dir.is_dir():
            folder.configure(state="disabled")
        folder.pack(anchor="w", pady=(7, 0))

        label(content, f"These mods load only when connecting to {addon.core.HOST}:{addon.switching.SERVER_PORT}.",
              size=9, color=SECONDARY, wraplength=245, justify="left").pack(fill="x", pady=(8, 0))
        self.list = frame(self)
        self.list.pack(fill="x", pady=(12, 0))

    def show(self, plan=None, status=None, busy=False, issue=None):
        if plan is not None:
            location = ("Parked for other servers." if self.addon.switching.is_parked(plan.game_dir)
                        else "In Mods for Sheikah.")
            self.subtitle.configure(text=f"{len(plan.ready)} of {len(plan.mods)} mods match the Sheikah list.\n{location}")
            if plan is not self._plan:
                self._fill(plan)
                self._plan = plan
        elif not busy:
            self._clear_list()
            self._plan = None
            self.subtitle.configure(text="Check mods for the selected game.")
        self.check_button.configure(state="disabled" if busy else "normal")
        caption, enabled = self.addon.ui_state.action(plan, busy, issue)
        self.apply_button.configure(text=caption, state="normal" if enabled else "disabled")
        if status is not None:
            styles(self.status).bind(self.status, fg="STATUS_WARNING" if issue or (plan and plan.offline) else SECONDARY)
            self.status.configure(text=status)
            if status:
                self.status.pack(fill="x", pady=(7, 0), after=self.subtitle)
            else:
                self.status.pack_forget()

    def _clear_list(self):
        for child in tuple(self.list.children.values()):
            child.destroy()

    def _fill(self, plan):
        self._clear_list()
        for title, color, rows in self.addon.window.sections(plan, include_ready=True):
            group, body = card(self.list, f"{title}  ·  {len(rows)}")
            group.pack(fill="x", pady=(0, 10))
            for name, detail, badge in rows:
                row = frame(body)
                row.pack(fill="x", pady=(7, 0))
                label(row, badge, size=8, color=_DRAFT_COLORS[color], weight="bold").pack(anchor="w")
                label(row, name, size=9, weight="bold", wraplength=240, justify="left").pack(fill="x")
                label(row, detail, size=8, color=SECONDARY, wraplength=240, justify="left").pack(fill="x")

    def close(self):
        if getattr(self.root, "_sheikah_window", None) is self:
            self.root._sheikah_window = None


def _open(root, addon):
    game_dir = addon._game_dir(root)
    if game_dir is None:
        messagebox.showerror(addon.core.NAME, "Set the game executable in TavernLauncher first.", parent=root)
        return
    dashboard = root._launcher_overhaul
    if isinstance(dashboard.detail_content, SheikahPage):
        return

    dashboard.open_detail(addon.core.NAME, lambda parent: SheikahPage(parent, root, addon, game_dir),
                          getattr(root, "_sheikah_button", None), legacy=False)
    page = dashboard.detail_content
    if not isinstance(page, SheikahPage):
        return
    root._sheikah_window = page
    plan = getattr(root, "_sheikah_plan", None)
    if plan is not None and plan.game_dir != game_dir:
        plan = None
    addon._show(root, plan, "Checking the Sheikah Sanctuary mod list..."
                if getattr(root, "_sheikah_pending", False) else None)
    addon.check(root, game_dir, prompt=False)


def _review(root, addon, plan, launching):
    groups = addon.window.sections(plan)
    count = sum(len(rows) for _, _, rows in groups)
    caption = f"{addon.core.HOST}  ·  {count} {'change' if count == 1 else 'changes'}"
    segments = []
    for title, _, rows in groups:
        segments.append((f"{title}  ·  {len(rows)}\n", "section"))
        for name, detail, _ in rows:
            segments.extend(((name + "\n", "mod"), (detail + "\n", "detail")))
    if not segments:
        segments.append(("The installed mods match the current list.\n", "mod"))
    segments.append(("You can check again from Sheikah Mods if you skip these changes.", "note"))

    overlay = dialogs._Overlay(root, root, "Review Sheikah mod changes", "".join(line for line, _ in segments),
                               "okcancel", caption=caption, width_limit=680, minimum_lines=min(9, 3 + count * 2))
    colors = styles(overlay).colors
    overlay.text.configure(state="normal", padx=12, pady=10)
    overlay.text.delete("1.0", "end")
    overlay.text.tag_configure("section", foreground=colors["PANEL_ACCENT"], font=(UI, 10, "bold"),
                               spacing1=5, spacing3=4)
    overlay.text.tag_configure("mod", font=(UI, 10, "bold"))
    overlay.text.tag_configure("detail", foreground=colors[SECONDARY], lmargin1=8, lmargin2=8,
                               spacing3=6)
    overlay.text.tag_configure("note", foreground=colors[SECONDARY], spacing1=7)
    for line, tag in segments:
        overlay.text.insert("end", line, tag)
    overlay.text.configure(state="disabled")
    overlay.buttons["ok"].configure(text="Apply & launch" if launching else addon.ui_state.action(plan)[0])
    overlay.buttons["cancel"].configure(text="Launch without updating" if launching else "Skip for now")
    # Keep the primary button styling on Apply and the initial focus on Skip.
    overlay.preferred = "cancel"
    for key in ("<Return>", "<KP_Enter>"):
        overlay.text.bind(key, overlay.cancel)

    def wrap_buttons(event):
        width = max(65, (min(overlay.width_limit, event.width - 20) - 60) // 2)
        for control in overlay.buttons.values():
            control.configure(wraplength=width)

    overlay.bind("<Configure>", wrap_buttons, add="+")
    return overlay.run() == "ok"


class _WaitingPrompt(tk.Frame):
    def __init__(self, root, text, cancel):
        super().__init__(dialogs.prompt_surface(root, root))
        self._overhaul_theme_exempt = True
        self.root = root
        self.previous_prompt = None
        self.previous_focus = None
        self.previous_grab = None
        self.previous_grab_status = None
        styles(self).bind(self, bg=BG)
        self.panel = frame(self, SURF, border=True)
        self.panel.place(relx=.5, rely=.5, anchor="center", width=1)
        content = frame(self.panel)
        content.pack(fill="x", padx=14, pady=12)
        label(content, "Sheikah Mods", size=13, weight="bold").pack(fill="x")
        self.message = label(content, text, wraplength=250, justify="left")
        self.message.pack(fill="x", pady=(8, 10))
        self.cancel_button = button(content, "Cancel launch", cancel, compact=True)
        self.cancel_button.pack(anchor="e")
        self.bind("<Configure>", self._fit)

        def escape(event):
            cancel()
            return "break"

        self.cancel_button.bind("<Escape>", escape)
        for key in ("<Tab>", "<Shift-Tab>", "<ISO_Left_Tab>", "<F1>"):
            self.cancel_button.bind(key, lambda event: "break")

    def _fit(self, event):
        width = min(445, max(1, event.width - 20))
        self.panel.place_configure(width=width)
        self.message.configure(wraplength=max(80, width - 32))

    def deiconify(self):
        # Called by the add-on when this wait becomes the parent of a review.
        if self.winfo_manager():
            return
        self.previous_prompt = dialogs.active(self.root)
        try:
            self.previous_focus = self.root.focus_get()
        except KeyError:
            pass
        self.previous_grab = self.root.grab_current()
        if self.previous_grab is not None:
            self.previous_grab_status = self.previous_grab.grab_status()
        self.root._overhaul_prompt = self
        self.place(x=0, y=0, relwidth=1, relheight=1)
        self.lift()
        self.update_idletasks()
        self.grab_set()
        self.cancel_button.focus_set()

    def finish(self):
        shown = bool(self.winfo_manager())
        if getattr(self.root, "_overhaul_prompt", None) is self:
            self.root._overhaul_prompt = self.previous_prompt
        self.destroy()
        if not shown:
            return
        if dialogs._exists(self.previous_grab) and self.previous_grab.winfo_viewable():
            (self.previous_grab.grab_set_global if self.previous_grab_status == "global"
             else self.previous_grab.grab_set)()
        if dialogs._exists(self.previous_focus) and self.previous_focus.winfo_viewable():
            self.previous_focus.focus_set()


def _wait(root, addon, ready, text):
    if ready():
        return
    finished = tk.BooleanVar(master=root, value=False)
    cancelled = False

    def cancel():
        nonlocal cancelled
        cancelled = True
        finished.set(True)

    prompt = _WaitingPrompt(root, text, cancel)
    previous = getattr(root, "_sheikah_wait_dialog", None)
    root._sheikah_wait_dialog = prompt

    def poll():
        nonlocal poll_id
        poll_id = None
        if ready():
            finished.set(True)
        else:
            poll_id = root.after(50, poll)

    def destroyed(event):
        if event.widget is prompt and not finished.get():
            cancel()

    prompt.bind("<Destroy>", destroyed, add="+")
    show_id = root.after(250, prompt.deiconify)
    poll_id = root.after(50, poll)
    try:
        root.wait_variable(finished)
    finally:
        root._sheikah_wait_dialog = previous
        for job in (show_id, poll_id):
            if job is not None:
                try:
                    root.after_cancel(job)
                except tk.TclError:
                    pass
        if dialogs._exists(prompt):
            prompt.finish()
    if cancelled:
        raise addon.core.Cancelled("Launch cancelled. The Sheikah Mods check or update will finish in the background.")


def attach(root, addon):
    """Opt in a supported separate add-on without modifying its files."""
    if addon is None or getattr(addon.core, "VERSION", None) != _SUPPORTED_VERSION:
        return False
    if getattr(root, "_overhaul_sheikah_attached", False):
        return True
    window = addon.window
    stock_open, stock_review, stock_wait = addon._open, window.ask_updates, window.wait_for
    stock_progress = addon._set_progress

    def open_page(owner):
        if owner is root:
            return _open(root, addon)
        return stock_open(owner)

    def review(parent, plan, launching=False):
        if isinstance(parent, tk.Misc) and parent.winfo_toplevel() is root:
            return _review(root, addon, plan, launching)
        return stock_review(parent, plan, launching)

    def wait(owner, ready, text):
        if owner is root:
            flow = root._launcher_overhaul.launch_flow
            if flow.depth:
                flow.stage("Preparing Sheikah Mods", text)
            result = _wait(root, addon, ready, text)
            if flow.depth:
                flow.stage("Starting the game")
            return result
        return stock_wait(owner, ready, text)

    def progress(owner, text):
        if owner is root:
            flow = root._launcher_overhaul.launch_flow
            if flow.depth:
                flow.stage("Preparing Sheikah Mods", text)
        return stock_progress(owner, text)

    addon._open, window.ask_updates, window.wait_for = open_page, review, wait
    addon._set_progress = progress
    root._overhaul_sheikah_attached = True

    def restore(event):
        if event.widget is not root:
            return
        if addon._open is open_page:
            addon._open = stock_open
        if window.ask_updates is review:
            window.ask_updates = stock_review
        if window.wait_for is wait:
            window.wait_for = stock_wait
        if addon._set_progress is progress:
            addon._set_progress = stock_progress

    root.bind("<Destroy>", restore, add="+")
    return True
