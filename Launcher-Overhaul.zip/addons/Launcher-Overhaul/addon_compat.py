"""Keep the standalone Main Menu add-on's action in the launcher dashboard."""

from contextlib import contextmanager
import sys


def _main_menu_addon():
    # The stock loader imports enabled add-ons before building its window.
    addon = sys.modules.get("addons.mainmenu.client")
    if (callable(getattr(addon, "_launch_menu", None)) and
            callable(getattr(addon, "_add_menu_button", None))):
        return addon
    return None


def main_menu_action():
    addon = _main_menu_addon()
    return addon._launch_menu if addon is not None else None


@contextmanager
def suppress_menu_button(launcher):
    addon = _main_menu_addon()
    if addon is None:
        yield
        return

    original = addon._add_menu_button

    def add_menu_button(win, *args, **kwargs):
        if win is not launcher:
            return original(win, *args, **kwargs)

    # The legacy build wrapper looks this helper up when it runs. Keeping the
    # guard around the full build covers either add-on import order.
    addon._add_menu_button = add_menu_button
    try:
        yield
    finally:
        if addon._add_menu_button is add_menu_button:
            addon._add_menu_button = original
