"""Render the bundled guides with the launcher's typography and palette."""

import re

from tavern_shared import help_pane


def guide_html(slug, colors, brand):
    html = help_pane._render_html(slug)
    _, _, content = html.partition("<body>")
    article, _, _ = content.rpartition("</body>")
    article = re.sub(r"\bA Township Tale\.exe\b", "the game executable", article, flags=re.IGNORECASE)
    article = re.sub(r"\bA Township Tale\b", brand, article, flags=re.IGNORECASE)
    return f"""<html><head><style>
body {{
    margin: 0;
    padding: 20px 24px;
    background-color: {colors["SURF"]};
    color: {colors["PARCH"]};
    font-family: 'Segoe UI', sans-serif;
    font-size: 14px;
    line-height: 1.55;
}}
article {{ display: block; max-width: 760px; margin: 0 auto; }}
h1, h2, h3, h4 {{ color: {colors["PARCH"]}; }}
h1 {{ font-family: Georgia, serif; font-size: 24px; margin: 0 0 16px; }}
h2 {{ font-family: Georgia, serif; font-size: 19px; margin: 24px 0 8px; }}
h3, h4 {{ font-size: 15px; margin: 18px 0 6px; }}
p {{ margin: 0 0 14px; }}
a {{ color: {colors["PANEL_ACCENT"]}; }}
ul, ol {{ padding-left: 24px; margin: 0 0 14px; }}
li {{ margin: 0 0 5px; }}
img {{ max-width: 100%; height: auto; }}
code {{ color: {colors["FIELD_TEXT"]}; font-family: Consolas, monospace; font-size: 12px;
        background-color: {colors["FIELD"]}; }}
pre {{ background-color: {colors["FIELD"]}; padding: 10px 12px; white-space: pre-wrap; }}
blockquote {{ margin: 0 0 14px; padding: 6px 12px;
              border-left: 3px solid {colors["PANEL_ACCENT"]}; background-color: {colors["FIELD"]}; }}
blockquote p {{ margin: 0; }}
hr {{ border: none; border-top: 1px solid {colors["BORDER"]}; margin: 18px 0; }}
table {{ border-collapse: collapse; margin: 0 0 14px; }}
td, th {{ border: 1px solid {colors["BORDER"]}; padding: 5px 8px; font-size: 12px; }}
th {{ background-color: {colors["SURF2"]}; color: {colors["SURF2_TEXT"]}; }}
</style></head><body><article>{article}</article></body></html>"""
